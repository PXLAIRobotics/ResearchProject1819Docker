# encoding: utf-8
# module _padding.lib
# from /usr/lib/python2.7/dist-packages/cryptography/hazmat/bindings/_padding.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def Cryptography_check_ansix923_padding(uint8_t, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """
    uint8_t Cryptography_check_ansix923_padding(uint8_t *, uint8_t);
    
    CFFI C function from _padding.lib
    """
    pass

def Cryptography_check_pkcs7_padding(uint8_t, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """
    uint8_t Cryptography_check_pkcs7_padding(uint8_t *, uint8_t);
    
    CFFI C function from _padding.lib
    """
    pass

# no classes
