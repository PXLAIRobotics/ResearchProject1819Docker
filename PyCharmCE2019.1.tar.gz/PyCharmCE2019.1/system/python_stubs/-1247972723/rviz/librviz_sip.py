# encoding: utf-8
# module rviz.librviz_sip
# from /opt/ros/melodic/lib/python2.7/dist-packages/rviz/librviz_sip.so
# by generator 1.147
# no doc
# no imports

# no functions
# classes

class rviz(): # skipped bases: <type 'sip.simplewrapper'>
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    BoolProperty = None # (!) real value is "<class 'librviz_sip.BoolProperty'>"
    Config = None # (!) real value is "<class 'librviz_sip.Config'>"
    Display = None # (!) real value is "<class 'librviz_sip.Display'>"
    DisplayGroup = None # (!) real value is "<class 'librviz_sip.DisplayGroup'>"
    OgreLogging = None # (!) real value is "<class 'librviz_sip.OgreLogging'>"
    PanelDockWidget = None # (!) real value is "<class 'librviz_sip.PanelDockWidget'>"
    Property = None # (!) real value is "<class 'librviz_sip.Property'>"
    Tool = None # (!) real value is "<class 'librviz_sip.Tool'>"
    ToolManager = None # (!) real value is "<class 'librviz_sip.ToolManager'>"
    ViewController = None # (!) real value is "<class 'librviz_sip.ViewController'>"
    ViewManager = None # (!) real value is "<class 'librviz_sip.ViewManager'>"
    VisualizationFrame = None # (!) real value is "<class 'librviz_sip.VisualizationFrame'>"
    VisualizationManager = None # (!) real value is "<class 'librviz_sip.VisualizationManager'>"
    YamlConfigReader = None # (!) real value is "<class 'librviz_sip.YamlConfigReader'>"
    YamlConfigWriter = None # (!) real value is "<class 'librviz_sip.YamlConfigWriter'>"


