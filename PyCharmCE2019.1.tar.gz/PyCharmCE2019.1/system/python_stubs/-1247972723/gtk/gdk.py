# encoding: utf-8
# module gtk.gdk
# from /usr/lib/python2.7/dist-packages/gi/_gi.x86_64-linux-gnu.so
# by generator 1.147
""" When using gi.repository you must not import static modules like "gobject". Please change all occurrences of "import gobject" to "from gi.repository import GObject". See: https://bugzilla.gnome.org/show_bug.cgi?id=709183 """
# no imports

# no functions
# no classes
