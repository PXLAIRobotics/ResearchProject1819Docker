# encoding: utf-8
# module _codecs_jp
# from /usr/lib/python2.7/lib-dynload/_codecs_jp.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    """  """
    pass

# no classes
# variables with complex values

__map_cp932ext = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f36eb7d4210>'

__map_jisx0208 = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f36eb8c3a20>'

__map_jisx0212 = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f36eb8c3d50>'

__map_jisx0213_1_bmp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f36eb7d4060>'

__map_jisx0213_1_emp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f36eb7d4150>'

__map_jisx0213_2_bmp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f36eb7d40f0>'

__map_jisx0213_2_emp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f36eb7d4180>'

__map_jisx0213_bmp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f36eb7d4120>'

__map_jisx0213_emp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f36eb7d41b0>'

__map_jisx0213_pair = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f36eb7d41e0>'

__map_jisxcommon = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f36eb8c3f60>'

