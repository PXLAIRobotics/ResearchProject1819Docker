# encoding: utf-8
# module wx._animate
# from /usr/lib/python2.7/dist-packages/wx-3.0-gtk3/wx/_animate.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

AC_DEFAULT_STYLE = 2097152

AC_NO_AUTORESIZE = 16

ANIMATION_TYPE_ANI = 2
ANIMATION_TYPE_ANY = 3
ANIMATION_TYPE_GIF = 1
ANIMATION_TYPE_INVALID = 0

ANIM_DONOTREMOVE = 0
ANIM_TOBACKGROUND = 1
ANIM_TOPREVIOUS = 2
ANIM_UNSPECIFIED = -1

AN_FIT_ANIMATION = 16

# functions

def AnimationBase_GetDelay(*args, **kwargs): # real signature unknown
    pass

def AnimationBase_GetFrame(*args, **kwargs): # real signature unknown
    pass

def AnimationBase_GetFrameCount(*args, **kwargs): # real signature unknown
    pass

def AnimationBase_GetSize(*args, **kwargs): # real signature unknown
    pass

def AnimationBase_IsOk(*args, **kwargs): # real signature unknown
    pass

def AnimationBase_Load(*args, **kwargs): # real signature unknown
    pass

def AnimationBase_LoadFile(*args, **kwargs): # real signature unknown
    pass

def AnimationBase_swigregister(*args, **kwargs): # real signature unknown
    pass

def AnimationCtrlBase_GetAnimation(*args, **kwargs): # real signature unknown
    pass

def AnimationCtrlBase_GetInactiveBitmap(*args, **kwargs): # real signature unknown
    pass

def AnimationCtrlBase_IsPlaying(*args, **kwargs): # real signature unknown
    pass

def AnimationCtrlBase_LoadFile(*args, **kwargs): # real signature unknown
    pass

def AnimationCtrlBase_Play(*args, **kwargs): # real signature unknown
    pass

def AnimationCtrlBase_SetAnimation(*args, **kwargs): # real signature unknown
    pass

def AnimationCtrlBase_SetInactiveBitmap(*args, **kwargs): # real signature unknown
    pass

def AnimationCtrlBase_Stop(*args, **kwargs): # real signature unknown
    pass

def AnimationCtrlBase_swigregister(*args, **kwargs): # real signature unknown
    pass

def AnimationCtrl_Create(*args, **kwargs): # real signature unknown
    pass

def AnimationCtrl_DrawCurrentFrame(*args, **kwargs): # real signature unknown
    pass

def AnimationCtrl_GetBackingStore(*args, **kwargs): # real signature unknown
    pass

def AnimationCtrl_IsUsingWindowBackgroundColour(*args, **kwargs): # real signature unknown
    pass

def AnimationCtrl_SetUseWindowBackgroundColour(*args, **kwargs): # real signature unknown
    pass

def AnimationCtrl_swiginit(*args, **kwargs): # real signature unknown
    pass

def AnimationCtrl_swigregister(*args, **kwargs): # real signature unknown
    pass

def Animation_GetBackgroundColour(*args, **kwargs): # real signature unknown
    pass

def Animation_GetDisposalMethod(*args, **kwargs): # real signature unknown
    pass

def Animation_GetFramePosition(*args, **kwargs): # real signature unknown
    pass

def Animation_GetFrameSize(*args, **kwargs): # real signature unknown
    pass

def Animation_GetTransparentColour(*args, **kwargs): # real signature unknown
    pass

def Animation_swiginit(*args, **kwargs): # real signature unknown
    pass

def Animation_swigregister(*args, **kwargs): # real signature unknown
    pass

def delete_Animation(*args, **kwargs): # real signature unknown
    pass

def delete_AnimationBase(*args, **kwargs): # real signature unknown
    pass

def new_Animation(*args, **kwargs): # real signature unknown
    pass

def new_AnimationCtrl(*args, **kwargs): # real signature unknown
    pass

def new_PreAnimationCtrl(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

cvar = None # (!) real value is '<Swig global variables>'

