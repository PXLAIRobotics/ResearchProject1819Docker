# encoding: utf-8
# module wx._windows_
# from /usr/lib/python2.7/dist-packages/wx-3.0-gtk3/wx/_windows_.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

CHOICEDLG_STYLE = 536877141

CLOSE_BOX = 4096

ColourData_NUM_CUSTOM = 16

DD_CHANGE_DIR = 256

DD_DEFAULT_STYLE = 536877120

DD_DIR_MUST_EXIST = 512

DD_NEW_DIR_BUTTON = 0

DEFAULT_DIALOG_STYLE = 536877056

DEFAULT_FRAME_STYLE = 541072960

DEFAULT_MINIFRAME_STYLE = 536871104

DIALOG_ADAPTATION_ANY_SIZER = 2

DIALOG_ADAPTATION_LOOSE_BUTTONS = 3

DIALOG_ADAPTATION_MODE_DEFAULT = 0
DIALOG_ADAPTATION_MODE_DISABLED = 2
DIALOG_ADAPTATION_MODE_ENABLED = 1

DIALOG_ADAPTATION_NONE = 0

DIALOG_ADAPTATION_STANDARD_SIZER = 1

DIALOG_EX_CONTEXTHELP = 128
DIALOG_EX_METAL = 64

DIALOG_MODALITY_APP_MODAL = 2

DIALOG_MODALITY_NONE = 0

DIALOG_MODALITY_WINDOW_MODAL = 1

DIALOG_NO_PARENT = 32

FD_CHANGE_DIR = 128

FD_DEFAULT_STYLE = 1

FD_FILE_MUST_EXIST = 16

FD_MULTIPLE = 32
FD_OPEN = 1

FD_OVERWRITE_PROMPT = 4

FD_PREVIEW = 256
FD_SAVE = 2

FIRST_MDI_CHILD = 4100

FRAME_DRAWER = 32

FRAME_EX_CONTEXTHELP = 128
FRAME_EX_METAL = 64

FRAME_FLOAT_ON_PARENT = 8

FRAME_NO_TASKBAR = 2

FRAME_NO_WINDOW_MENU = 256

FRAME_SHAPED = 16

FRAME_TOOL_WINDOW = 4

FR_DOWN = 1
FR_MATCHCASE = 4
FR_NOMATCHCASE = 4
FR_NOUPDOWN = 2
FR_NOWHOLEWORD = 8
FR_REPLACEDIALOG = 1
FR_WHOLEWORD = 2

FULLSCREEN_ALL = 31
FULLSCREEN_NOBORDER = 8
FULLSCREEN_NOCAPTION = 16
FULLSCREEN_NOMENUBAR = 1
FULLSCREEN_NOSTATUSBAR = 4
FULLSCREEN_NOTOOLBAR = 2

HLB_DEFAULT_STYLE = 134217728

HLB_MULTIPLE = 64

ICONIZE = 16384

IDM_WINDOWCASCADE = 4002
IDM_WINDOWICONS = 4003
IDM_WINDOWNEXT = 4004
IDM_WINDOWPREV = 4006
IDM_WINDOWTILE = 4001
IDM_WINDOWTILEHOR = 4001
IDM_WINDOWTILEVERT = 4005

ID_PREVIEW_CLOSE = 1
ID_PREVIEW_FIRST = 6
ID_PREVIEW_GOTO = 8
ID_PREVIEW_LAST = 7
ID_PREVIEW_NEXT = 2
ID_PREVIEW_PREVIOUS = 3
ID_PREVIEW_PRINT = 4
ID_PREVIEW_ZOOM = 5

LAST_MDI_CHILD = 4600

LAYOUT_BOTTOM = 4
LAYOUT_HORIZONTAL = 0
LAYOUT_LEFT = 2

LAYOUT_LENGTH_X = 0
LAYOUT_LENGTH_Y = 8

LAYOUT_MRU_LENGTH = 16

LAYOUT_NONE = 0
LAYOUT_QUERY = 256
LAYOUT_RIGHT = 3
LAYOUT_TOP = 1
LAYOUT_VERTICAL = 1

MAXIMIZE = 8192

MAXIMIZE_BOX = 512

MINIMIZE = 16384

MINIMIZE_BOX = 1024

PD_APP_MODAL = 2

PD_AUTO_HIDE = 4

PD_CAN_ABORT = 1
PD_CAN_SKIP = 128

PD_ELAPSED_TIME = 8

PD_ESTIMATED_TIME = 16

PD_REMAINING_TIME = 64

PD_SMOOTH = 32

PreviewFrame_AppModal = 0
PreviewFrame_NonModal = 2
PreviewFrame_WindowModal = 1

PREVIEW_DEFAULT = 126
PREVIEW_FIRST = 16
PREVIEW_GOTO = 64
PREVIEW_LAST = 32
PREVIEW_NEXT = 4
PREVIEW_PREVIOUS = 2
PREVIEW_PRINT = 1
PREVIEW_ZOOM = 8

PRINTBIN_AUTO = 7
PRINTBIN_CASSETTE = 12
PRINTBIN_DEFAULT = 0
PRINTBIN_ENVELOPE = 5
PRINTBIN_ENVMANUAL = 6
PRINTBIN_FORMSOURCE = 13
PRINTBIN_LARGECAPACITY = 11
PRINTBIN_LARGEFMT = 10
PRINTBIN_LOWER = 2
PRINTBIN_MANUAL = 4
PRINTBIN_MIDDLE = 3
PRINTBIN_ONLYONE = 1
PRINTBIN_SMALLFMT = 9
PRINTBIN_TRACTOR = 8
PRINTBIN_USER = 14

PRINTER_CANCELLED = 1
PRINTER_ERROR = 2

PRINTER_NO_ERROR = 0

PRINT_MODE_FILE = 2
PRINT_MODE_NONE = 0
PRINT_MODE_PREVIEW = 1
PRINT_MODE_PRINTER = 3
PRINT_MODE_STREAM = 4

RESIZE_BORDER = 64

SASH_BOTTOM = 2

SASH_DRAG_DRAGGING = 1

SASH_DRAG_LEFT_DOWN = 2

SASH_DRAG_NONE = 0

SASH_LEFT = 3
SASH_NONE = 100
SASH_RIGHT = 1

SASH_STATUS_OK = 0

SASH_STATUS_OUT_OF_RANGE = 1

SASH_TOP = 0

SB_FLAT = 1
SB_NORMAL = 0
SB_RAISED = 2

SHOW_SB_ALWAYS = 1
SHOW_SB_DEFAULT = 0
SHOW_SB_NEVER = -1

SPLASH_CENTER_ON_PARENT = 1
SPLASH_CENTER_ON_SCREEN = 2

SPLASH_CENTRE_ON_PARENT = 1
SPLASH_CENTRE_ON_SCREEN = 2

SPLASH_NO_CENTER = 0
SPLASH_NO_CENTRE = 0
SPLASH_NO_TIMEOUT = 0

SPLASH_TIMEOUT = 4

SPLIT_DRAG_DRAGGING = 1

SPLIT_DRAG_LEFT_DOWN = 2

SPLIT_DRAG_NONE = 0

SPLIT_HORIZONTAL = 1
SPLIT_VERTICAL = 2

SP_3D = 768
SP_3DBORDER = 512
SP_3DSASH = 256
SP_BORDER = 512

SP_LIVE_UPDATE = 128

SP_NOBORDER = 0
SP_NOSASH = 16

SP_NO_XP_THEME = 1024

SP_PERMIT_UNSPLIT = 64

SP_THIN_SASH = 0

STAY_ON_TOP = 32768

STB_DEFAULT_STYLE = 65840

STB_ELLIPSIZE_END = 256
STB_ELLIPSIZE_MIDDLE = 128
STB_ELLIPSIZE_START = 64

STB_SHOW_TIPS = 32

STB_SIZEGRIP = 16

ST_SIZEGRIP = 16

SW_3D = 192
SW_3DBORDER = 128
SW_3DSASH = 64
SW_BORDER = 32
SW_NOBORDER = 0

SYSTEM_MENU = 2048

TBI_CUSTOM_STATUSITEM = 1

TBI_DEFAULT_TYPE = 0

TBI_DOCK = 0

TextEntryDialogStyle = 21

TINY_CAPTION_HORIZ = 128
TINY_CAPTION_VERT = 128

TOPLEVEL_EX_DIALOG = 8

USER_ATTENTION_ERROR = 2
USER_ATTENTION_INFO = 1

WS_EX_CONTEXTHELP = 128

wxEVT_CALCULATE_LAYOUT = 10274

wxEVT_COMMAND_FIND = 10128

wxEVT_COMMAND_FIND_CLOSE = 10132
wxEVT_COMMAND_FIND_NEXT = 10129
wxEVT_COMMAND_FIND_REPLACE = 10130

wxEVT_COMMAND_FIND_REPLACE_ALL = 10131

wxEVT_COMMAND_SPLITTER_DOUBLECLICKED = 10212

wxEVT_COMMAND_SPLITTER_SASH_POS_CHANGED = 10210
wxEVT_COMMAND_SPLITTER_SASH_POS_CHANGING = 10211

wxEVT_COMMAND_SPLITTER_UNSPLIT = 10213

wxEVT_QUERY_LAYOUT_INFO = 10273

wxEVT_SASH_DRAGGED = 10275

wxEVT_TASKBAR_BALLOON_CLICK = 10298
wxEVT_TASKBAR_BALLOON_TIMEOUT = 10297

wxEVT_TASKBAR_CLICK = 10293

wxEVT_TASKBAR_LEFT_DCLICK = 10295
wxEVT_TASKBAR_LEFT_DOWN = 10291
wxEVT_TASKBAR_LEFT_UP = 10292

wxEVT_TASKBAR_MOVE = 10290

wxEVT_TASKBAR_RIGHT_DCLICK = 10296
wxEVT_TASKBAR_RIGHT_DOWN = 10293
wxEVT_TASKBAR_RIGHT_UP = 10294

wxEVT_WINDOW_MODAL_DIALOG_CLOSED = 10127

# functions

def CalculateLayoutEvent_GetFlags(*args, **kwargs): # real signature unknown
    pass

def CalculateLayoutEvent_GetRect(*args, **kwargs): # real signature unknown
    pass

def CalculateLayoutEvent_SetFlags(*args, **kwargs): # real signature unknown
    pass

def CalculateLayoutEvent_SetRect(*args, **kwargs): # real signature unknown
    pass

def CalculateLayoutEvent_swiginit(*args, **kwargs): # real signature unknown
    pass

def CalculateLayoutEvent_swigregister(*args, **kwargs): # real signature unknown
    pass

def ColourData_FromString(*args, **kwargs): # real signature unknown
    pass

def ColourData_GetChooseFull(*args, **kwargs): # real signature unknown
    pass

def ColourData_GetColour(*args, **kwargs): # real signature unknown
    pass

def ColourData_GetCustomColour(*args, **kwargs): # real signature unknown
    pass

def ColourData_SetChooseFull(*args, **kwargs): # real signature unknown
    pass

def ColourData_SetColour(*args, **kwargs): # real signature unknown
    pass

def ColourData_SetCustomColour(*args, **kwargs): # real signature unknown
    pass

def ColourData_swiginit(*args, **kwargs): # real signature unknown
    pass

def ColourData_swigregister(*args, **kwargs): # real signature unknown
    pass

def ColourData_ToString(*args, **kwargs): # real signature unknown
    pass

def ColourDialog_GetColourData(*args, **kwargs): # real signature unknown
    pass

def ColourDialog_swiginit(*args, **kwargs): # real signature unknown
    pass

def ColourDialog_swigregister(*args, **kwargs): # real signature unknown
    pass

def delete_ColourData(*args, **kwargs): # real signature unknown
    pass

def delete_FindReplaceData(*args, **kwargs): # real signature unknown
    pass

def delete_FontData(*args, **kwargs): # real signature unknown
    pass

def delete_LayoutAlgorithm(*args, **kwargs): # real signature unknown
    pass

def delete_PageSetupDialog(*args, **kwargs): # real signature unknown
    pass

def delete_PageSetupDialogData(*args, **kwargs): # real signature unknown
    pass

def delete_PrintData(*args, **kwargs): # real signature unknown
    pass

def delete_PrintDialog(*args, **kwargs): # real signature unknown
    pass

def delete_PrintDialogData(*args, **kwargs): # real signature unknown
    pass

def delete_Printer(*args, **kwargs): # real signature unknown
    pass

def delete_Printout(*args, **kwargs): # real signature unknown
    pass

def delete_PrintPreview(*args, **kwargs): # real signature unknown
    pass

def delete_TaskBarIcon(*args, **kwargs): # real signature unknown
    pass

def DialogLayoutAdapter_CanDoLayoutAdaptation(*args, **kwargs): # real signature unknown
    pass

def DialogLayoutAdapter_DoLayoutAdaptation(*args, **kwargs): # real signature unknown
    pass

def DialogLayoutAdapter_swigregister(*args, **kwargs): # real signature unknown
    pass

def Dialog_AddMainButtonId(*args, **kwargs): # real signature unknown
    pass

def Dialog_CanDoLayoutAdaptation(*args, **kwargs): # real signature unknown
    pass

def Dialog_Create(*args, **kwargs): # real signature unknown
    pass

def Dialog_CreateSeparatedButtonSizer(*args, **kwargs): # real signature unknown
    pass

def Dialog_CreateSeparatedSizer(*args, **kwargs): # real signature unknown
    pass

def Dialog_CreateStdDialogButtonSizer(*args, **kwargs): # real signature unknown
    pass

def Dialog_CreateTextSizer(*args, **kwargs): # real signature unknown
    pass

def Dialog_DoLayoutAdaptation(*args, **kwargs): # real signature unknown
    pass

def Dialog_EnableLayoutAdaptation(*args, **kwargs): # real signature unknown
    pass

def Dialog_EndModal(*args, **kwargs): # real signature unknown
    pass

def Dialog_GetAffirmativeId(*args, **kwargs): # real signature unknown
    pass

def Dialog_GetClassDefaultAttributes(*args, **kwargs): # real signature unknown
    pass

def Dialog_GetContentWindow(*args, **kwargs): # real signature unknown
    pass

def Dialog_GetEscapeId(*args, **kwargs): # real signature unknown
    pass

def Dialog_GetLayoutAdaptationDone(*args, **kwargs): # real signature unknown
    pass

def Dialog_GetLayoutAdaptationLevel(*args, **kwargs): # real signature unknown
    pass

def Dialog_GetLayoutAdaptationMode(*args, **kwargs): # real signature unknown
    pass

def Dialog_GetLayoutAdapter(*args, **kwargs): # real signature unknown
    pass

def Dialog_GetMainButtonIds(*args, **kwargs): # real signature unknown
    pass

def Dialog_GetModality(*args, **kwargs): # real signature unknown
    pass

def Dialog_GetParentForModalDialog(*args, **kwargs): # real signature unknown
    pass

def Dialog_GetReturnCode(*args, **kwargs): # real signature unknown
    pass

def Dialog_IsLayoutAdaptationEnabled(*args, **kwargs): # real signature unknown
    pass

def Dialog_IsMainButtonId(*args, **kwargs): # real signature unknown
    pass

def Dialog_IsModal(*args, **kwargs): # real signature unknown
    pass

def Dialog_SendWindowModalDialogEvent(*args, **kwargs): # real signature unknown
    pass

def Dialog_SetAffirmativeId(*args, **kwargs): # real signature unknown
    pass

def Dialog_SetEscapeId(*args, **kwargs): # real signature unknown
    pass

def Dialog_SetLayoutAdaptationDone(*args, **kwargs): # real signature unknown
    pass

def Dialog_SetLayoutAdaptationLevel(*args, **kwargs): # real signature unknown
    pass

def Dialog_SetLayoutAdaptationMode(*args, **kwargs): # real signature unknown
    pass

def Dialog_SetLayoutAdapter(*args, **kwargs): # real signature unknown
    pass

def Dialog_SetReturnCode(*args, **kwargs): # real signature unknown
    pass

def Dialog_ShowModal(*args, **kwargs): # real signature unknown
    pass

def Dialog_ShowWindowModal(*args, **kwargs): # real signature unknown
    pass

def Dialog_swiginit(*args, **kwargs): # real signature unknown
    pass

def Dialog_swigregister(*args, **kwargs): # real signature unknown
    pass

def Dialog__CreateButtonSizer(*args, **kwargs): # real signature unknown
    pass

def DirDialog_GetMessage(*args, **kwargs): # real signature unknown
    pass

def DirDialog_GetPath(*args, **kwargs): # real signature unknown
    pass

def DirDialog_SetMessage(*args, **kwargs): # real signature unknown
    pass

def DirDialog_SetPath(*args, **kwargs): # real signature unknown
    pass

def DirDialog_swiginit(*args, **kwargs): # real signature unknown
    pass

def DirDialog_swigregister(*args, **kwargs): # real signature unknown
    pass

def FileDialog_GetDirectory(*args, **kwargs): # real signature unknown
    pass

def FileDialog_GetFilename(*args, **kwargs): # real signature unknown
    pass

def FileDialog_GetFilenames(*args, **kwargs): # real signature unknown
    pass

def FileDialog_GetFilterIndex(*args, **kwargs): # real signature unknown
    pass

def FileDialog_GetMessage(*args, **kwargs): # real signature unknown
    pass

def FileDialog_GetPath(*args, **kwargs): # real signature unknown
    pass

def FileDialog_GetPaths(*args, **kwargs): # real signature unknown
    pass

def FileDialog_GetWildcard(*args, **kwargs): # real signature unknown
    pass

def FileDialog_SetDirectory(*args, **kwargs): # real signature unknown
    pass

def FileDialog_SetFilename(*args, **kwargs): # real signature unknown
    pass

def FileDialog_SetFilterIndex(*args, **kwargs): # real signature unknown
    pass

def FileDialog_SetMessage(*args, **kwargs): # real signature unknown
    pass

def FileDialog_SetPath(*args, **kwargs): # real signature unknown
    pass

def FileDialog_SetWildcard(*args, **kwargs): # real signature unknown
    pass

def FileDialog_swiginit(*args, **kwargs): # real signature unknown
    pass

def FileDialog_swigregister(*args, **kwargs): # real signature unknown
    pass

def FindDialogEvent_GetDialog(*args, **kwargs): # real signature unknown
    pass

def FindDialogEvent_GetFindString(*args, **kwargs): # real signature unknown
    pass

def FindDialogEvent_GetFlags(*args, **kwargs): # real signature unknown
    pass

def FindDialogEvent_GetReplaceString(*args, **kwargs): # real signature unknown
    pass

def FindDialogEvent_SetFindString(*args, **kwargs): # real signature unknown
    pass

def FindDialogEvent_SetFlags(*args, **kwargs): # real signature unknown
    pass

def FindDialogEvent_SetReplaceString(*args, **kwargs): # real signature unknown
    pass

def FindDialogEvent_swiginit(*args, **kwargs): # real signature unknown
    pass

def FindDialogEvent_swigregister(*args, **kwargs): # real signature unknown
    pass

def FindReplaceData_GetFindString(*args, **kwargs): # real signature unknown
    pass

def FindReplaceData_GetFlags(*args, **kwargs): # real signature unknown
    pass

def FindReplaceData_GetReplaceString(*args, **kwargs): # real signature unknown
    pass

def FindReplaceData_SetFindString(*args, **kwargs): # real signature unknown
    pass

def FindReplaceData_SetFlags(*args, **kwargs): # real signature unknown
    pass

def FindReplaceData_SetReplaceString(*args, **kwargs): # real signature unknown
    pass

def FindReplaceData_swiginit(*args, **kwargs): # real signature unknown
    pass

def FindReplaceData_swigregister(*args, **kwargs): # real signature unknown
    pass

def FindReplaceDialog_Create(*args, **kwargs): # real signature unknown
    pass

def FindReplaceDialog_GetData(*args, **kwargs): # real signature unknown
    pass

def FindReplaceDialog_SetData(*args, **kwargs): # real signature unknown
    pass

def FindReplaceDialog_swiginit(*args, **kwargs): # real signature unknown
    pass

def FindReplaceDialog_swigregister(*args, **kwargs): # real signature unknown
    pass

def FontData_EnableEffects(*args, **kwargs): # real signature unknown
    pass

def FontData_GetAllowSymbols(*args, **kwargs): # real signature unknown
    pass

def FontData_GetChosenFont(*args, **kwargs): # real signature unknown
    pass

def FontData_GetColour(*args, **kwargs): # real signature unknown
    pass

def FontData_GetEnableEffects(*args, **kwargs): # real signature unknown
    pass

def FontData_GetInitialFont(*args, **kwargs): # real signature unknown
    pass

def FontData_GetShowHelp(*args, **kwargs): # real signature unknown
    pass

def FontData_SetAllowSymbols(*args, **kwargs): # real signature unknown
    pass

def FontData_SetChosenFont(*args, **kwargs): # real signature unknown
    pass

def FontData_SetColour(*args, **kwargs): # real signature unknown
    pass

def FontData_SetInitialFont(*args, **kwargs): # real signature unknown
    pass

def FontData_SetRange(*args, **kwargs): # real signature unknown
    pass

def FontData_SetShowHelp(*args, **kwargs): # real signature unknown
    pass

def FontData_swiginit(*args, **kwargs): # real signature unknown
    pass

def FontData_swigregister(*args, **kwargs): # real signature unknown
    pass

def FontDialog_GetFontData(*args, **kwargs): # real signature unknown
    pass

def FontDialog_swiginit(*args, **kwargs): # real signature unknown
    pass

def FontDialog_swigregister(*args, **kwargs): # real signature unknown
    pass

def Frame_Create(*args, **kwargs): # real signature unknown
    pass

def Frame_CreateStatusBar(*args, **kwargs): # real signature unknown
    pass

def Frame_CreateToolBar(*args, **kwargs): # real signature unknown
    pass

def Frame_DoGiveHelp(*args, **kwargs): # real signature unknown
    pass

def Frame_DoMenuUpdates(*args, **kwargs): # real signature unknown
    pass

def Frame_FindItemInMenuBar(*args, **kwargs): # real signature unknown
    pass

def Frame_GetClassDefaultAttributes(*args, **kwargs): # real signature unknown
    pass

def Frame_GetMenuBar(*args, **kwargs): # real signature unknown
    pass

def Frame_GetStatusBar(*args, **kwargs): # real signature unknown
    pass

def Frame_GetStatusBarPane(*args, **kwargs): # real signature unknown
    pass

def Frame_GetToolBar(*args, **kwargs): # real signature unknown
    pass

def Frame_PopStatusText(*args, **kwargs): # real signature unknown
    pass

def Frame_ProcessCommand(*args, **kwargs): # real signature unknown
    pass

def Frame_PushStatusText(*args, **kwargs): # real signature unknown
    pass

def Frame_SetMenuBar(*args, **kwargs): # real signature unknown
    pass

def Frame_SetStatusBar(*args, **kwargs): # real signature unknown
    pass

def Frame_SetStatusBarPane(*args, **kwargs): # real signature unknown
    pass

def Frame_SetStatusText(*args, **kwargs): # real signature unknown
    pass

def Frame_SetStatusWidths(*args, **kwargs): # real signature unknown
    pass

def Frame_SetToolBar(*args, **kwargs): # real signature unknown
    pass

def Frame_swiginit(*args, **kwargs): # real signature unknown
    pass

def Frame_swigregister(*args, **kwargs): # real signature unknown
    pass

def GenericProgressDialog_GetMessage(*args, **kwargs): # real signature unknown
    pass

def GenericProgressDialog_GetRange(*args, **kwargs): # real signature unknown
    pass

def GenericProgressDialog_GetValue(*args, **kwargs): # real signature unknown
    pass

def GenericProgressDialog_Pulse(*args, **kwargs): # real signature unknown
    pass

def GenericProgressDialog_Resume(*args, **kwargs): # real signature unknown
    pass

def GenericProgressDialog_SetRange(*args, **kwargs): # real signature unknown
    pass

def GenericProgressDialog_swiginit(*args, **kwargs): # real signature unknown
    pass

def GenericProgressDialog_swigregister(*args, **kwargs): # real signature unknown
    pass

def GenericProgressDialog_Update(*args, **kwargs): # real signature unknown
    pass

def GenericProgressDialog_WasCancelled(*args, **kwargs): # real signature unknown
    pass

def GenericProgressDialog_WasSkipped(*args, **kwargs): # real signature unknown
    pass

def GetColourFromUser(*args, **kwargs): # real signature unknown
    pass

def GetFontFromUser(*args, **kwargs): # real signature unknown
    pass

def HScrolledWindow_Create(*args, **kwargs): # real signature unknown
    pass

def HScrolledWindow_EstimateTotalWidth(*args, **kwargs): # real signature unknown
    pass

def HScrolledWindow_GetColumnsWidth(*args, **kwargs): # real signature unknown
    pass

def HScrolledWindow_swiginit(*args, **kwargs): # real signature unknown
    pass

def HScrolledWindow_swigregister(*args, **kwargs): # real signature unknown
    pass

def HScrolledWindow__setCallbackInfo(*args, **kwargs): # real signature unknown
    pass

def HtmlListBox_Create(*args, **kwargs): # real signature unknown
    pass

def HtmlListBox_GetFileSystem(*args, **kwargs): # real signature unknown
    pass

def HtmlListBox_OnLinkClicked(*args, **kwargs): # real signature unknown
    pass

def HtmlListBox_SetItemCount(*args, **kwargs): # real signature unknown
    pass

def HtmlListBox_swiginit(*args, **kwargs): # real signature unknown
    pass

def HtmlListBox_swigregister(*args, **kwargs): # real signature unknown
    pass

def HtmlListBox__setCallbackInfo(*args, **kwargs): # real signature unknown
    pass

def HVScrolledWindow_Create(*args, **kwargs): # real signature unknown
    pass

def HVScrolledWindow_EstimateTotalHeight(*args, **kwargs): # real signature unknown
    pass

def HVScrolledWindow_EstimateTotalWidth(*args, **kwargs): # real signature unknown
    pass

def HVScrolledWindow_GetColumnsWidth(*args, **kwargs): # real signature unknown
    pass

def HVScrolledWindow_GetRowsHeight(*args, **kwargs): # real signature unknown
    pass

def HVScrolledWindow_swiginit(*args, **kwargs): # real signature unknown
    pass

def HVScrolledWindow_swigregister(*args, **kwargs): # real signature unknown
    pass

def HVScrolledWindow__setCallbackInfo(*args, **kwargs): # real signature unknown
    pass

def LayoutAlgorithm_LayoutFrame(*args, **kwargs): # real signature unknown
    pass

def LayoutAlgorithm_LayoutMDIFrame(*args, **kwargs): # real signature unknown
    pass

def LayoutAlgorithm_LayoutWindow(*args, **kwargs): # real signature unknown
    pass

def LayoutAlgorithm_swiginit(*args, **kwargs): # real signature unknown
    pass

def LayoutAlgorithm_swigregister(*args, **kwargs): # real signature unknown
    pass

def MDIChildFrame_Activate(*args, **kwargs): # real signature unknown
    pass

def MDIChildFrame_Create(*args, **kwargs): # real signature unknown
    pass

def MDIChildFrame_swiginit(*args, **kwargs): # real signature unknown
    pass

def MDIChildFrame_swigregister(*args, **kwargs): # real signature unknown
    pass

def MDIClientWindow_CreateClient(*args, **kwargs): # real signature unknown
    pass

def MDIClientWindow_swiginit(*args, **kwargs): # real signature unknown
    pass

def MDIClientWindow_swigregister(*args, **kwargs): # real signature unknown
    pass

def MDIParentFrame_ActivateNext(*args, **kwargs): # real signature unknown
    pass

def MDIParentFrame_ActivatePrevious(*args, **kwargs): # real signature unknown
    pass

def MDIParentFrame_ArrangeIcons(*args, **kwargs): # real signature unknown
    pass

def MDIParentFrame_Cascade(*args, **kwargs): # real signature unknown
    pass

def MDIParentFrame_Create(*args, **kwargs): # real signature unknown
    pass

def MDIParentFrame_GetActiveChild(*args, **kwargs): # real signature unknown
    pass

def MDIParentFrame_GetClientWindow(*args, **kwargs): # real signature unknown
    pass

def MDIParentFrame_swiginit(*args, **kwargs): # real signature unknown
    pass

def MDIParentFrame_swigregister(*args, **kwargs): # real signature unknown
    pass

def MDIParentFrame_Tile(*args, **kwargs): # real signature unknown
    pass

def MessageDialog_GetHelpLabel(*args, **kwargs): # real signature unknown
    pass

def MessageDialog_SetExtendedMessage(*args, **kwargs): # real signature unknown
    pass

def MessageDialog_SetHelpLabel(*args, **kwargs): # real signature unknown
    pass

def MessageDialog_SetMessage(*args, **kwargs): # real signature unknown
    pass

def MessageDialog_SetOKCancelLabels(*args, **kwargs): # real signature unknown
    pass

def MessageDialog_SetOKLabel(*args, **kwargs): # real signature unknown
    pass

def MessageDialog_SetYesNoCancelLabels(*args, **kwargs): # real signature unknown
    pass

def MessageDialog_SetYesNoLabels(*args, **kwargs): # real signature unknown
    pass

def MessageDialog_swiginit(*args, **kwargs): # real signature unknown
    pass

def MessageDialog_swigregister(*args, **kwargs): # real signature unknown
    pass

def MiniFrame_Create(*args, **kwargs): # real signature unknown
    pass

def MiniFrame_swiginit(*args, **kwargs): # real signature unknown
    pass

def MiniFrame_swigregister(*args, **kwargs): # real signature unknown
    pass

def MultiChoiceDialog_GetSelections(*args, **kwargs): # real signature unknown
    pass

def MultiChoiceDialog_SetSelections(*args, **kwargs): # real signature unknown
    pass

def MultiChoiceDialog_swiginit(*args, **kwargs): # real signature unknown
    pass

def MultiChoiceDialog_swigregister(*args, **kwargs): # real signature unknown
    pass

def new_CalculateLayoutEvent(*args, **kwargs): # real signature unknown
    pass

def new_ColourData(*args, **kwargs): # real signature unknown
    pass

def new_ColourDialog(*args, **kwargs): # real signature unknown
    pass

def new_Dialog(*args, **kwargs): # real signature unknown
    pass

def new_DirDialog(*args, **kwargs): # real signature unknown
    pass

def new_FileDialog(*args, **kwargs): # real signature unknown
    pass

def new_FindDialogEvent(*args, **kwargs): # real signature unknown
    pass

def new_FindReplaceData(*args, **kwargs): # real signature unknown
    pass

def new_FindReplaceDialog(*args, **kwargs): # real signature unknown
    pass

def new_FontData(*args, **kwargs): # real signature unknown
    pass

def new_FontDialog(*args, **kwargs): # real signature unknown
    pass

def new_Frame(*args, **kwargs): # real signature unknown
    pass

def new_GenericProgressDialog(*args, **kwargs): # real signature unknown
    pass

def new_HScrolledWindow(*args, **kwargs): # real signature unknown
    pass

def new_HtmlListBox(*args, **kwargs): # real signature unknown
    pass

def new_HVScrolledWindow(*args, **kwargs): # real signature unknown
    pass

def new_LayoutAlgorithm(*args, **kwargs): # real signature unknown
    pass

def new_MDIChildFrame(*args, **kwargs): # real signature unknown
    pass

def new_MDIClientWindow(*args, **kwargs): # real signature unknown
    pass

def new_MDIParentFrame(*args, **kwargs): # real signature unknown
    pass

def new_MessageDialog(*args, **kwargs): # real signature unknown
    pass

def new_MiniFrame(*args, **kwargs): # real signature unknown
    pass

def new_MultiChoiceDialog(*args, **kwargs): # real signature unknown
    pass

def new_NumberEntryDialog(*args, **kwargs): # real signature unknown
    pass

def new_PageSetupDialog(*args, **kwargs): # real signature unknown
    pass

def new_PageSetupDialogData(*args, **kwargs): # real signature unknown
    pass

def new_Panel(*args, **kwargs): # real signature unknown
    pass

def new_PasswordEntryDialog(*args, **kwargs): # real signature unknown
    pass

def new_PopupTransientWindow(*args, **kwargs): # real signature unknown
    pass

def new_PopupWindow(*args, **kwargs): # real signature unknown
    pass

def new_PreDialog(*args, **kwargs): # real signature unknown
    pass

def new_PreFindReplaceDialog(*args, **kwargs): # real signature unknown
    pass

def new_PreFrame(*args, **kwargs): # real signature unknown
    pass

def new_PreHScrolledWindow(*args, **kwargs): # real signature unknown
    pass

def new_PreHtmlListBox(*args, **kwargs): # real signature unknown
    pass

def new_PreHVScrolledWindow(*args, **kwargs): # real signature unknown
    pass

def new_PreMDIChildFrame(*args, **kwargs): # real signature unknown
    pass

def new_PreMDIClientWindow(*args, **kwargs): # real signature unknown
    pass

def new_PreMDIParentFrame(*args, **kwargs): # real signature unknown
    pass

def new_PreMiniFrame(*args, **kwargs): # real signature unknown
    pass

def new_PrePanel(*args, **kwargs): # real signature unknown
    pass

def new_PrePopupTransientWindow(*args, **kwargs): # real signature unknown
    pass

def new_PrePopupWindow(*args, **kwargs): # real signature unknown
    pass

def new_PrePyPanel(*args, **kwargs): # real signature unknown
    pass

def new_PrePyScrolledWindow(*args, **kwargs): # real signature unknown
    pass

def new_PrePyWindow(*args, **kwargs): # real signature unknown
    pass

def new_PreSashLayoutWindow(*args, **kwargs): # real signature unknown
    pass

def new_PreSashWindow(*args, **kwargs): # real signature unknown
    pass

def new_PreScrolledWindow(*args, **kwargs): # real signature unknown
    pass

def new_PreSimpleHtmlListBox(*args, **kwargs): # real signature unknown
    pass

def new_PreSplitterWindow(*args, **kwargs): # real signature unknown
    pass

def new_PreStatusBar(*args, **kwargs): # real signature unknown
    pass

def new_PreviewCanvas(*args, **kwargs): # real signature unknown
    pass

def new_PreviewControlBar(*args, **kwargs): # real signature unknown
    pass

def new_PreviewFrame(*args, **kwargs): # real signature unknown
    pass

def new_PreVListBox(*args, **kwargs): # real signature unknown
    pass

def new_PreVScrolledWindow(*args, **kwargs): # real signature unknown
    pass

def new_PrintData(*args, **kwargs): # real signature unknown
    pass

def new_PrintDialog(*args, **kwargs): # real signature unknown
    pass

def new_PrintDialogData(*args, **kwargs): # real signature unknown
    pass

def new_Printer(*args, **kwargs): # real signature unknown
    pass

def new_Printout(*args, **kwargs): # real signature unknown
    pass

def new_PrintPreview(*args, **kwargs): # real signature unknown
    pass

def new_ProgressDialog(*args, **kwargs): # real signature unknown
    pass

def new_PyPanel(*args, **kwargs): # real signature unknown
    pass

def new_PyPreviewControlBar(*args, **kwargs): # real signature unknown
    pass

def new_PyPreviewFrame(*args, **kwargs): # real signature unknown
    pass

def new_PyPrintPreview(*args, **kwargs): # real signature unknown
    pass

def new_PyScrolledWindow(*args, **kwargs): # real signature unknown
    pass

def new_PyWindow(*args, **kwargs): # real signature unknown
    pass

def new_QueryLayoutInfoEvent(*args, **kwargs): # real signature unknown
    pass

def new_SashEvent(*args, **kwargs): # real signature unknown
    pass

def new_SashLayoutWindow(*args, **kwargs): # real signature unknown
    pass

def new_SashWindow(*args, **kwargs): # real signature unknown
    pass

def new_ScrolledWindow(*args, **kwargs): # real signature unknown
    pass

def new_ScrollHelper(*args, **kwargs): # real signature unknown
    pass

def new_SimpleHtmlListBox(*args, **kwargs): # real signature unknown
    pass

def new_SingleChoiceDialog(*args, **kwargs): # real signature unknown
    pass

def new_SplashScreen(*args, **kwargs): # real signature unknown
    pass

def new_SplashScreenWindow(*args, **kwargs): # real signature unknown
    pass

def new_SplitterEvent(*args, **kwargs): # real signature unknown
    pass

def new_SplitterWindow(*args, **kwargs): # real signature unknown
    pass

def new_StandardDialogLayoutAdapter(*args, **kwargs): # real signature unknown
    pass

def new_StatusBar(*args, **kwargs): # real signature unknown
    pass

def new_StatusBarPane(*args, **kwargs): # real signature unknown
    pass

def new_TaskBarIcon(*args, **kwargs): # real signature unknown
    pass

def new_TaskBarIconEvent(*args, **kwargs): # real signature unknown
    pass

def new_TextEntryDialog(*args, **kwargs): # real signature unknown
    pass

def new_TipWindow(*args, **kwargs): # real signature unknown
    pass

def new_VListBox(*args, **kwargs): # real signature unknown
    pass

def new_VScrolledWindow(*args, **kwargs): # real signature unknown
    pass

def new_WindowModalDialogEvent(*args, **kwargs): # real signature unknown
    pass

def NumberEntryDialog_GetValue(*args, **kwargs): # real signature unknown
    pass

def NumberEntryDialog_swiginit(*args, **kwargs): # real signature unknown
    pass

def NumberEntryDialog_swigregister(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_CalculateIdFromPaperSize(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_CalculatePaperSizeFromId(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_EnableHelp(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_EnableMargins(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_EnableOrientation(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_EnablePaper(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_EnablePrinter(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_GetDefaultInfo(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_GetDefaultMinMargins(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_GetEnableHelp(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_GetEnableMargins(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_GetEnableOrientation(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_GetEnablePaper(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_GetEnablePrinter(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_GetMarginBottomRight(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_GetMarginTopLeft(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_GetMinMarginBottomRight(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_GetMinMarginTopLeft(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_GetPaperId(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_GetPaperSize(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_GetPrintData(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_IsOk(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_SetDefaultInfo(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_SetDefaultMinMargins(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_SetMarginBottomRight(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_SetMarginTopLeft(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_SetMinMarginBottomRight(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_SetMinMarginTopLeft(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_SetPaperId(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_SetPaperSize(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_SetPrintData(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_swiginit(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialogData_swigregister(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialog_GetPageSetupData(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialog_GetPageSetupDialogData(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialog_ShowModal(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialog_swiginit(*args, **kwargs): # real signature unknown
    pass

def PageSetupDialog_swigregister(*args, **kwargs): # real signature unknown
    pass

def Panel_Create(*args, **kwargs): # real signature unknown
    pass

def Panel_GetClassDefaultAttributes(*args, **kwargs): # real signature unknown
    pass

def Panel_SetFocusIgnoringChildren(*args, **kwargs): # real signature unknown
    pass

def Panel_swiginit(*args, **kwargs): # real signature unknown
    pass

def Panel_swigregister(*args, **kwargs): # real signature unknown
    pass

def PasswordEntryDialog_swiginit(*args, **kwargs): # real signature unknown
    pass

def PasswordEntryDialog_swigregister(*args, **kwargs): # real signature unknown
    pass

def PopupTransientWindow_CanDismiss(*args, **kwargs): # real signature unknown
    pass

def PopupTransientWindow_Dismiss(*args, **kwargs): # real signature unknown
    pass

def PopupTransientWindow_Popup(*args, **kwargs): # real signature unknown
    pass

def PopupTransientWindow_ProcessLeftDown(*args, **kwargs): # real signature unknown
    pass

def PopupTransientWindow_swiginit(*args, **kwargs): # real signature unknown
    pass

def PopupTransientWindow_swigregister(*args, **kwargs): # real signature unknown
    pass

def PopupTransientWindow__setCallbackInfo(*args, **kwargs): # real signature unknown
    pass

def PopupWindow_Create(*args, **kwargs): # real signature unknown
    pass

def PopupWindow_Position(*args, **kwargs): # real signature unknown
    pass

def PopupWindow_swiginit(*args, **kwargs): # real signature unknown
    pass

def PopupWindow_swigregister(*args, **kwargs): # real signature unknown
    pass

def PreviewCanvas_SetPreview(*args, **kwargs): # real signature unknown
    pass

def PreviewCanvas_swiginit(*args, **kwargs): # real signature unknown
    pass

def PreviewCanvas_swigregister(*args, **kwargs): # real signature unknown
    pass

def PreviewControlBar_GetPrintPreview(*args, **kwargs): # real signature unknown
    pass

def PreviewControlBar_GetZoomControl(*args, **kwargs): # real signature unknown
    pass

def PreviewControlBar_SetPageInfo(*args, **kwargs): # real signature unknown
    pass

def PreviewControlBar_SetZoomControl(*args, **kwargs): # real signature unknown
    pass

def PreviewControlBar_swiginit(*args, **kwargs): # real signature unknown
    pass

def PreviewControlBar_swigregister(*args, **kwargs): # real signature unknown
    pass

def PreviewFrame_CreateCanvas(*args, **kwargs): # real signature unknown
    pass

def PreviewFrame_CreateControlBar(*args, **kwargs): # real signature unknown
    pass

def PreviewFrame_GetControlBar(*args, **kwargs): # real signature unknown
    pass

def PreviewFrame_Initialize(*args, **kwargs): # real signature unknown
    pass

def PreviewFrame_InitializeWithModality(*args, **kwargs): # real signature unknown
    pass

def PreviewFrame_swiginit(*args, **kwargs): # real signature unknown
    pass

def PreviewFrame_swigregister(*args, **kwargs): # real signature unknown
    pass

def PrintData_GetBin(*args, **kwargs): # real signature unknown
    pass

def PrintData_GetCollate(*args, **kwargs): # real signature unknown
    pass

def PrintData_GetColour(*args, **kwargs): # real signature unknown
    pass

def PrintData_GetDuplex(*args, **kwargs): # real signature unknown
    pass

def PrintData_GetFilename(*args, **kwargs): # real signature unknown
    pass

def PrintData_GetMedia(*args, **kwargs): # real signature unknown
    pass

def PrintData_GetNoCopies(*args, **kwargs): # real signature unknown
    pass

def PrintData_GetOrientation(*args, **kwargs): # real signature unknown
    pass

def PrintData_GetPaperId(*args, **kwargs): # real signature unknown
    pass

def PrintData_GetPaperSize(*args, **kwargs): # real signature unknown
    pass

def PrintData_GetPrinterName(*args, **kwargs): # real signature unknown
    pass

def PrintData_GetPrintMode(*args, **kwargs): # real signature unknown
    pass

def PrintData_GetPrivData(*args, **kwargs): # real signature unknown
    pass

def PrintData_GetQuality(*args, **kwargs): # real signature unknown
    pass

def PrintData_IsOk(*args, **kwargs): # real signature unknown
    pass

def PrintData_IsOrientationReversed(*args, **kwargs): # real signature unknown
    pass

def PrintData_SetBin(*args, **kwargs): # real signature unknown
    pass

def PrintData_SetCollate(*args, **kwargs): # real signature unknown
    pass

def PrintData_SetColour(*args, **kwargs): # real signature unknown
    pass

def PrintData_SetDuplex(*args, **kwargs): # real signature unknown
    pass

def PrintData_SetFilename(*args, **kwargs): # real signature unknown
    pass

def PrintData_SetMedia(*args, **kwargs): # real signature unknown
    pass

def PrintData_SetNoCopies(*args, **kwargs): # real signature unknown
    pass

def PrintData_SetOrientation(*args, **kwargs): # real signature unknown
    pass

def PrintData_SetOrientationReversed(*args, **kwargs): # real signature unknown
    pass

def PrintData_SetPaperId(*args, **kwargs): # real signature unknown
    pass

def PrintData_SetPaperSize(*args, **kwargs): # real signature unknown
    pass

def PrintData_SetPrinterName(*args, **kwargs): # real signature unknown
    pass

def PrintData_SetPrintMode(*args, **kwargs): # real signature unknown
    pass

def PrintData_SetPrivData(*args, **kwargs): # real signature unknown
    pass

def PrintData_SetQuality(*args, **kwargs): # real signature unknown
    pass

def PrintData_swiginit(*args, **kwargs): # real signature unknown
    pass

def PrintData_swigregister(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_EnableHelp(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_EnablePageNumbers(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_EnablePrintToFile(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_EnableSelection(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_GetAllPages(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_GetCollate(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_GetEnableHelp(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_GetEnablePageNumbers(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_GetEnablePrintToFile(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_GetEnableSelection(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_GetFromPage(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_GetMaxPage(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_GetMinPage(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_GetNoCopies(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_GetPrintData(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_GetPrintToFile(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_GetSelection(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_GetToPage(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_IsOk(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_SetAllPages(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_SetCollate(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_SetFromPage(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_SetMaxPage(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_SetMinPage(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_SetNoCopies(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_SetPrintData(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_SetPrintToFile(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_SetSelection(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_SetToPage(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_swiginit(*args, **kwargs): # real signature unknown
    pass

def PrintDialogData_swigregister(*args, **kwargs): # real signature unknown
    pass

def PrintDialog_GetPrintData(*args, **kwargs): # real signature unknown
    pass

def PrintDialog_GetPrintDC(*args, **kwargs): # real signature unknown
    pass

def PrintDialog_GetPrintDialogData(*args, **kwargs): # real signature unknown
    pass

def PrintDialog_ShowModal(*args, **kwargs): # real signature unknown
    pass

def PrintDialog_swiginit(*args, **kwargs): # real signature unknown
    pass

def PrintDialog_swigregister(*args, **kwargs): # real signature unknown
    pass

def Printer_CreateAbortWindow(*args, **kwargs): # real signature unknown
    pass

def Printer_GetAbort(*args, **kwargs): # real signature unknown
    pass

def Printer_GetLastError(*args, **kwargs): # real signature unknown
    pass

def Printer_GetPrintDialogData(*args, **kwargs): # real signature unknown
    pass

def Printer_Print(*args, **kwargs): # real signature unknown
    pass

def Printer_PrintDialog(*args, **kwargs): # real signature unknown
    pass

def Printer_ReportError(*args, **kwargs): # real signature unknown
    pass

def Printer_Setup(*args, **kwargs): # real signature unknown
    pass

def Printer_swiginit(*args, **kwargs): # real signature unknown
    pass

def Printer_swigregister(*args, **kwargs): # real signature unknown
    pass

def Printout_FitThisSizeToPage(*args, **kwargs): # real signature unknown
    pass

def Printout_FitThisSizeToPageMargins(*args, **kwargs): # real signature unknown
    pass

def Printout_FitThisSizeToPaper(*args, **kwargs): # real signature unknown
    pass

def Printout_GetDC(*args, **kwargs): # real signature unknown
    pass

def Printout_GetLogicalPageMarginsRect(*args, **kwargs): # real signature unknown
    pass

def Printout_GetLogicalPageRect(*args, **kwargs): # real signature unknown
    pass

def Printout_GetLogicalPaperRect(*args, **kwargs): # real signature unknown
    pass

def Printout_GetPageInfo(*args, **kwargs): # real signature unknown
    pass

def Printout_GetPageSizeMM(*args, **kwargs): # real signature unknown
    pass

def Printout_GetPageSizePixels(*args, **kwargs): # real signature unknown
    pass

def Printout_GetPaperRectPixels(*args, **kwargs): # real signature unknown
    pass

def Printout_GetPPIPrinter(*args, **kwargs): # real signature unknown
    pass

def Printout_GetPPIScreen(*args, **kwargs): # real signature unknown
    pass

def Printout_GetPreview(*args, **kwargs): # real signature unknown
    pass

def Printout_GetTitle(*args, **kwargs): # real signature unknown
    pass

def Printout_HasPage(*args, **kwargs): # real signature unknown
    pass

def Printout_IsPreview(*args, **kwargs): # real signature unknown
    pass

def Printout_MapScreenSizeToDevice(*args, **kwargs): # real signature unknown
    pass

def Printout_MapScreenSizeToPage(*args, **kwargs): # real signature unknown
    pass

def Printout_MapScreenSizeToPageMargins(*args, **kwargs): # real signature unknown
    pass

def Printout_MapScreenSizeToPaper(*args, **kwargs): # real signature unknown
    pass

def Printout_OffsetLogicalOrigin(*args, **kwargs): # real signature unknown
    pass

def Printout_OnBeginDocument(*args, **kwargs): # real signature unknown
    pass

def Printout_OnBeginPrinting(*args, **kwargs): # real signature unknown
    pass

def Printout_OnEndDocument(*args, **kwargs): # real signature unknown
    pass

def Printout_OnEndPrinting(*args, **kwargs): # real signature unknown
    pass

def Printout_OnPreparePrinting(*args, **kwargs): # real signature unknown
    pass

def Printout_SetDC(*args, **kwargs): # real signature unknown
    pass

def Printout_SetLogicalOrigin(*args, **kwargs): # real signature unknown
    pass

def Printout_SetPageSizeMM(*args, **kwargs): # real signature unknown
    pass

def Printout_SetPageSizePixels(*args, **kwargs): # real signature unknown
    pass

def Printout_SetPaperRectPixels(*args, **kwargs): # real signature unknown
    pass

def Printout_SetPPIPrinter(*args, **kwargs): # real signature unknown
    pass

def Printout_SetPPIScreen(*args, **kwargs): # real signature unknown
    pass

def Printout_SetPreview(*args, **kwargs): # real signature unknown
    pass

def Printout_swiginit(*args, **kwargs): # real signature unknown
    pass

def Printout_swigregister(*args, **kwargs): # real signature unknown
    pass

def Printout__setCallbackInfo(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_AdjustScrollbars(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_DetermineScaling(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_DrawBlankPage(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_GetCanvas(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_GetCurrentPage(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_GetFrame(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_GetMaxPage(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_GetMinPage(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_GetPrintDialogData(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_GetPrintout(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_GetPrintoutForPrinting(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_GetZoom(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_IsOk(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_PaintPage(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_Print(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_RenderPage(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_SetCanvas(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_SetCurrentPage(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_SetFrame(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_SetOk(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_SetPrintout(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_SetZoom(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_swiginit(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_swigregister(*args, **kwargs): # real signature unknown
    pass

def PrintPreview_UpdatePageRendering(*args, **kwargs): # real signature unknown
    pass

def ProgressDialog_swiginit(*args, **kwargs): # real signature unknown
    pass

def ProgressDialog_swigregister(*args, **kwargs): # real signature unknown
    pass

def PyPanel_DoEraseBackground(*args, **kwargs): # real signature unknown
    pass

def PyPanel_DoGetBestSize(*args, **kwargs): # real signature unknown
    pass

def PyPanel_DoGetClientSize(*args, **kwargs): # real signature unknown
    pass

def PyPanel_DoGetPosition(*args, **kwargs): # real signature unknown
    pass

def PyPanel_DoGetSize(*args, **kwargs): # real signature unknown
    pass

def PyPanel_DoGetVirtualSize(*args, **kwargs): # real signature unknown
    pass

def PyPanel_DoMoveWindow(*args, **kwargs): # real signature unknown
    pass

def PyPanel_DoSetClientSize(*args, **kwargs): # real signature unknown
    pass

def PyPanel_DoSetSize(*args, **kwargs): # real signature unknown
    pass

def PyPanel_DoSetVirtualSize(*args, **kwargs): # real signature unknown
    pass

def PyPanel_GetDefaultAttributes(*args, **kwargs): # real signature unknown
    pass

def PyPanel_OnInternalIdle(*args, **kwargs): # real signature unknown
    pass

def PyPanel_swiginit(*args, **kwargs): # real signature unknown
    pass

def PyPanel_swigregister(*args, **kwargs): # real signature unknown
    pass

def PyPanel__setCallbackInfo(*args, **kwargs): # real signature unknown
    pass

def PyPreviewControlBar_CreateButtons(*args, **kwargs): # real signature unknown
    pass

def PyPreviewControlBar_SetPrintPreview(*args, **kwargs): # real signature unknown
    pass

def PyPreviewControlBar_SetZoomControl(*args, **kwargs): # real signature unknown
    pass

def PyPreviewControlBar_swiginit(*args, **kwargs): # real signature unknown
    pass

def PyPreviewControlBar_swigregister(*args, **kwargs): # real signature unknown
    pass

def PyPreviewControlBar__setCallbackInfo(*args, **kwargs): # real signature unknown
    pass

def PyPreviewFrame_CreateCanvas(*args, **kwargs): # real signature unknown
    pass

def PyPreviewFrame_CreateControlBar(*args, **kwargs): # real signature unknown
    pass

def PyPreviewFrame_Initialize(*args, **kwargs): # real signature unknown
    pass

def PyPreviewFrame_InitializeWithModality(*args, **kwargs): # real signature unknown
    pass

def PyPreviewFrame_SetControlBar(*args, **kwargs): # real signature unknown
    pass

def PyPreviewFrame_SetPreviewCanvas(*args, **kwargs): # real signature unknown
    pass

def PyPreviewFrame_swiginit(*args, **kwargs): # real signature unknown
    pass

def PyPreviewFrame_swigregister(*args, **kwargs): # real signature unknown
    pass

def PyPreviewFrame__setCallbackInfo(*args, **kwargs): # real signature unknown
    pass

def PyPrintPreview_swiginit(*args, **kwargs): # real signature unknown
    pass

def PyPrintPreview_swigregister(*args, **kwargs): # real signature unknown
    pass

def PyPrintPreview__setCallbackInfo(*args, **kwargs): # real signature unknown
    pass

def PyScrolledWindow_DoEraseBackground(*args, **kwargs): # real signature unknown
    pass

def PyScrolledWindow_DoGetBestSize(*args, **kwargs): # real signature unknown
    pass

def PyScrolledWindow_DoGetClientSize(*args, **kwargs): # real signature unknown
    pass

def PyScrolledWindow_DoGetPosition(*args, **kwargs): # real signature unknown
    pass

def PyScrolledWindow_DoGetSize(*args, **kwargs): # real signature unknown
    pass

def PyScrolledWindow_DoGetVirtualSize(*args, **kwargs): # real signature unknown
    pass

def PyScrolledWindow_DoMoveWindow(*args, **kwargs): # real signature unknown
    pass

def PyScrolledWindow_DoSetClientSize(*args, **kwargs): # real signature unknown
    pass

def PyScrolledWindow_DoSetSize(*args, **kwargs): # real signature unknown
    pass

def PyScrolledWindow_DoSetVirtualSize(*args, **kwargs): # real signature unknown
    pass

def PyScrolledWindow_GetDefaultAttributes(*args, **kwargs): # real signature unknown
    pass

def PyScrolledWindow_OnInternalIdle(*args, **kwargs): # real signature unknown
    pass

def PyScrolledWindow_swiginit(*args, **kwargs): # real signature unknown
    pass

def PyScrolledWindow_swigregister(*args, **kwargs): # real signature unknown
    pass

def PyScrolledWindow__setCallbackInfo(*args, **kwargs): # real signature unknown
    pass

def PyWindow_DoEraseBackground(*args, **kwargs): # real signature unknown
    pass

def PyWindow_DoGetBestSize(*args, **kwargs): # real signature unknown
    pass

def PyWindow_DoGetClientSize(*args, **kwargs): # real signature unknown
    pass

def PyWindow_DoGetPosition(*args, **kwargs): # real signature unknown
    pass

def PyWindow_DoGetSize(*args, **kwargs): # real signature unknown
    pass

def PyWindow_DoGetVirtualSize(*args, **kwargs): # real signature unknown
    pass

def PyWindow_DoMoveWindow(*args, **kwargs): # real signature unknown
    pass

def PyWindow_DoSetClientSize(*args, **kwargs): # real signature unknown
    pass

def PyWindow_DoSetSize(*args, **kwargs): # real signature unknown
    pass

def PyWindow_DoSetVirtualSize(*args, **kwargs): # real signature unknown
    pass

def PyWindow_GetDefaultAttributes(*args, **kwargs): # real signature unknown
    pass

def PyWindow_OnInternalIdle(*args, **kwargs): # real signature unknown
    pass

def PyWindow_swiginit(*args, **kwargs): # real signature unknown
    pass

def PyWindow_swigregister(*args, **kwargs): # real signature unknown
    pass

def PyWindow__setCallbackInfo(*args, **kwargs): # real signature unknown
    pass

def QueryLayoutInfoEvent_GetAlignment(*args, **kwargs): # real signature unknown
    pass

def QueryLayoutInfoEvent_GetFlags(*args, **kwargs): # real signature unknown
    pass

def QueryLayoutInfoEvent_GetOrientation(*args, **kwargs): # real signature unknown
    pass

def QueryLayoutInfoEvent_GetRequestedLength(*args, **kwargs): # real signature unknown
    pass

def QueryLayoutInfoEvent_GetSize(*args, **kwargs): # real signature unknown
    pass

def QueryLayoutInfoEvent_SetAlignment(*args, **kwargs): # real signature unknown
    pass

def QueryLayoutInfoEvent_SetFlags(*args, **kwargs): # real signature unknown
    pass

def QueryLayoutInfoEvent_SetOrientation(*args, **kwargs): # real signature unknown
    pass

def QueryLayoutInfoEvent_SetRequestedLength(*args, **kwargs): # real signature unknown
    pass

def QueryLayoutInfoEvent_SetSize(*args, **kwargs): # real signature unknown
    pass

def QueryLayoutInfoEvent_swiginit(*args, **kwargs): # real signature unknown
    pass

def QueryLayoutInfoEvent_swigregister(*args, **kwargs): # real signature unknown
    pass

def SashEvent_GetDragRect(*args, **kwargs): # real signature unknown
    pass

def SashEvent_GetDragStatus(*args, **kwargs): # real signature unknown
    pass

def SashEvent_GetEdge(*args, **kwargs): # real signature unknown
    pass

def SashEvent_SetDragRect(*args, **kwargs): # real signature unknown
    pass

def SashEvent_SetDragStatus(*args, **kwargs): # real signature unknown
    pass

def SashEvent_SetEdge(*args, **kwargs): # real signature unknown
    pass

def SashEvent_swiginit(*args, **kwargs): # real signature unknown
    pass

def SashEvent_swigregister(*args, **kwargs): # real signature unknown
    pass

def SashLayoutWindow_Create(*args, **kwargs): # real signature unknown
    pass

def SashLayoutWindow_GetAlignment(*args, **kwargs): # real signature unknown
    pass

def SashLayoutWindow_GetOrientation(*args, **kwargs): # real signature unknown
    pass

def SashLayoutWindow_SetAlignment(*args, **kwargs): # real signature unknown
    pass

def SashLayoutWindow_SetDefaultSize(*args, **kwargs): # real signature unknown
    pass

def SashLayoutWindow_SetOrientation(*args, **kwargs): # real signature unknown
    pass

def SashLayoutWindow_swiginit(*args, **kwargs): # real signature unknown
    pass

def SashLayoutWindow_swigregister(*args, **kwargs): # real signature unknown
    pass

def SashWindow_Create(*args, **kwargs): # real signature unknown
    pass

def SashWindow_GetDefaultBorderSize(*args, **kwargs): # real signature unknown
    pass

def SashWindow_GetEdgeMargin(*args, **kwargs): # real signature unknown
    pass

def SashWindow_GetExtraBorderSize(*args, **kwargs): # real signature unknown
    pass

def SashWindow_GetMaximumSizeX(*args, **kwargs): # real signature unknown
    pass

def SashWindow_GetMaximumSizeY(*args, **kwargs): # real signature unknown
    pass

def SashWindow_GetMinimumSizeX(*args, **kwargs): # real signature unknown
    pass

def SashWindow_GetMinimumSizeY(*args, **kwargs): # real signature unknown
    pass

def SashWindow_GetSashVisible(*args, **kwargs): # real signature unknown
    pass

def SashWindow_SashHitTest(*args, **kwargs): # real signature unknown
    pass

def SashWindow_SetDefaultBorderSize(*args, **kwargs): # real signature unknown
    pass

def SashWindow_SetExtraBorderSize(*args, **kwargs): # real signature unknown
    pass

def SashWindow_SetMaximumSizeX(*args, **kwargs): # real signature unknown
    pass

def SashWindow_SetMaximumSizeY(*args, **kwargs): # real signature unknown
    pass

def SashWindow_SetMinimumSizeX(*args, **kwargs): # real signature unknown
    pass

def SashWindow_SetMinimumSizeY(*args, **kwargs): # real signature unknown
    pass

def SashWindow_SetSashVisible(*args, **kwargs): # real signature unknown
    pass

def SashWindow_SizeWindows(*args, **kwargs): # real signature unknown
    pass

def SashWindow_swiginit(*args, **kwargs): # real signature unknown
    pass

def SashWindow_swigregister(*args, **kwargs): # real signature unknown
    pass

def ScrolledWindow_Create(*args, **kwargs): # real signature unknown
    pass

def ScrolledWindow_GetClassDefaultAttributes(*args, **kwargs): # real signature unknown
    pass

def ScrolledWindow_swiginit(*args, **kwargs): # real signature unknown
    pass

def ScrolledWindow_swigregister(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_AdjustScrollbars(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_CalcScrolledPosition(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_CalcScrollInc(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_CalcUnscrolledPosition(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_DisableKeyboardScrolling(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_DoPrepareDC(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_EnableScrolling(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_GetScaleX(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_GetScaleY(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_GetScrollLines(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_GetScrollPageSize(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_GetScrollPixelsPerUnit(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_GetTargetRect(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_GetTargetWindow(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_GetViewStart(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_IsAutoScrolling(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_Scroll(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_SendAutoScrollEvents(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_SetScale(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_SetScrollbars(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_SetScrollPageSize(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_SetScrollRate(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_SetTargetRect(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_SetTargetWindow(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_ShowScrollbars(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_StopAutoScrolling(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_swiginit(*args, **kwargs): # real signature unknown
    pass

def ScrollHelper_swigregister(*args, **kwargs): # real signature unknown
    pass

def SimpleHtmlListBox_Create(*args, **kwargs): # real signature unknown
    pass

def SimpleHtmlListBox_swiginit(*args, **kwargs): # real signature unknown
    pass

def SimpleHtmlListBox_swigregister(*args, **kwargs): # real signature unknown
    pass

def SimpleHtmlListBox__Clear(*args, **kwargs): # real signature unknown
    pass

def SingleChoiceDialog_GetSelection(*args, **kwargs): # real signature unknown
    pass

def SingleChoiceDialog_GetStringSelection(*args, **kwargs): # real signature unknown
    pass

def SingleChoiceDialog_SetSelection(*args, **kwargs): # real signature unknown
    pass

def SingleChoiceDialog_swiginit(*args, **kwargs): # real signature unknown
    pass

def SingleChoiceDialog_swigregister(*args, **kwargs): # real signature unknown
    pass

def SplashScreenWindow_GetBitmap(*args, **kwargs): # real signature unknown
    pass

def SplashScreenWindow_SetBitmap(*args, **kwargs): # real signature unknown
    pass

def SplashScreenWindow_swiginit(*args, **kwargs): # real signature unknown
    pass

def SplashScreenWindow_swigregister(*args, **kwargs): # real signature unknown
    pass

def SplashScreen_GetSplashStyle(*args, **kwargs): # real signature unknown
    pass

def SplashScreen_GetSplashWindow(*args, **kwargs): # real signature unknown
    pass

def SplashScreen_GetTimeout(*args, **kwargs): # real signature unknown
    pass

def SplashScreen_swiginit(*args, **kwargs): # real signature unknown
    pass

def SplashScreen_swigregister(*args, **kwargs): # real signature unknown
    pass

def SplitterEvent_GetSashPosition(*args, **kwargs): # real signature unknown
    pass

def SplitterEvent_GetWindowBeingRemoved(*args, **kwargs): # real signature unknown
    pass

def SplitterEvent_GetX(*args, **kwargs): # real signature unknown
    pass

def SplitterEvent_GetY(*args, **kwargs): # real signature unknown
    pass

def SplitterEvent_SetSashPosition(*args, **kwargs): # real signature unknown
    pass

def SplitterEvent_swiginit(*args, **kwargs): # real signature unknown
    pass

def SplitterEvent_swigregister(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_Create(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_GetBorderSize(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_GetClassDefaultAttributes(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_GetMinimumPaneSize(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_GetSashGravity(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_GetSashPosition(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_GetSashSize(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_GetSplitMode(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_GetWindow1(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_GetWindow2(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_Initialize(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_IsSashInvisible(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_IsSplit(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_ReplaceWindow(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_SashHitTest(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_SetBorderSize(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_SetMinimumPaneSize(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_SetSashGravity(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_SetSashInvisible(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_SetSashPosition(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_SetSashSize(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_SetSplitMode(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_SizeWindows(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_SplitHorizontally(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_SplitVertically(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_swiginit(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_swigregister(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_Unsplit(*args, **kwargs): # real signature unknown
    pass

def SplitterWindow_UpdateSize(*args, **kwargs): # real signature unknown
    pass

def StandardDialogLayoutAdapter_CreateScrolledWindow(*args, **kwargs): # real signature unknown
    pass

def StandardDialogLayoutAdapter_DoFitWithScrolling(*args, **kwargs): # real signature unknown
    pass

def StandardDialogLayoutAdapter_DoMustScroll(*args, **kwargs): # real signature unknown
    pass

def StandardDialogLayoutAdapter_DoReparentControls(*args, **kwargs): # real signature unknown
    pass

def StandardDialogLayoutAdapter_FindButtonSizer(*args, **kwargs): # real signature unknown
    pass

def StandardDialogLayoutAdapter_FindLooseButtons(*args, **kwargs): # real signature unknown
    pass

def StandardDialogLayoutAdapter_FitWithScrolling(*args, **kwargs): # real signature unknown
    pass

def StandardDialogLayoutAdapter_IsOrdinaryButtonSizer(*args, **kwargs): # real signature unknown
    pass

def StandardDialogLayoutAdapter_IsStandardButton(*args, **kwargs): # real signature unknown
    pass

def StandardDialogLayoutAdapter_MustScroll(*args, **kwargs): # real signature unknown
    pass

def StandardDialogLayoutAdapter_ReparentControls(*args, **kwargs): # real signature unknown
    pass

def StandardDialogLayoutAdapter_swiginit(*args, **kwargs): # real signature unknown
    pass

def StandardDialogLayoutAdapter_swigregister(*args, **kwargs): # real signature unknown
    pass

def StatusBarPane_GetStyle(*args, **kwargs): # real signature unknown
    pass

def StatusBarPane_GetText(*args, **kwargs): # real signature unknown
    pass

def StatusBarPane_GetWidth(*args, **kwargs): # real signature unknown
    pass

def StatusBarPane_IsEllipsized(*args, **kwargs): # real signature unknown
    pass

def StatusBarPane_PopText(*args, **kwargs): # real signature unknown
    pass

def StatusBarPane_PushText(*args, **kwargs): # real signature unknown
    pass

def StatusBarPane_SetIsEllipsized(*args, **kwargs): # real signature unknown
    pass

def StatusBarPane_SetStyle(*args, **kwargs): # real signature unknown
    pass

def StatusBarPane_SetText(*args, **kwargs): # real signature unknown
    pass

def StatusBarPane_SetWidth(*args, **kwargs): # real signature unknown
    pass

def StatusBarPane_swiginit(*args, **kwargs): # real signature unknown
    pass

def StatusBarPane_swigregister(*args, **kwargs): # real signature unknown
    pass

def StatusBar_Create(*args, **kwargs): # real signature unknown
    pass

def StatusBar_GetBorders(*args, **kwargs): # real signature unknown
    pass

def StatusBar_GetBorderX(*args, **kwargs): # real signature unknown
    pass

def StatusBar_GetBorderY(*args, **kwargs): # real signature unknown
    pass

def StatusBar_GetClassDefaultAttributes(*args, **kwargs): # real signature unknown
    pass

def StatusBar_GetField(*args, **kwargs): # real signature unknown
    pass

def StatusBar_GetFieldRect(*args, **kwargs): # real signature unknown
    pass

def StatusBar_GetFieldsCount(*args, **kwargs): # real signature unknown
    pass

def StatusBar_GetStatusStyle(*args, **kwargs): # real signature unknown
    pass

def StatusBar_GetStatusText(*args, **kwargs): # real signature unknown
    pass

def StatusBar_GetStatusWidth(*args, **kwargs): # real signature unknown
    pass

def StatusBar_PopStatusText(*args, **kwargs): # real signature unknown
    pass

def StatusBar_PushStatusText(*args, **kwargs): # real signature unknown
    pass

def StatusBar_SetFieldsCount(*args, **kwargs): # real signature unknown
    pass

def StatusBar_SetMinHeight(*args, **kwargs): # real signature unknown
    pass

def StatusBar_SetStatusStyles(*args, **kwargs): # real signature unknown
    pass

def StatusBar_SetStatusText(*args, **kwargs): # real signature unknown
    pass

def StatusBar_SetStatusWidths(*args, **kwargs): # real signature unknown
    pass

def StatusBar_swiginit(*args, **kwargs): # real signature unknown
    pass

def StatusBar_swigregister(*args, **kwargs): # real signature unknown
    pass

def TaskBarIconEvent_swiginit(*args, **kwargs): # real signature unknown
    pass

def TaskBarIconEvent_swigregister(*args, **kwargs): # real signature unknown
    pass

def TaskBarIcon_Destroy(*args, **kwargs): # real signature unknown
    pass

def TaskBarIcon_IsAvailable(*args, **kwargs): # real signature unknown
    pass

def TaskBarIcon_IsIconInstalled(*args, **kwargs): # real signature unknown
    pass

def TaskBarIcon_IsOk(*args, **kwargs): # real signature unknown
    pass

def TaskBarIcon_PopupMenu(*args, **kwargs): # real signature unknown
    pass

def TaskBarIcon_RemoveIcon(*args, **kwargs): # real signature unknown
    pass

def TaskBarIcon_SetIcon(*args, **kwargs): # real signature unknown
    pass

def TaskBarIcon_ShowBalloon(*args, **kwargs): # real signature unknown
    pass

def TaskBarIcon_swiginit(*args, **kwargs): # real signature unknown
    pass

def TaskBarIcon_swigregister(*args, **kwargs): # real signature unknown
    pass

def TaskBarIcon__setCallbackInfo(*args, **kwargs): # real signature unknown
    pass

def TextEntryDialog_GetValue(*args, **kwargs): # real signature unknown
    pass

def TextEntryDialog_SetValue(*args, **kwargs): # real signature unknown
    pass

def TextEntryDialog_swiginit(*args, **kwargs): # real signature unknown
    pass

def TextEntryDialog_swigregister(*args, **kwargs): # real signature unknown
    pass

def TipWindow_Close(*args, **kwargs): # real signature unknown
    pass

def TipWindow_SetBoundingRect(*args, **kwargs): # real signature unknown
    pass

def TipWindow_swiginit(*args, **kwargs): # real signature unknown
    pass

def TipWindow_swigregister(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_CenterOnScreen(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_EnableCloseButton(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_GetDefaultItem(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_GetDefaultSize(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_GetIcon(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_GetTitle(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_GetTmpDefaultItem(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_Iconize(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_IsActive(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_IsAlwaysMaximized(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_IsFullScreen(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_IsIconized(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_IsMaximized(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_MacGetMetalAppearance(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_MacGetTopLevelWindowRef(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_MacGetUnifiedAppearance(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_MacSetMetalAppearance(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_Maximize(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_OSXIsModified(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_OSXSetModified(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_RequestUserAttention(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_Restore(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_SetDefaultItem(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_SetIcon(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_SetIcons(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_SetRepresentedFilename(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_SetShape(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_SetTitle(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_SetTmpDefaultItem(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_ShowFullScreen(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_ShowWithoutActivating(*args, **kwargs): # real signature unknown
    pass

def TopLevelWindow_swigregister(*args, **kwargs): # real signature unknown
    pass

def VarHScrollHelper_GetColumnCount(*args, **kwargs): # real signature unknown
    pass

def VarHScrollHelper_GetVisibleColumnsBegin(*args, **kwargs): # real signature unknown
    pass

def VarHScrollHelper_GetVisibleColumnsEnd(*args, **kwargs): # real signature unknown
    pass

def VarHScrollHelper_IsColumnVisible(*args, **kwargs): # real signature unknown
    pass

def VarHScrollHelper_RefreshColumn(*args, **kwargs): # real signature unknown
    pass

def VarHScrollHelper_RefreshColumns(*args, **kwargs): # real signature unknown
    pass

def VarHScrollHelper_ScrollColumnPages(*args, **kwargs): # real signature unknown
    pass

def VarHScrollHelper_ScrollColumns(*args, **kwargs): # real signature unknown
    pass

def VarHScrollHelper_ScrollToColumn(*args, **kwargs): # real signature unknown
    pass

def VarHScrollHelper_SetColumnCount(*args, **kwargs): # real signature unknown
    pass

def VarHScrollHelper_swigregister(*args, **kwargs): # real signature unknown
    pass

def VarHVScrollHelper_EnablePhysicalScrolling(*args, **kwargs): # real signature unknown
    pass

def VarHVScrollHelper_GetRowColumnCount(*args, **kwargs): # real signature unknown
    pass

def VarHVScrollHelper_GetVisibleBegin(*args, **kwargs): # real signature unknown
    pass

def VarHVScrollHelper_GetVisibleEnd(*args, **kwargs): # real signature unknown
    pass

def VarHVScrollHelper_IsVisible(*args, **kwargs): # real signature unknown
    pass

def VarHVScrollHelper_RefreshRowColumn(*args, **kwargs): # real signature unknown
    pass

def VarHVScrollHelper_RefreshRowsColumns(*args, **kwargs): # real signature unknown
    pass

def VarHVScrollHelper_ScrollLayout(*args, **kwargs): # real signature unknown
    pass

def VarHVScrollHelper_ScrollToRowColumn(*args, **kwargs): # real signature unknown
    pass

def VarHVScrollHelper_SetRowColumnCount(*args, **kwargs): # real signature unknown
    pass

def VarHVScrollHelper_swigregister(*args, **kwargs): # real signature unknown
    pass

def VarHVScrollHelper_VirtualHitTest(*args, **kwargs): # real signature unknown
    pass

def VarScrollHelperBase_CalcScrolledPosition(*args, **kwargs): # real signature unknown
    pass

def VarScrollHelperBase_CalcUnscrolledPosition(*args, **kwargs): # real signature unknown
    pass

def VarScrollHelperBase_EnablePhysicalScrolling(*args, **kwargs): # real signature unknown
    pass

def VarScrollHelperBase_GetNonOrientationTargetSize(*args, **kwargs): # real signature unknown
    pass

def VarScrollHelperBase_GetOrientation(*args, **kwargs): # real signature unknown
    pass

def VarScrollHelperBase_GetOrientationTargetSize(*args, **kwargs): # real signature unknown
    pass

def VarScrollHelperBase_GetTargetWindow(*args, **kwargs): # real signature unknown
    pass

def VarScrollHelperBase_GetVisibleBegin(*args, **kwargs): # real signature unknown
    pass

def VarScrollHelperBase_GetVisibleEnd(*args, **kwargs): # real signature unknown
    pass

def VarScrollHelperBase_IsVisible(*args, **kwargs): # real signature unknown
    pass

def VarScrollHelperBase_RefreshAll(*args, **kwargs): # real signature unknown
    pass

def VarScrollHelperBase_RemoveScrollbar(*args, **kwargs): # real signature unknown
    pass

def VarScrollHelperBase_SetTargetWindow(*args, **kwargs): # real signature unknown
    pass

def VarScrollHelperBase_swigregister(*args, **kwargs): # real signature unknown
    pass

def VarScrollHelperBase_UpdateScrollbar(*args, **kwargs): # real signature unknown
    pass

def VarScrollHelperBase_VirtualHitTest(*args, **kwargs): # real signature unknown
    pass

def VarVScrollHelper_GetRowCount(*args, **kwargs): # real signature unknown
    pass

def VarVScrollHelper_GetVisibleRowsBegin(*args, **kwargs): # real signature unknown
    pass

def VarVScrollHelper_GetVisibleRowsEnd(*args, **kwargs): # real signature unknown
    pass

def VarVScrollHelper_IsRowVisible(*args, **kwargs): # real signature unknown
    pass

def VarVScrollHelper_RefreshRow(*args, **kwargs): # real signature unknown
    pass

def VarVScrollHelper_RefreshRows(*args, **kwargs): # real signature unknown
    pass

def VarVScrollHelper_ScrollRowPages(*args, **kwargs): # real signature unknown
    pass

def VarVScrollHelper_ScrollRows(*args, **kwargs): # real signature unknown
    pass

def VarVScrollHelper_ScrollToRow(*args, **kwargs): # real signature unknown
    pass

def VarVScrollHelper_SetRowCount(*args, **kwargs): # real signature unknown
    pass

def VarVScrollHelper_swigregister(*args, **kwargs): # real signature unknown
    pass

def VListBox_Clear(*args, **kwargs): # real signature unknown
    pass

def VListBox_Create(*args, **kwargs): # real signature unknown
    pass

def VListBox_DeselectAll(*args, **kwargs): # real signature unknown
    pass

def VListBox_GetFirstSelected(*args, **kwargs): # real signature unknown
    pass

def VListBox_GetItemCount(*args, **kwargs): # real signature unknown
    pass

def VListBox_GetItemRect(*args, **kwargs): # real signature unknown
    pass

def VListBox_GetMargins(*args, **kwargs): # real signature unknown
    pass

def VListBox_GetNextSelected(*args, **kwargs): # real signature unknown
    pass

def VListBox_GetSelectedCount(*args, **kwargs): # real signature unknown
    pass

def VListBox_GetSelection(*args, **kwargs): # real signature unknown
    pass

def VListBox_GetSelectionBackground(*args, **kwargs): # real signature unknown
    pass

def VListBox_HasMultipleSelection(*args, **kwargs): # real signature unknown
    pass

def VListBox_IsCurrent(*args, **kwargs): # real signature unknown
    pass

def VListBox_IsSelected(*args, **kwargs): # real signature unknown
    pass

def VListBox_OnDrawBackground(*args, **kwargs): # real signature unknown
    pass

def VListBox_OnDrawSeparator(*args, **kwargs): # real signature unknown
    pass

def VListBox_RefreshSelected(*args, **kwargs): # real signature unknown
    pass

def VListBox_Select(*args, **kwargs): # real signature unknown
    pass

def VListBox_SelectAll(*args, **kwargs): # real signature unknown
    pass

def VListBox_SelectRange(*args, **kwargs): # real signature unknown
    pass

def VListBox_SetItemCount(*args, **kwargs): # real signature unknown
    pass

def VListBox_SetMargins(*args, **kwargs): # real signature unknown
    pass

def VListBox_SetMarginsXY(*args, **kwargs): # real signature unknown
    pass

def VListBox_SetSelection(*args, **kwargs): # real signature unknown
    pass

def VListBox_SetSelectionBackground(*args, **kwargs): # real signature unknown
    pass

def VListBox_swiginit(*args, **kwargs): # real signature unknown
    pass

def VListBox_swigregister(*args, **kwargs): # real signature unknown
    pass

def VListBox_Toggle(*args, **kwargs): # real signature unknown
    pass

def VListBox__setCallbackInfo(*args, **kwargs): # real signature unknown
    pass

def VScrolledWindow_Create(*args, **kwargs): # real signature unknown
    pass

def VScrolledWindow_EstimateTotalHeight(*args, **kwargs): # real signature unknown
    pass

def VScrolledWindow_GetRowsHeight(*args, **kwargs): # real signature unknown
    pass

def VScrolledWindow_HitTest(*args, **kwargs): # real signature unknown
    pass

def VScrolledWindow_swiginit(*args, **kwargs): # real signature unknown
    pass

def VScrolledWindow_swigregister(*args, **kwargs): # real signature unknown
    pass

def VScrolledWindow__setCallbackInfo(*args, **kwargs): # real signature unknown
    pass

def WindowModalDialogEvent_GetDialog(*args, **kwargs): # real signature unknown
    pass

def WindowModalDialogEvent_GetReturnCode(*args, **kwargs): # real signature unknown
    pass

def WindowModalDialogEvent_swiginit(*args, **kwargs): # real signature unknown
    pass

def WindowModalDialogEvent_swigregister(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

cvar = None # (!) real value is '<Swig global variables>'

