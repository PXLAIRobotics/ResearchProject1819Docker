# encoding: utf-8
# module wx._glcanvas
# from /usr/lib/python2.7/dist-packages/wx-3.0-gtk3/wx/_glcanvas.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

WX_GL_AUX_BUFFERS = 6

WX_GL_BUFFER_SIZE = 2

WX_GL_DEPTH_SIZE = 11

WX_GL_DOUBLEBUFFER = 4
WX_GL_LEVEL = 3

WX_GL_MIN_ACCUM_ALPHA = 16
WX_GL_MIN_ACCUM_BLUE = 15
WX_GL_MIN_ACCUM_GREEN = 14
WX_GL_MIN_ACCUM_RED = 13

WX_GL_MIN_ALPHA = 10
WX_GL_MIN_BLUE = 9
WX_GL_MIN_GREEN = 8
WX_GL_MIN_RED = 7

WX_GL_RGBA = 1
WX_GL_SAMPLES = 18

WX_GL_SAMPLE_BUFFERS = 17

WX_GL_STENCIL_SIZE = 12

WX_GL_STEREO = 5

# functions

def delete_GLContext(*args, **kwargs): # real signature unknown
    pass

def GLCanvas_Create(*args, **kwargs): # real signature unknown
    pass

def GLCanvas_GetContext(*args, **kwargs): # real signature unknown
    pass

def GLCanvas_GetPalette(*args, **kwargs): # real signature unknown
    pass

def GLCanvas_InitVisual(*args, **kwargs): # real signature unknown
    pass

def GLCanvas_IsDisplaySupported(*args, **kwargs): # real signature unknown
    pass

def GLCanvas_IsExtensionSupported(*args, **kwargs): # real signature unknown
    pass

def GLCanvas_SetColour(*args, **kwargs): # real signature unknown
    pass

def GLCanvas_SetCurrent(*args, **kwargs): # real signature unknown
    pass

def GLCanvas_SwapBuffers(*args, **kwargs): # real signature unknown
    pass

def GLCanvas_swiginit(*args, **kwargs): # real signature unknown
    pass

def GLCanvas_swigregister(*args, **kwargs): # real signature unknown
    pass

def GLContext_SetCurrent(*args, **kwargs): # real signature unknown
    pass

def GLContext_swiginit(*args, **kwargs): # real signature unknown
    pass

def GLContext_swigregister(*args, **kwargs): # real signature unknown
    pass

def new_GLCanvas(*args, **kwargs): # real signature unknown
    pass

def new_GLCanvasWithContext(*args, **kwargs): # real signature unknown
    pass

def new_GLContext(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

cvar = None # (!) real value is '<Swig global variables>'

