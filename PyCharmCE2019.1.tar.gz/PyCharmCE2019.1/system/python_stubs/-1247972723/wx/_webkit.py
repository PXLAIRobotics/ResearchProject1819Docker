# encoding: utf-8
# module wx._webkit
# from /usr/lib/python2.7/dist-packages/wx-3.0-gtk3/wx/_webkit.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

WEBKIT_NAV_BACK_NEXT = 0

WEBKIT_NAV_FORM_RESUBMITTED = 0
WEBKIT_NAV_FORM_SUBMITTED = 0

WEBKIT_NAV_LINK_CLICKED = 0

WEBKIT_NAV_OTHER = 0
WEBKIT_NAV_RELOAD = 0

WEBKIT_STATE_FAILED = 0
WEBKIT_STATE_NEGOTIATING = 0
WEBKIT_STATE_REDIRECTING = 0
WEBKIT_STATE_START = 0
WEBKIT_STATE_STOP = 0
WEBKIT_STATE_TRANSFERRING = 0

wxEVT_WEBKIT_BEFORE_LOAD = 0

wxEVT_WEBKIT_NEW_WINDOW = 0

wxEVT_WEBKIT_STATE_CHANGED = 0

# functions

def new_PreWebKitCtrl(*args, **kwargs): # real signature unknown
    pass

def new_WebKitBeforeLoadEvent(*args, **kwargs): # real signature unknown
    pass

def new_WebKitCtrl(*args, **kwargs): # real signature unknown
    pass

def new_WebKitNewWindowEvent(*args, **kwargs): # real signature unknown
    pass

def new_WebKitStateChangedEvent(*args, **kwargs): # real signature unknown
    pass

def WebKitBeforeLoadEvent_Cancel(*args, **kwargs): # real signature unknown
    pass

def WebKitBeforeLoadEvent_GetNavigationType(*args, **kwargs): # real signature unknown
    pass

def WebKitBeforeLoadEvent_GetURL(*args, **kwargs): # real signature unknown
    pass

def WebKitBeforeLoadEvent_IsCancelled(*args, **kwargs): # real signature unknown
    pass

def WebKitBeforeLoadEvent_SetNavigationType(*args, **kwargs): # real signature unknown
    pass

def WebKitBeforeLoadEvent_SetURL(*args, **kwargs): # real signature unknown
    pass

def WebKitBeforeLoadEvent_swiginit(*args, **kwargs): # real signature unknown
    pass

def WebKitBeforeLoadEvent_swigregister(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_CanDecreaseTextSize(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_CanGetPageSource(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_CanGoBack(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_CanGoForward(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_CanIncreaseTextSize(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_Create(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_DecreaseTextSize(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_GetPageSource(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_GetPageTitle(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_GetPageURL(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_GetSelection(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_GoBack(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_GoForward(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_IncreaseTextSize(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_IsEditable(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_LoadURL(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_MakeEditable(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_Print(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_Reload(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_RunScript(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_SetPageSource(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_Stop(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_swiginit(*args, **kwargs): # real signature unknown
    pass

def WebKitCtrl_swigregister(*args, **kwargs): # real signature unknown
    pass

def WebKitNewWindowEvent_GetTargetName(*args, **kwargs): # real signature unknown
    pass

def WebKitNewWindowEvent_GetURL(*args, **kwargs): # real signature unknown
    pass

def WebKitNewWindowEvent_SetTargetName(*args, **kwargs): # real signature unknown
    pass

def WebKitNewWindowEvent_SetURL(*args, **kwargs): # real signature unknown
    pass

def WebKitNewWindowEvent_swiginit(*args, **kwargs): # real signature unknown
    pass

def WebKitNewWindowEvent_swigregister(*args, **kwargs): # real signature unknown
    pass

def WebKitStateChangedEvent_GetState(*args, **kwargs): # real signature unknown
    pass

def WebKitStateChangedEvent_GetURL(*args, **kwargs): # real signature unknown
    pass

def WebKitStateChangedEvent_SetState(*args, **kwargs): # real signature unknown
    pass

def WebKitStateChangedEvent_SetURL(*args, **kwargs): # real signature unknown
    pass

def WebKitStateChangedEvent_swiginit(*args, **kwargs): # real signature unknown
    pass

def WebKitStateChangedEvent_swigregister(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

cvar = None # (!) real value is '<Swig global variables>'

