# encoding: utf-8
# module wx._wizard
# from /usr/lib/python2.7/dist-packages/wx-3.0-gtk3/wx/_wizard.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

WIZARD_EX_HELPBUTTON = 16

WIZARD_HALIGN_CENTRE = 16
WIZARD_HALIGN_LEFT = 8
WIZARD_HALIGN_RIGHT = 32

WIZARD_TILE = 64

WIZARD_VALIGN_BOTTOM = 4
WIZARD_VALIGN_CENTRE = 2
WIZARD_VALIGN_TOP = 1

wxEVT_WIZARD_BEFORE_PAGE_CHANGED = 10285

wxEVT_WIZARD_CANCEL = 10286
wxEVT_WIZARD_FINISHED = 10287
wxEVT_WIZARD_HELP = 10288

wxEVT_WIZARD_PAGE_CHANGED = 10283
wxEVT_WIZARD_PAGE_CHANGING = 10284
wxEVT_WIZARD_PAGE_SHOWN = 10289

# functions

def new_PrePyWizardPage(*args, **kwargs): # real signature unknown
    pass

def new_PreWizard(*args, **kwargs): # real signature unknown
    pass

def new_PreWizardPageSimple(*args, **kwargs): # real signature unknown
    pass

def new_PyWizardPage(*args, **kwargs): # real signature unknown
    pass

def new_Wizard(*args, **kwargs): # real signature unknown
    pass

def new_WizardEvent(*args, **kwargs): # real signature unknown
    pass

def new_WizardPageSimple(*args, **kwargs): # real signature unknown
    pass

def PyWizardPage_Create(*args, **kwargs): # real signature unknown
    pass

def PyWizardPage_DoGetBestSize(*args, **kwargs): # real signature unknown
    pass

def PyWizardPage_DoGetClientSize(*args, **kwargs): # real signature unknown
    pass

def PyWizardPage_DoGetPosition(*args, **kwargs): # real signature unknown
    pass

def PyWizardPage_DoGetSize(*args, **kwargs): # real signature unknown
    pass

def PyWizardPage_DoGetVirtualSize(*args, **kwargs): # real signature unknown
    pass

def PyWizardPage_DoMoveWindow(*args, **kwargs): # real signature unknown
    pass

def PyWizardPage_DoSetClientSize(*args, **kwargs): # real signature unknown
    pass

def PyWizardPage_DoSetSize(*args, **kwargs): # real signature unknown
    pass

def PyWizardPage_DoSetVirtualSize(*args, **kwargs): # real signature unknown
    pass

def PyWizardPage_GetDefaultAttributes(*args, **kwargs): # real signature unknown
    pass

def PyWizardPage_OnInternalIdle(*args, **kwargs): # real signature unknown
    pass

def PyWizardPage_swiginit(*args, **kwargs): # real signature unknown
    pass

def PyWizardPage_swigregister(*args, **kwargs): # real signature unknown
    pass

def PyWizardPage__setCallbackInfo(*args, **kwargs): # real signature unknown
    pass

def WizardEvent_GetDirection(*args, **kwargs): # real signature unknown
    pass

def WizardEvent_GetPage(*args, **kwargs): # real signature unknown
    pass

def WizardEvent_swiginit(*args, **kwargs): # real signature unknown
    pass

def WizardEvent_swigregister(*args, **kwargs): # real signature unknown
    pass

def WizardPageSimple_Chain(*args, **kwargs): # real signature unknown
    pass

def WizardPageSimple_Create(*args, **kwargs): # real signature unknown
    pass

def WizardPageSimple_SetNext(*args, **kwargs): # real signature unknown
    pass

def WizardPageSimple_SetPrev(*args, **kwargs): # real signature unknown
    pass

def WizardPageSimple_swiginit(*args, **kwargs): # real signature unknown
    pass

def WizardPageSimple_swigregister(*args, **kwargs): # real signature unknown
    pass

def WizardPage_Create(*args, **kwargs): # real signature unknown
    pass

def WizardPage_GetBitmap(*args, **kwargs): # real signature unknown
    pass

def WizardPage_GetNext(*args, **kwargs): # real signature unknown
    pass

def WizardPage_GetPrev(*args, **kwargs): # real signature unknown
    pass

def WizardPage_swigregister(*args, **kwargs): # real signature unknown
    pass

def Wizard_Create(*args, **kwargs): # real signature unknown
    pass

def Wizard_FitToPage(*args, **kwargs): # real signature unknown
    pass

def Wizard_GetBitmap(*args, **kwargs): # real signature unknown
    pass

def Wizard_GetBitmapBackgroundColour(*args, **kwargs): # real signature unknown
    pass

def Wizard_GetBitmapPlacement(*args, **kwargs): # real signature unknown
    pass

def Wizard_GetCurrentPage(*args, **kwargs): # real signature unknown
    pass

def Wizard_GetMinimumBitmapWidth(*args, **kwargs): # real signature unknown
    pass

def Wizard_GetPageAreaSizer(*args, **kwargs): # real signature unknown
    pass

def Wizard_GetPageSize(*args, **kwargs): # real signature unknown
    pass

def Wizard_HasNextPage(*args, **kwargs): # real signature unknown
    pass

def Wizard_HasPrevPage(*args, **kwargs): # real signature unknown
    pass

def Wizard_Init(*args, **kwargs): # real signature unknown
    pass

def Wizard_IsRunning(*args, **kwargs): # real signature unknown
    pass

def Wizard_RunWizard(*args, **kwargs): # real signature unknown
    pass

def Wizard_SetBitmap(*args, **kwargs): # real signature unknown
    pass

def Wizard_SetBitmapBackgroundColour(*args, **kwargs): # real signature unknown
    pass

def Wizard_SetBitmapPlacement(*args, **kwargs): # real signature unknown
    pass

def Wizard_SetBorder(*args, **kwargs): # real signature unknown
    pass

def Wizard_SetMinimumBitmapWidth(*args, **kwargs): # real signature unknown
    pass

def Wizard_SetPageSize(*args, **kwargs): # real signature unknown
    pass

def Wizard_ShowPage(*args, **kwargs): # real signature unknown
    pass

def Wizard_swiginit(*args, **kwargs): # real signature unknown
    pass

def Wizard_swigregister(*args, **kwargs): # real signature unknown
    pass

def Wizard_TileBitmap(*args, **kwargs): # real signature unknown
    pass

# no classes
