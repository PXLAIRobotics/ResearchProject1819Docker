# encoding: utf-8
# module PyQt5.QtXml
# from /usr/lib/python2.7/dist-packages/PyQt5/QtXml.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

class QXmlAttributes(): # skipped bases: <type 'sip.simplewrapper'>
    """
    QXmlAttributes()
    QXmlAttributes(QXmlAttributes)
    """
    def append(self, p_str, p_str_1, p_str_2, p_str_3): # real signature unknown; restored from __doc__
        """ append(self, str, str, str, str) """
        pass

    def clear(self): # real signature unknown; restored from __doc__
        """ clear(self) """
        pass

    def count(self): # real signature unknown; restored from __doc__
        """ count(self) -> int """
        return 0

    def index(self, p_str, p_str_1=None): # real signature unknown; restored from __doc__ with multiple overloads
        """
        index(self, str) -> int
        index(self, str, str) -> int
        """
        return 0

    def length(self): # real signature unknown; restored from __doc__
        """ length(self) -> int """
        return 0

    def localName(self, p_int): # real signature unknown; restored from __doc__
        """ localName(self, int) -> str """
        return ""

    def qName(self, p_int): # real signature unknown; restored from __doc__
        """ qName(self, int) -> str """
        return ""

    def swap(self, QXmlAttributes): # real signature unknown; restored from __doc__
        """ swap(self, QXmlAttributes) """
        pass

    def type(self, *__args): # real signature unknown; restored from __doc__ with multiple overloads
        """
        type(self, int) -> str
        type(self, str) -> str
        type(self, str, str) -> str
        """
        return ""

    def uri(self, p_int): # real signature unknown; restored from __doc__
        """ uri(self, int) -> str """
        return ""

    def value(self, *__args): # real signature unknown; restored from __doc__ with multiple overloads
        """
        value(self, int) -> str
        value(self, str) -> str
        value(self, str, str) -> str
        """
        return ""

    def __init__(self, QXmlAttributes=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    def __len__(self): # real signature unknown; restored from __doc__
        """ x.__len__() <==> len(x) """
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



