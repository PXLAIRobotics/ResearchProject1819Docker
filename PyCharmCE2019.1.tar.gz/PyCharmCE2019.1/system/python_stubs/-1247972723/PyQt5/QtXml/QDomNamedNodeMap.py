# encoding: utf-8
# module PyQt5.QtXml
# from /usr/lib/python2.7/dist-packages/PyQt5/QtXml.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

class QDomNamedNodeMap(): # skipped bases: <type 'sip.simplewrapper'>
    """
    QDomNamedNodeMap()
    QDomNamedNodeMap(QDomNamedNodeMap)
    """
    def contains(self, p_str): # real signature unknown; restored from __doc__
        """ contains(self, str) -> bool """
        return False

    def count(self): # real signature unknown; restored from __doc__
        """ count(self) -> int """
        return 0

    def isEmpty(self): # real signature unknown; restored from __doc__
        """ isEmpty(self) -> bool """
        return False

    def item(self, p_int): # real signature unknown; restored from __doc__
        """ item(self, int) -> QDomNode """
        return QDomNode

    def length(self): # real signature unknown; restored from __doc__
        """ length(self) -> int """
        return 0

    def namedItem(self, p_str): # real signature unknown; restored from __doc__
        """ namedItem(self, str) -> QDomNode """
        return QDomNode

    def namedItemNS(self, p_str, p_str_1): # real signature unknown; restored from __doc__
        """ namedItemNS(self, str, str) -> QDomNode """
        return QDomNode

    def removeNamedItem(self, p_str): # real signature unknown; restored from __doc__
        """ removeNamedItem(self, str) -> QDomNode """
        return QDomNode

    def removeNamedItemNS(self, p_str, p_str_1): # real signature unknown; restored from __doc__
        """ removeNamedItemNS(self, str, str) -> QDomNode """
        return QDomNode

    def setNamedItem(self, QDomNode): # real signature unknown; restored from __doc__
        """ setNamedItem(self, QDomNode) -> QDomNode """
        return QDomNode

    def setNamedItemNS(self, QDomNode): # real signature unknown; restored from __doc__
        """ setNamedItemNS(self, QDomNode) -> QDomNode """
        return QDomNode

    def size(self): # real signature unknown; restored from __doc__
        """ size(self) -> int """
        return 0

    def __eq__(self, y): # real signature unknown; restored from __doc__
        """ x.__eq__(y) <==> x==y """
        pass

    def __ge__(self, y): # real signature unknown; restored from __doc__
        """ x.__ge__(y) <==> x>=y """
        pass

    def __gt__(self, y): # real signature unknown; restored from __doc__
        """ x.__gt__(y) <==> x>y """
        pass

    def __init__(self, QDomNamedNodeMap=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    def __len__(self): # real signature unknown; restored from __doc__
        """ x.__len__() <==> len(x) """
        pass

    def __le__(self, y): # real signature unknown; restored from __doc__
        """ x.__le__(y) <==> x<=y """
        pass

    def __lt__(self, y): # real signature unknown; restored from __doc__
        """ x.__lt__(y) <==> x<y """
        pass

    def __ne__(self, y): # real signature unknown; restored from __doc__
        """ x.__ne__(y) <==> x!=y """
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



