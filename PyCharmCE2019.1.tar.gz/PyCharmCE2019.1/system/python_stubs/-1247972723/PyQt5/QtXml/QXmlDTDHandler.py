# encoding: utf-8
# module PyQt5.QtXml
# from /usr/lib/python2.7/dist-packages/PyQt5/QtXml.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

class QXmlDTDHandler(): # skipped bases: <type 'sip.simplewrapper'>
    """
    QXmlDTDHandler()
    QXmlDTDHandler(QXmlDTDHandler)
    """
    def errorString(self): # real signature unknown; restored from __doc__
        """ errorString(self) -> str """
        return ""

    def notationDecl(self, p_str, p_str_1, p_str_2): # real signature unknown; restored from __doc__
        """ notationDecl(self, str, str, str) -> bool """
        return False

    def unparsedEntityDecl(self, p_str, p_str_1, p_str_2, p_str_3): # real signature unknown; restored from __doc__
        """ unparsedEntityDecl(self, str, str, str, str) -> bool """
        return False

    def __init__(self, QXmlDTDHandler=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



