# encoding: utf-8
# module PyQt5.QtXml
# from /usr/lib/python2.7/dist-packages/PyQt5/QtXml.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

class QXmlNamespaceSupport(): # skipped bases: <type 'sip.simplewrapper'>
    """ QXmlNamespaceSupport() """
    def popContext(self): # real signature unknown; restored from __doc__
        """ popContext(self) """
        pass

    def prefix(self, p_str): # real signature unknown; restored from __doc__
        """ prefix(self, str) -> str """
        return ""

    def prefixes(self, p_str=None): # real signature unknown; restored from __doc__ with multiple overloads
        """
        prefixes(self) -> List[str]
        prefixes(self, str) -> List[str]
        """
        return []

    def processName(self, p_str, bool, p_str_1, p_str_2): # real signature unknown; restored from __doc__
        """ processName(self, str, bool, str, str) """
        pass

    def pushContext(self): # real signature unknown; restored from __doc__
        """ pushContext(self) """
        pass

    def reset(self): # real signature unknown; restored from __doc__
        """ reset(self) """
        pass

    def setPrefix(self, p_str, p_str_1): # real signature unknown; restored from __doc__
        """ setPrefix(self, str, str) """
        pass

    def splitName(self, p_str, p_str_1, p_str_2): # real signature unknown; restored from __doc__
        """ splitName(self, str, str, str) """
        pass

    def uri(self, p_str): # real signature unknown; restored from __doc__
        """ uri(self, str) -> str """
        return ""

    def __init__(self): # real signature unknown; restored from __doc__
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



