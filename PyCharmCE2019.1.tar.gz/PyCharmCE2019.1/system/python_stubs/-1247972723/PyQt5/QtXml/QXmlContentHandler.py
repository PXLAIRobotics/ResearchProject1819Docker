# encoding: utf-8
# module PyQt5.QtXml
# from /usr/lib/python2.7/dist-packages/PyQt5/QtXml.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

class QXmlContentHandler(): # skipped bases: <type 'sip.simplewrapper'>
    """
    QXmlContentHandler()
    QXmlContentHandler(QXmlContentHandler)
    """
    def characters(self, p_str): # real signature unknown; restored from __doc__
        """ characters(self, str) -> bool """
        return False

    def endDocument(self): # real signature unknown; restored from __doc__
        """ endDocument(self) -> bool """
        return False

    def endElement(self, p_str, p_str_1, p_str_2): # real signature unknown; restored from __doc__
        """ endElement(self, str, str, str) -> bool """
        return False

    def endPrefixMapping(self, p_str): # real signature unknown; restored from __doc__
        """ endPrefixMapping(self, str) -> bool """
        return False

    def errorString(self): # real signature unknown; restored from __doc__
        """ errorString(self) -> str """
        return ""

    def ignorableWhitespace(self, p_str): # real signature unknown; restored from __doc__
        """ ignorableWhitespace(self, str) -> bool """
        return False

    def processingInstruction(self, p_str, p_str_1): # real signature unknown; restored from __doc__
        """ processingInstruction(self, str, str) -> bool """
        return False

    def setDocumentLocator(self, QXmlLocator): # real signature unknown; restored from __doc__
        """ setDocumentLocator(self, QXmlLocator) """
        pass

    def skippedEntity(self, p_str): # real signature unknown; restored from __doc__
        """ skippedEntity(self, str) -> bool """
        return False

    def startDocument(self): # real signature unknown; restored from __doc__
        """ startDocument(self) -> bool """
        return False

    def startElement(self, p_str, p_str_1, p_str_2, QXmlAttributes): # real signature unknown; restored from __doc__
        """ startElement(self, str, str, str, QXmlAttributes) -> bool """
        return False

    def startPrefixMapping(self, p_str, p_str_1): # real signature unknown; restored from __doc__
        """ startPrefixMapping(self, str, str) -> bool """
        return False

    def __init__(self, QXmlContentHandler=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



