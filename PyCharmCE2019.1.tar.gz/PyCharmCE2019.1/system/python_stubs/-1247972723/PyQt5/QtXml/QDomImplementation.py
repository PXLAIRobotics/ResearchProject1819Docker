# encoding: utf-8
# module PyQt5.QtXml
# from /usr/lib/python2.7/dist-packages/PyQt5/QtXml.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

class QDomImplementation(): # skipped bases: <type 'sip.simplewrapper'>
    """
    QDomImplementation()
    QDomImplementation(QDomImplementation)
    """
    def createDocument(self, p_str, p_str_1, QDomDocumentType): # real signature unknown; restored from __doc__
        """ createDocument(self, str, str, QDomDocumentType) -> QDomDocument """
        return QDomDocument

    def createDocumentType(self, p_str, p_str_1, p_str_2): # real signature unknown; restored from __doc__
        """ createDocumentType(self, str, str, str) -> QDomDocumentType """
        return QDomDocumentType

    def hasFeature(self, p_str, p_str_1): # real signature unknown; restored from __doc__
        """ hasFeature(self, str, str) -> bool """
        return False

    def invalidDataPolicy(self): # real signature unknown; restored from __doc__
        """ invalidDataPolicy() -> QDomImplementation.InvalidDataPolicy """
        pass

    def isNull(self): # real signature unknown; restored from __doc__
        """ isNull(self) -> bool """
        return False

    def setInvalidDataPolicy(self, QDomImplementation_InvalidDataPolicy): # real signature unknown; restored from __doc__
        """ setInvalidDataPolicy(QDomImplementation.InvalidDataPolicy) """
        pass

    def __eq__(self, y): # real signature unknown; restored from __doc__
        """ x.__eq__(y) <==> x==y """
        pass

    def __ge__(self, y): # real signature unknown; restored from __doc__
        """ x.__ge__(y) <==> x>=y """
        pass

    def __gt__(self, y): # real signature unknown; restored from __doc__
        """ x.__gt__(y) <==> x>y """
        pass

    def __init__(self, QDomImplementation=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    def __le__(self, y): # real signature unknown; restored from __doc__
        """ x.__le__(y) <==> x<=y """
        pass

    def __lt__(self, y): # real signature unknown; restored from __doc__
        """ x.__lt__(y) <==> x<y """
        pass

    def __ne__(self, y): # real signature unknown; restored from __doc__
        """ x.__ne__(y) <==> x!=y """
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    AcceptInvalidChars = 0
    DropInvalidChars = 1
    ReturnNullNode = 2


