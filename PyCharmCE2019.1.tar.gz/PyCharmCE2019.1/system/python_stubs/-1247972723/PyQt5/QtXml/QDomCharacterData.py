# encoding: utf-8
# module PyQt5.QtXml
# from /usr/lib/python2.7/dist-packages/PyQt5/QtXml.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

from QDomNode import QDomNode

class QDomCharacterData(QDomNode):
    """
    QDomCharacterData()
    QDomCharacterData(QDomCharacterData)
    """
    def appendData(self, p_str): # real signature unknown; restored from __doc__
        """ appendData(self, str) """
        pass

    def data(self): # real signature unknown; restored from __doc__
        """ data(self) -> str """
        return ""

    def deleteData(self, p_int, p_int_1): # real signature unknown; restored from __doc__
        """ deleteData(self, int, int) """
        pass

    def insertData(self, p_int, p_str): # real signature unknown; restored from __doc__
        """ insertData(self, int, str) """
        pass

    def length(self): # real signature unknown; restored from __doc__
        """ length(self) -> int """
        return 0

    def nodeType(self): # real signature unknown; restored from __doc__
        """ nodeType(self) -> QDomNode.NodeType """
        pass

    def replaceData(self, p_int, p_int_1, p_str): # real signature unknown; restored from __doc__
        """ replaceData(self, int, int, str) """
        pass

    def setData(self, p_str): # real signature unknown; restored from __doc__
        """ setData(self, str) """
        pass

    def substringData(self, p_int, p_int_1): # real signature unknown; restored from __doc__
        """ substringData(self, int, int) -> str """
        return ""

    def __init__(self, QDomCharacterData=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass


