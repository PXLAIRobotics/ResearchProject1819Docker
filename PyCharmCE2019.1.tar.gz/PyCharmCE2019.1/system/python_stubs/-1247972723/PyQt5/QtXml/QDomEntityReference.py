# encoding: utf-8
# module PyQt5.QtXml
# from /usr/lib/python2.7/dist-packages/PyQt5/QtXml.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

from QDomNode import QDomNode

class QDomEntityReference(QDomNode):
    """
    QDomEntityReference()
    QDomEntityReference(QDomEntityReference)
    """
    def nodeType(self): # real signature unknown; restored from __doc__
        """ nodeType(self) -> QDomNode.NodeType """
        pass

    def __init__(self, QDomEntityReference=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass


