# encoding: utf-8
# module PyQt5.QtXml
# from /usr/lib/python2.7/dist-packages/PyQt5/QtXml.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

from QDomNode import QDomNode

class QDomProcessingInstruction(QDomNode):
    """
    QDomProcessingInstruction()
    QDomProcessingInstruction(QDomProcessingInstruction)
    """
    def data(self): # real signature unknown; restored from __doc__
        """ data(self) -> str """
        return ""

    def nodeType(self): # real signature unknown; restored from __doc__
        """ nodeType(self) -> QDomNode.NodeType """
        pass

    def setData(self, p_str): # real signature unknown; restored from __doc__
        """ setData(self, str) """
        pass

    def target(self): # real signature unknown; restored from __doc__
        """ target(self) -> str """
        return ""

    def __init__(self, QDomProcessingInstruction=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass


