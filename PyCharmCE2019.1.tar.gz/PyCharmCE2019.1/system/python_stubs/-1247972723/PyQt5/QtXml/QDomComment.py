# encoding: utf-8
# module PyQt5.QtXml
# from /usr/lib/python2.7/dist-packages/PyQt5/QtXml.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

from QDomCharacterData import QDomCharacterData

class QDomComment(QDomCharacterData):
    """
    QDomComment()
    QDomComment(QDomComment)
    """
    def nodeType(self): # real signature unknown; restored from __doc__
        """ nodeType(self) -> QDomNode.NodeType """
        pass

    def __init__(self, QDomComment=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass


