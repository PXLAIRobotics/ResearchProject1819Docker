# encoding: utf-8
# module PyQt5.QtCore
# from /usr/lib/python2.7/dist-packages/PyQt5/QtCore.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

from QObject import QObject

class QMimeData(QObject):
    """ QMimeData() """
    def clear(self): # real signature unknown; restored from __doc__
        """ clear(self) """
        pass

    def colorData(self): # real signature unknown; restored from __doc__
        """ colorData(self) -> Any """
        pass

    def data(self, p_str): # real signature unknown; restored from __doc__
        """ data(self, str) -> QByteArray """
        return QByteArray

    def formats(self): # real signature unknown; restored from __doc__
        """ formats(self) -> List[str] """
        return []

    def hasColor(self): # real signature unknown; restored from __doc__
        """ hasColor(self) -> bool """
        return False

    def hasFormat(self, p_str): # real signature unknown; restored from __doc__
        """ hasFormat(self, str) -> bool """
        return False

    def hasHtml(self): # real signature unknown; restored from __doc__
        """ hasHtml(self) -> bool """
        return False

    def hasImage(self): # real signature unknown; restored from __doc__
        """ hasImage(self) -> bool """
        return False

    def hasText(self): # real signature unknown; restored from __doc__
        """ hasText(self) -> bool """
        return False

    def hasUrls(self): # real signature unknown; restored from __doc__
        """ hasUrls(self) -> bool """
        return False

    def html(self): # real signature unknown; restored from __doc__
        """ html(self) -> str """
        return ""

    def imageData(self): # real signature unknown; restored from __doc__
        """ imageData(self) -> Any """
        pass

    def removeFormat(self, p_str): # real signature unknown; restored from __doc__
        """ removeFormat(self, str) """
        pass

    def retrieveData(self, p_str, QVariant_Type): # real signature unknown; restored from __doc__
        """ retrieveData(self, str, QVariant.Type) -> Any """
        pass

    def setColorData(self, Any): # real signature unknown; restored from __doc__
        """ setColorData(self, Any) """
        pass

    def setData(self, p_str, Union, QByteArray=None, bytes=None, bytearray=None): # real signature unknown; restored from __doc__
        """ setData(self, str, Union[QByteArray, bytes, bytearray]) """
        pass

    def setHtml(self, p_str): # real signature unknown; restored from __doc__
        """ setHtml(self, str) """
        pass

    def setImageData(self, Any): # real signature unknown; restored from __doc__
        """ setImageData(self, Any) """
        pass

    def setText(self, p_str): # real signature unknown; restored from __doc__
        """ setText(self, str) """
        pass

    def setUrls(self, Iterable, QUrl=None): # real signature unknown; restored from __doc__
        """ setUrls(self, Iterable[QUrl]) """
        pass

    def text(self): # real signature unknown; restored from __doc__
        """ text(self) -> str """
        return ""

    def urls(self): # real signature unknown; restored from __doc__
        """ urls(self) -> object """
        return object()

    def __init__(self): # real signature unknown; restored from __doc__
        pass


