# encoding: utf-8
# module PyQt5.QtCore
# from /usr/lib/python2.7/dist-packages/PyQt5/QtCore.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

class QTextDecoder(): # skipped bases: <type 'sip.wrapper'>
    """
    QTextDecoder(QTextCodec)
    QTextDecoder(QTextCodec, Union[QTextCodec.ConversionFlags, QTextCodec.ConversionFlag])
    """
    def toUnicode(self, *__args): # real signature unknown; restored from __doc__ with multiple overloads
        """
        toUnicode(self, bytes) -> str
        toUnicode(self, Union[QByteArray, bytes, bytearray]) -> str
        """
        return ""

    def __init__(self, QTextCodec, Union=None, QTextCodec_ConversionFlags=None, QTextCodec_ConversionFlag=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



