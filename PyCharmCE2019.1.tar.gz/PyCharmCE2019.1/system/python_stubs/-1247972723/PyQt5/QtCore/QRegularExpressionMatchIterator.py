# encoding: utf-8
# module PyQt5.QtCore
# from /usr/lib/python2.7/dist-packages/PyQt5/QtCore.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

class QRegularExpressionMatchIterator(): # skipped bases: <type 'sip.simplewrapper'>
    """
    QRegularExpressionMatchIterator()
    QRegularExpressionMatchIterator(QRegularExpressionMatchIterator)
    """
    def hasNext(self): # real signature unknown; restored from __doc__
        """ hasNext(self) -> bool """
        return False

    def isValid(self): # real signature unknown; restored from __doc__
        """ isValid(self) -> bool """
        return False

    def matchOptions(self): # real signature unknown; restored from __doc__
        """ matchOptions(self) -> QRegularExpression.MatchOptions """
        pass

    def matchType(self): # real signature unknown; restored from __doc__
        """ matchType(self) -> QRegularExpression.MatchType """
        pass

    def next(self): # real signature unknown; restored from __doc__
        """ next(self) -> QRegularExpressionMatch """
        return QRegularExpressionMatch

    def peekNext(self): # real signature unknown; restored from __doc__
        """ peekNext(self) -> QRegularExpressionMatch """
        return QRegularExpressionMatch

    def regularExpression(self): # real signature unknown; restored from __doc__
        """ regularExpression(self) -> QRegularExpression """
        return QRegularExpression

    def swap(self, QRegularExpressionMatchIterator): # real signature unknown; restored from __doc__
        """ swap(self, QRegularExpressionMatchIterator) """
        pass

    def __init__(self, QRegularExpressionMatchIterator=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



