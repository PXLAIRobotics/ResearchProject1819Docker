# encoding: utf-8
# module PyQt5.QtCore
# from /usr/lib/python2.7/dist-packages/PyQt5/QtCore.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

class QEventLoopLocker(): # skipped bases: <type 'sip.simplewrapper'>
    """
    QEventLoopLocker()
    QEventLoopLocker(QEventLoop)
    QEventLoopLocker(QThread)
    """
    def __init__(self, *__args): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



