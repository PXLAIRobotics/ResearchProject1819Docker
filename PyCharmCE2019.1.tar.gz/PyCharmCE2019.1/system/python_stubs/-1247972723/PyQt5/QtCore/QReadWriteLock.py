# encoding: utf-8
# module PyQt5.QtCore
# from /usr/lib/python2.7/dist-packages/PyQt5/QtCore.x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

class QReadWriteLock(): # skipped bases: <type 'sip.simplewrapper'>
    """ QReadWriteLock(recursionMode: QReadWriteLock.RecursionMode = QReadWriteLock.NonRecursive) """
    def lockForRead(self): # real signature unknown; restored from __doc__
        """ lockForRead(self) """
        pass

    def lockForWrite(self): # real signature unknown; restored from __doc__
        """ lockForWrite(self) """
        pass

    def tryLockForRead(self, p_int=None): # real signature unknown; restored from __doc__ with multiple overloads
        """
        tryLockForRead(self) -> bool
        tryLockForRead(self, int) -> bool
        """
        return False

    def tryLockForWrite(self, p_int=None): # real signature unknown; restored from __doc__ with multiple overloads
        """
        tryLockForWrite(self) -> bool
        tryLockForWrite(self, int) -> bool
        """
        return False

    def unlock(self): # real signature unknown; restored from __doc__
        """ unlock(self) """
        pass

    def __init__(self, recursionMode=None): # real signature unknown; restored from __doc__
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    NonRecursive = 0
    Recursive = 1


