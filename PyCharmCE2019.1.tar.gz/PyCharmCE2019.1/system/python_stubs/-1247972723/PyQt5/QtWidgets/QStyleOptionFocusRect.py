# encoding: utf-8
# module PyQt5.QtWidgets
# from /usr/lib/python2.7/dist-packages/PyQt5/QtWidgets.x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore
import PyQt5.QtGui as __PyQt5_QtGui


from QStyleOption import QStyleOption

class QStyleOptionFocusRect(QStyleOption):
    """
    QStyleOptionFocusRect()
    QStyleOptionFocusRect(QStyleOptionFocusRect)
    """
    def __init__(self, QStyleOptionFocusRect=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    Type = 1
    Version = 1


