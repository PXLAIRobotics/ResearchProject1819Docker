# encoding: utf-8
# module PyQt5.QtWidgets
# from /usr/lib/python2.7/dist-packages/PyQt5/QtWidgets.x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore
import PyQt5.QtGui as __PyQt5_QtGui


from QGraphicsSceneEvent import QGraphicsSceneEvent

class QGraphicsSceneMoveEvent(QGraphicsSceneEvent):
    """ QGraphicsSceneMoveEvent() """
    def newPos(self): # real signature unknown; restored from __doc__
        """ newPos(self) -> QPointF """
        pass

    def oldPos(self): # real signature unknown; restored from __doc__
        """ oldPos(self) -> QPointF """
        pass

    def __init__(self): # real signature unknown; restored from __doc__
        pass


