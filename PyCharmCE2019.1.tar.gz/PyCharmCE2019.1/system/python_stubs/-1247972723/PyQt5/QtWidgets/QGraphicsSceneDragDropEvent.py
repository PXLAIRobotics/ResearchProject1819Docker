# encoding: utf-8
# module PyQt5.QtWidgets
# from /usr/lib/python2.7/dist-packages/PyQt5/QtWidgets.x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore
import PyQt5.QtGui as __PyQt5_QtGui


from QGraphicsSceneEvent import QGraphicsSceneEvent

class QGraphicsSceneDragDropEvent(QGraphicsSceneEvent):
    # no doc
    def acceptProposedAction(self): # real signature unknown; restored from __doc__
        """ acceptProposedAction(self) """
        pass

    def buttons(self): # real signature unknown; restored from __doc__
        """ buttons(self) -> Qt.MouseButtons """
        pass

    def dropAction(self): # real signature unknown; restored from __doc__
        """ dropAction(self) -> Qt.DropAction """
        pass

    def mimeData(self): # real signature unknown; restored from __doc__
        """ mimeData(self) -> QMimeData """
        pass

    def modifiers(self): # real signature unknown; restored from __doc__
        """ modifiers(self) -> Qt.KeyboardModifiers """
        pass

    def pos(self): # real signature unknown; restored from __doc__
        """ pos(self) -> QPointF """
        pass

    def possibleActions(self): # real signature unknown; restored from __doc__
        """ possibleActions(self) -> Qt.DropActions """
        pass

    def proposedAction(self): # real signature unknown; restored from __doc__
        """ proposedAction(self) -> Qt.DropAction """
        pass

    def scenePos(self): # real signature unknown; restored from __doc__
        """ scenePos(self) -> QPointF """
        pass

    def screenPos(self): # real signature unknown; restored from __doc__
        """ screenPos(self) -> QPoint """
        pass

    def setDropAction(self, Qt_DropAction): # real signature unknown; restored from __doc__
        """ setDropAction(self, Qt.DropAction) """
        pass

    def source(self): # real signature unknown; restored from __doc__
        """ source(self) -> QWidget """
        return QWidget

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


