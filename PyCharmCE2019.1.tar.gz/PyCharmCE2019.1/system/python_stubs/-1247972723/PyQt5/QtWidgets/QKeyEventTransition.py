# encoding: utf-8
# module PyQt5.QtWidgets
# from /usr/lib/python2.7/dist-packages/PyQt5/QtWidgets.x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore
import PyQt5.QtGui as __PyQt5_QtGui


class QKeyEventTransition(__PyQt5_QtCore.QEventTransition):
    """
    QKeyEventTransition(sourceState: QState = None)
    QKeyEventTransition(QObject, QEvent.Type, int, sourceState: QState = None)
    """
    def eventTest(self, QEvent): # real signature unknown; restored from __doc__
        """ eventTest(self, QEvent) -> bool """
        return False

    def key(self): # real signature unknown; restored from __doc__
        """ key(self) -> int """
        return 0

    def modifierMask(self): # real signature unknown; restored from __doc__
        """ modifierMask(self) -> Qt.KeyboardModifiers """
        pass

    def onTransition(self, QEvent): # real signature unknown; restored from __doc__
        """ onTransition(self, QEvent) """
        pass

    def setKey(self, p_int): # real signature unknown; restored from __doc__
        """ setKey(self, int) """
        pass

    def setModifierMask(self, Union, Qt_KeyboardModifiers=None, Qt_KeyboardModifier=None): # real signature unknown; restored from __doc__
        """ setModifierMask(self, Union[Qt.KeyboardModifiers, Qt.KeyboardModifier]) """
        pass

    def __init__(self, *__args): # real signature unknown; restored from __doc__ with multiple overloads
        pass


