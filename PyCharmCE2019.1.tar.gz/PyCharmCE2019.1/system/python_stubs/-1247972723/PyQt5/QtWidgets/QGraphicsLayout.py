# encoding: utf-8
# module PyQt5.QtWidgets
# from /usr/lib/python2.7/dist-packages/PyQt5/QtWidgets.x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore
import PyQt5.QtGui as __PyQt5_QtGui


from QGraphicsLayoutItem import QGraphicsLayoutItem

class QGraphicsLayout(QGraphicsLayoutItem):
    """ QGraphicsLayout(parent: QGraphicsLayoutItem = None) """
    def activate(self): # real signature unknown; restored from __doc__
        """ activate(self) """
        pass

    def addChildLayoutItem(self, QGraphicsLayoutItem): # real signature unknown; restored from __doc__
        """ addChildLayoutItem(self, QGraphicsLayoutItem) """
        pass

    def count(self): # real signature unknown; restored from __doc__
        """ count(self) -> int """
        return 0

    def getContentsMargins(self): # real signature unknown; restored from __doc__
        """ getContentsMargins(self) -> Tuple[float, float, float, float] """
        pass

    def invalidate(self): # real signature unknown; restored from __doc__
        """ invalidate(self) """
        pass

    def isActivated(self): # real signature unknown; restored from __doc__
        """ isActivated(self) -> bool """
        return False

    def itemAt(self, p_int): # real signature unknown; restored from __doc__
        """ itemAt(self, int) -> QGraphicsLayoutItem """
        return QGraphicsLayoutItem

    def removeAt(self, p_int): # real signature unknown; restored from __doc__
        """ removeAt(self, int) """
        pass

    def setContentsMargins(self, p_float, p_float_1, p_float_2, p_float_3): # real signature unknown; restored from __doc__
        """ setContentsMargins(self, float, float, float, float) """
        pass

    def updateGeometry(self): # real signature unknown; restored from __doc__
        """ updateGeometry(self) """
        pass

    def widgetEvent(self, QEvent): # real signature unknown; restored from __doc__
        """ widgetEvent(self, QEvent) """
        pass

    def __init__(self, parent=None): # real signature unknown; restored from __doc__
        pass

    def __len__(self): # real signature unknown; restored from __doc__
        """ x.__len__() <==> len(x) """
        pass


