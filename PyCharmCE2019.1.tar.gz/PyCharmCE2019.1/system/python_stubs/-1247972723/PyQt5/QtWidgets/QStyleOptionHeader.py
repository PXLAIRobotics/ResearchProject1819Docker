# encoding: utf-8
# module PyQt5.QtWidgets
# from /usr/lib/python2.7/dist-packages/PyQt5/QtWidgets.x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore
import PyQt5.QtGui as __PyQt5_QtGui


from QStyleOption import QStyleOption

class QStyleOptionHeader(QStyleOption):
    """
    QStyleOptionHeader()
    QStyleOptionHeader(QStyleOptionHeader)
    """
    def __init__(self, QStyleOptionHeader=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    Beginning = 0
    End = 2
    Middle = 1
    NextAndPreviousAreSelected = 3
    NextIsSelected = 1
    None_ = 0
    NotAdjacent = 0
    OnlyOneSection = 3
    PreviousIsSelected = 2
    SortDown = 2
    SortUp = 1
    Type = 8
    Version = 1


