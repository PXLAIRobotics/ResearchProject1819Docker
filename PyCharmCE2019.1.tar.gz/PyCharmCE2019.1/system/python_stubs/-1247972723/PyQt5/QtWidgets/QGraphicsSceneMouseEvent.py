# encoding: utf-8
# module PyQt5.QtWidgets
# from /usr/lib/python2.7/dist-packages/PyQt5/QtWidgets.x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore
import PyQt5.QtGui as __PyQt5_QtGui


from QGraphicsSceneEvent import QGraphicsSceneEvent

class QGraphicsSceneMouseEvent(QGraphicsSceneEvent):
    # no doc
    def button(self): # real signature unknown; restored from __doc__
        """ button(self) -> Qt.MouseButton """
        pass

    def buttonDownPos(self, Qt_MouseButton): # real signature unknown; restored from __doc__
        """ buttonDownPos(self, Qt.MouseButton) -> QPointF """
        pass

    def buttonDownScenePos(self, Qt_MouseButton): # real signature unknown; restored from __doc__
        """ buttonDownScenePos(self, Qt.MouseButton) -> QPointF """
        pass

    def buttonDownScreenPos(self, Qt_MouseButton): # real signature unknown; restored from __doc__
        """ buttonDownScreenPos(self, Qt.MouseButton) -> QPoint """
        pass

    def buttons(self): # real signature unknown; restored from __doc__
        """ buttons(self) -> Qt.MouseButtons """
        pass

    def flags(self): # real signature unknown; restored from __doc__
        """ flags(self) -> Qt.MouseEventFlags """
        pass

    def lastPos(self): # real signature unknown; restored from __doc__
        """ lastPos(self) -> QPointF """
        pass

    def lastScenePos(self): # real signature unknown; restored from __doc__
        """ lastScenePos(self) -> QPointF """
        pass

    def lastScreenPos(self): # real signature unknown; restored from __doc__
        """ lastScreenPos(self) -> QPoint """
        pass

    def modifiers(self): # real signature unknown; restored from __doc__
        """ modifiers(self) -> Qt.KeyboardModifiers """
        pass

    def pos(self): # real signature unknown; restored from __doc__
        """ pos(self) -> QPointF """
        pass

    def scenePos(self): # real signature unknown; restored from __doc__
        """ scenePos(self) -> QPointF """
        pass

    def screenPos(self): # real signature unknown; restored from __doc__
        """ screenPos(self) -> QPoint """
        pass

    def source(self): # real signature unknown; restored from __doc__
        """ source(self) -> Qt.MouseEventSource """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


