# encoding: utf-8
# module PyQt5.QtWidgets
# from /usr/lib/python2.7/dist-packages/PyQt5/QtWidgets.x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore
import PyQt5.QtGui as __PyQt5_QtGui


class QToolTip(): # skipped bases: <type 'sip.simplewrapper'>
    """ QToolTip(QToolTip) """
    def font(self): # real signature unknown; restored from __doc__
        """ font() -> QFont """
        pass

    def hideText(self): # real signature unknown; restored from __doc__
        """ hideText() """
        pass

    def isVisible(self): # real signature unknown; restored from __doc__
        """ isVisible() -> bool """
        return False

    def palette(self): # real signature unknown; restored from __doc__
        """ palette() -> QPalette """
        pass

    def setFont(self, QFont): # real signature unknown; restored from __doc__
        """ setFont(QFont) """
        pass

    def setPalette(self, QPalette): # real signature unknown; restored from __doc__
        """ setPalette(QPalette) """
        pass

    def showText(self, QPoint, p_str, *__args): # real signature unknown; restored from __doc__ with multiple overloads
        """
        showText(QPoint, str, widget: QWidget = None)
        showText(QPoint, str, QWidget, QRect)
        showText(QPoint, str, QWidget, QRect, int)
        """
        pass

    def text(self): # real signature unknown; restored from __doc__
        """ text() -> str """
        return ""

    def __init__(self, QToolTip): # real signature unknown; restored from __doc__
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



