# encoding: utf-8
# module PyQt5.QtWidgets
# from /usr/lib/python2.7/dist-packages/PyQt5/QtWidgets.x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore
import PyQt5.QtGui as __PyQt5_QtGui


class QStyleFactory(): # skipped bases: <type 'sip.simplewrapper'>
    """
    QStyleFactory()
    QStyleFactory(QStyleFactory)
    """
    def create(self, p_str): # real signature unknown; restored from __doc__
        """ create(str) -> QStyle """
        return QStyle

    def keys(self): # real signature unknown; restored from __doc__
        """ keys() -> List[str] """
        return []

    def __init__(self, QStyleFactory=None): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



