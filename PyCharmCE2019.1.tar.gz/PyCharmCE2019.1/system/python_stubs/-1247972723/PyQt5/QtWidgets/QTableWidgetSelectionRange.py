# encoding: utf-8
# module PyQt5.QtWidgets
# from /usr/lib/python2.7/dist-packages/PyQt5/QtWidgets.x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore
import PyQt5.QtGui as __PyQt5_QtGui


class QTableWidgetSelectionRange(): # skipped bases: <type 'sip.simplewrapper'>
    """
    QTableWidgetSelectionRange()
    QTableWidgetSelectionRange(int, int, int, int)
    QTableWidgetSelectionRange(QTableWidgetSelectionRange)
    """
    def bottomRow(self): # real signature unknown; restored from __doc__
        """ bottomRow(self) -> int """
        return 0

    def columnCount(self): # real signature unknown; restored from __doc__
        """ columnCount(self) -> int """
        return 0

    def leftColumn(self): # real signature unknown; restored from __doc__
        """ leftColumn(self) -> int """
        return 0

    def rightColumn(self): # real signature unknown; restored from __doc__
        """ rightColumn(self) -> int """
        return 0

    def rowCount(self): # real signature unknown; restored from __doc__
        """ rowCount(self) -> int """
        return 0

    def topRow(self): # real signature unknown; restored from __doc__
        """ topRow(self) -> int """
        return 0

    def __init__(self, *__args): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



