# encoding: utf-8
# module PyQt5.QtWidgets
# from /usr/lib/python2.7/dist-packages/PyQt5/QtWidgets.x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import PyQt5.QtCore as __PyQt5_QtCore
import PyQt5.QtGui as __PyQt5_QtGui


class QStyleOption(): # skipped bases: <type 'sip.simplewrapper'>
    """
    QStyleOption(version: int = QStyleOption.Version, type: int = QStyleOption.SO_Default)
    QStyleOption(QStyleOption)
    """
    def initFrom(self, QWidget): # real signature unknown; restored from __doc__
        """ initFrom(self, QWidget) """
        pass

    def __init__(self, *__args): # real signature unknown; restored from __doc__ with multiple overloads
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    SO_Button = 2
    SO_ComboBox = 983044
    SO_Complex = 983040
    SO_ComplexCustomBase = 251658240
    SO_CustomBase = 3840
    SO_Default = 0
    SO_DockWidget = 9
    SO_FocusRect = 1
    SO_Frame = 5
    SO_GraphicsItem = 15
    SO_GroupBox = 983046
    SO_Header = 8
    SO_MenuItem = 4
    SO_ProgressBar = 6
    SO_RubberBand = 13
    SO_SizeGrip = 983047
    SO_Slider = 983041
    SO_SpinBox = 983042
    SO_Tab = 3
    SO_TabBarBase = 12
    SO_TabWidgetFrame = 11
    SO_TitleBar = 983045
    SO_ToolBar = 14
    SO_ToolBox = 7
    SO_ToolButton = 983043
    SO_ViewItem = 10
    Type = 0
    Version = 1


