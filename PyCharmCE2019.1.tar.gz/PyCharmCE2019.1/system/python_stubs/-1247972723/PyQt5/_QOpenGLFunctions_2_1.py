# encoding: utf-8
# module PyQt5._QOpenGLFunctions_2_1
# from /usr/lib/python2.7/dist-packages/PyQt5/_QOpenGLFunctions_2_1.x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import PyQt5.QtGui as __PyQt5_QtGui


# no functions
# classes

class QOpenGLFunctions_2_1(__PyQt5_QtGui.QAbstractOpenGLFunctions):
    # no doc
    def glAccum(self, *args, **kwargs): # real signature unknown
        pass

    def glActiveTexture(self, *args, **kwargs): # real signature unknown
        pass

    def glAlphaFunc(self, *args, **kwargs): # real signature unknown
        pass

    def glArrayElement(self, *args, **kwargs): # real signature unknown
        pass

    def glAttachShader(self, *args, **kwargs): # real signature unknown
        pass

    def glBegin(self, *args, **kwargs): # real signature unknown
        pass

    def glBeginQuery(self, *args, **kwargs): # real signature unknown
        pass

    def glBindAttribLocation(self, *args, **kwargs): # real signature unknown
        pass

    def glBindBuffer(self, *args, **kwargs): # real signature unknown
        pass

    def glBindTexture(self, *args, **kwargs): # real signature unknown
        pass

    def glBitmap(self, *args, **kwargs): # real signature unknown
        pass

    def glBlendColor(self, *args, **kwargs): # real signature unknown
        pass

    def glBlendEquation(self, *args, **kwargs): # real signature unknown
        pass

    def glBlendEquationSeparate(self, *args, **kwargs): # real signature unknown
        pass

    def glBlendFunc(self, *args, **kwargs): # real signature unknown
        pass

    def glBlendFuncSeparate(self, *args, **kwargs): # real signature unknown
        pass

    def glBufferData(self, *args, **kwargs): # real signature unknown
        pass

    def glBufferSubData(self, *args, **kwargs): # real signature unknown
        pass

    def glCallList(self, *args, **kwargs): # real signature unknown
        pass

    def glClear(self, *args, **kwargs): # real signature unknown
        pass

    def glClearAccum(self, *args, **kwargs): # real signature unknown
        pass

    def glClearColor(self, *args, **kwargs): # real signature unknown
        pass

    def glClearDepth(self, *args, **kwargs): # real signature unknown
        pass

    def glClearIndex(self, *args, **kwargs): # real signature unknown
        pass

    def glClearStencil(self, *args, **kwargs): # real signature unknown
        pass

    def glClientActiveTexture(self, *args, **kwargs): # real signature unknown
        pass

    def glClipPlane(self, *args, **kwargs): # real signature unknown
        pass

    def glColor3b(self, *args, **kwargs): # real signature unknown
        pass

    def glColor3bv(self, *args, **kwargs): # real signature unknown
        pass

    def glColor3d(self, *args, **kwargs): # real signature unknown
        pass

    def glColor3dv(self, *args, **kwargs): # real signature unknown
        pass

    def glColor3f(self, *args, **kwargs): # real signature unknown
        pass

    def glColor3fv(self, *args, **kwargs): # real signature unknown
        pass

    def glColor3i(self, *args, **kwargs): # real signature unknown
        pass

    def glColor3iv(self, *args, **kwargs): # real signature unknown
        pass

    def glColor3s(self, *args, **kwargs): # real signature unknown
        pass

    def glColor3sv(self, *args, **kwargs): # real signature unknown
        pass

    def glColor3ub(self, *args, **kwargs): # real signature unknown
        pass

    def glColor3ubv(self, *args, **kwargs): # real signature unknown
        pass

    def glColor3ui(self, *args, **kwargs): # real signature unknown
        pass

    def glColor3uiv(self, *args, **kwargs): # real signature unknown
        pass

    def glColor3us(self, *args, **kwargs): # real signature unknown
        pass

    def glColor3usv(self, *args, **kwargs): # real signature unknown
        pass

    def glColor4b(self, *args, **kwargs): # real signature unknown
        pass

    def glColor4bv(self, *args, **kwargs): # real signature unknown
        pass

    def glColor4d(self, *args, **kwargs): # real signature unknown
        pass

    def glColor4dv(self, *args, **kwargs): # real signature unknown
        pass

    def glColor4f(self, *args, **kwargs): # real signature unknown
        pass

    def glColor4fv(self, *args, **kwargs): # real signature unknown
        pass

    def glColor4i(self, *args, **kwargs): # real signature unknown
        pass

    def glColor4iv(self, *args, **kwargs): # real signature unknown
        pass

    def glColor4s(self, *args, **kwargs): # real signature unknown
        pass

    def glColor4sv(self, *args, **kwargs): # real signature unknown
        pass

    def glColor4ub(self, *args, **kwargs): # real signature unknown
        pass

    def glColor4ubv(self, *args, **kwargs): # real signature unknown
        pass

    def glColor4ui(self, *args, **kwargs): # real signature unknown
        pass

    def glColor4uiv(self, *args, **kwargs): # real signature unknown
        pass

    def glColor4us(self, *args, **kwargs): # real signature unknown
        pass

    def glColor4usv(self, *args, **kwargs): # real signature unknown
        pass

    def glColorMask(self, *args, **kwargs): # real signature unknown
        pass

    def glColorMaterial(self, *args, **kwargs): # real signature unknown
        pass

    def glColorPointer(self, *args, **kwargs): # real signature unknown
        pass

    def glColorSubTable(self, *args, **kwargs): # real signature unknown
        pass

    def glColorTable(self, *args, **kwargs): # real signature unknown
        pass

    def glColorTableParameterfv(self, *args, **kwargs): # real signature unknown
        pass

    def glColorTableParameteriv(self, *args, **kwargs): # real signature unknown
        pass

    def glCompileShader(self, *args, **kwargs): # real signature unknown
        pass

    def glCompressedTexImage1D(self, *args, **kwargs): # real signature unknown
        pass

    def glCompressedTexImage2D(self, *args, **kwargs): # real signature unknown
        pass

    def glCompressedTexImage3D(self, *args, **kwargs): # real signature unknown
        pass

    def glCompressedTexSubImage1D(self, *args, **kwargs): # real signature unknown
        pass

    def glCompressedTexSubImage2D(self, *args, **kwargs): # real signature unknown
        pass

    def glCompressedTexSubImage3D(self, *args, **kwargs): # real signature unknown
        pass

    def glConvolutionFilter1D(self, *args, **kwargs): # real signature unknown
        pass

    def glConvolutionFilter2D(self, *args, **kwargs): # real signature unknown
        pass

    def glConvolutionParameterf(self, *args, **kwargs): # real signature unknown
        pass

    def glConvolutionParameterfv(self, *args, **kwargs): # real signature unknown
        pass

    def glConvolutionParameteri(self, *args, **kwargs): # real signature unknown
        pass

    def glConvolutionParameteriv(self, *args, **kwargs): # real signature unknown
        pass

    def glCopyColorSubTable(self, *args, **kwargs): # real signature unknown
        pass

    def glCopyColorTable(self, *args, **kwargs): # real signature unknown
        pass

    def glCopyConvolutionFilter1D(self, *args, **kwargs): # real signature unknown
        pass

    def glCopyConvolutionFilter2D(self, *args, **kwargs): # real signature unknown
        pass

    def glCopyPixels(self, *args, **kwargs): # real signature unknown
        pass

    def glCopyTexImage1D(self, *args, **kwargs): # real signature unknown
        pass

    def glCopyTexImage2D(self, *args, **kwargs): # real signature unknown
        pass

    def glCopyTexSubImage1D(self, *args, **kwargs): # real signature unknown
        pass

    def glCopyTexSubImage2D(self, *args, **kwargs): # real signature unknown
        pass

    def glCopyTexSubImage3D(self, *args, **kwargs): # real signature unknown
        pass

    def glCreateProgram(self, *args, **kwargs): # real signature unknown
        pass

    def glCreateShader(self, *args, **kwargs): # real signature unknown
        pass

    def glCullFace(self, *args, **kwargs): # real signature unknown
        pass

    def glDeleteBuffers(self, *args, **kwargs): # real signature unknown
        pass

    def glDeleteLists(self, *args, **kwargs): # real signature unknown
        pass

    def glDeleteProgram(self, *args, **kwargs): # real signature unknown
        pass

    def glDeleteQueries(self, *args, **kwargs): # real signature unknown
        pass

    def glDeleteShader(self, *args, **kwargs): # real signature unknown
        pass

    def glDeleteTextures(self, *args, **kwargs): # real signature unknown
        pass

    def glDepthFunc(self, *args, **kwargs): # real signature unknown
        pass

    def glDepthMask(self, *args, **kwargs): # real signature unknown
        pass

    def glDepthRange(self, *args, **kwargs): # real signature unknown
        pass

    def glDetachShader(self, *args, **kwargs): # real signature unknown
        pass

    def glDisable(self, *args, **kwargs): # real signature unknown
        pass

    def glDisableClientState(self, *args, **kwargs): # real signature unknown
        pass

    def glDisableVertexAttribArray(self, *args, **kwargs): # real signature unknown
        pass

    def glDrawArrays(self, *args, **kwargs): # real signature unknown
        pass

    def glDrawBuffer(self, *args, **kwargs): # real signature unknown
        pass

    def glDrawBuffers(self, *args, **kwargs): # real signature unknown
        pass

    def glDrawElements(self, *args, **kwargs): # real signature unknown
        pass

    def glDrawPixels(self, *args, **kwargs): # real signature unknown
        pass

    def glDrawRangeElements(self, *args, **kwargs): # real signature unknown
        pass

    def glEdgeFlag(self, *args, **kwargs): # real signature unknown
        pass

    def glEdgeFlagPointer(self, *args, **kwargs): # real signature unknown
        pass

    def glEdgeFlagv(self, *args, **kwargs): # real signature unknown
        pass

    def glEnable(self, *args, **kwargs): # real signature unknown
        pass

    def glEnableClientState(self, *args, **kwargs): # real signature unknown
        pass

    def glEnableVertexAttribArray(self, *args, **kwargs): # real signature unknown
        pass

    def glEnd(self, *args, **kwargs): # real signature unknown
        pass

    def glEndList(self, *args, **kwargs): # real signature unknown
        pass

    def glEndQuery(self, *args, **kwargs): # real signature unknown
        pass

    def glEvalCoord1d(self, *args, **kwargs): # real signature unknown
        pass

    def glEvalCoord1dv(self, *args, **kwargs): # real signature unknown
        pass

    def glEvalCoord1f(self, *args, **kwargs): # real signature unknown
        pass

    def glEvalCoord1fv(self, *args, **kwargs): # real signature unknown
        pass

    def glEvalCoord2d(self, *args, **kwargs): # real signature unknown
        pass

    def glEvalCoord2dv(self, *args, **kwargs): # real signature unknown
        pass

    def glEvalCoord2f(self, *args, **kwargs): # real signature unknown
        pass

    def glEvalCoord2fv(self, *args, **kwargs): # real signature unknown
        pass

    def glEvalMesh1(self, *args, **kwargs): # real signature unknown
        pass

    def glEvalMesh2(self, *args, **kwargs): # real signature unknown
        pass

    def glEvalPoint1(self, *args, **kwargs): # real signature unknown
        pass

    def glEvalPoint2(self, *args, **kwargs): # real signature unknown
        pass

    def glFinish(self, *args, **kwargs): # real signature unknown
        pass

    def glFlush(self, *args, **kwargs): # real signature unknown
        pass

    def glFogCoordd(self, *args, **kwargs): # real signature unknown
        pass

    def glFogCoorddv(self, *args, **kwargs): # real signature unknown
        pass

    def glFogCoordf(self, *args, **kwargs): # real signature unknown
        pass

    def glFogCoordfv(self, *args, **kwargs): # real signature unknown
        pass

    def glFogCoordPointer(self, *args, **kwargs): # real signature unknown
        pass

    def glFogf(self, *args, **kwargs): # real signature unknown
        pass

    def glFogfv(self, *args, **kwargs): # real signature unknown
        pass

    def glFogi(self, *args, **kwargs): # real signature unknown
        pass

    def glFogiv(self, *args, **kwargs): # real signature unknown
        pass

    def glFrontFace(self, *args, **kwargs): # real signature unknown
        pass

    def glFrustum(self, *args, **kwargs): # real signature unknown
        pass

    def glGenBuffers(self, *args, **kwargs): # real signature unknown
        pass

    def glGenLists(self, *args, **kwargs): # real signature unknown
        pass

    def glGenQueries(self, *args, **kwargs): # real signature unknown
        pass

    def glGenTextures(self, *args, **kwargs): # real signature unknown
        pass

    def glGetActiveAttrib(self, *args, **kwargs): # real signature unknown
        pass

    def glGetActiveUniform(self, *args, **kwargs): # real signature unknown
        pass

    def glGetAttachedShaders(self, *args, **kwargs): # real signature unknown
        pass

    def glGetAttribLocation(self, *args, **kwargs): # real signature unknown
        pass

    def glGetBooleanv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetBufferParameteriv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetClipPlane(self, *args, **kwargs): # real signature unknown
        pass

    def glGetColorTableParameterfv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetColorTableParameteriv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetConvolutionParameterfv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetConvolutionParameteriv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetDoublev(self, *args, **kwargs): # real signature unknown
        pass

    def glGetError(self, *args, **kwargs): # real signature unknown
        pass

    def glGetFloatv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetIntegerv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetLightfv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetLightiv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetMaterialfv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetMaterialiv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetProgramInfoLog(self, *args, **kwargs): # real signature unknown
        pass

    def glGetProgramiv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetQueryiv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetShaderInfoLog(self, *args, **kwargs): # real signature unknown
        pass

    def glGetShaderiv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetShaderSource(self, *args, **kwargs): # real signature unknown
        pass

    def glGetString(self, *args, **kwargs): # real signature unknown
        pass

    def glGetTexEnvfv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetTexEnviv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetTexGendv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetTexGenfv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetTexGeniv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetTexLevelParameterfv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetTexLevelParameteriv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetTexParameterfv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetTexParameteriv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetUniformLocation(self, *args, **kwargs): # real signature unknown
        pass

    def glGetVertexAttribdv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetVertexAttribfv(self, *args, **kwargs): # real signature unknown
        pass

    def glGetVertexAttribiv(self, *args, **kwargs): # real signature unknown
        pass

    def glHint(self, *args, **kwargs): # real signature unknown
        pass

    def glHistogram(self, *args, **kwargs): # real signature unknown
        pass

    def glIndexd(self, *args, **kwargs): # real signature unknown
        pass

    def glIndexdv(self, *args, **kwargs): # real signature unknown
        pass

    def glIndexf(self, *args, **kwargs): # real signature unknown
        pass

    def glIndexfv(self, *args, **kwargs): # real signature unknown
        pass

    def glIndexi(self, *args, **kwargs): # real signature unknown
        pass

    def glIndexiv(self, *args, **kwargs): # real signature unknown
        pass

    def glIndexMask(self, *args, **kwargs): # real signature unknown
        pass

    def glIndexPointer(self, *args, **kwargs): # real signature unknown
        pass

    def glIndexs(self, *args, **kwargs): # real signature unknown
        pass

    def glIndexsv(self, *args, **kwargs): # real signature unknown
        pass

    def glIndexub(self, *args, **kwargs): # real signature unknown
        pass

    def glIndexubv(self, *args, **kwargs): # real signature unknown
        pass

    def glInitNames(self, *args, **kwargs): # real signature unknown
        pass

    def glIsBuffer(self, *args, **kwargs): # real signature unknown
        pass

    def glIsEnabled(self, *args, **kwargs): # real signature unknown
        pass

    def glIsList(self, *args, **kwargs): # real signature unknown
        pass

    def glIsProgram(self, *args, **kwargs): # real signature unknown
        pass

    def glIsQuery(self, *args, **kwargs): # real signature unknown
        pass

    def glIsShader(self, *args, **kwargs): # real signature unknown
        pass

    def glIsTexture(self, *args, **kwargs): # real signature unknown
        pass

    def glLightf(self, *args, **kwargs): # real signature unknown
        pass

    def glLightfv(self, *args, **kwargs): # real signature unknown
        pass

    def glLighti(self, *args, **kwargs): # real signature unknown
        pass

    def glLightiv(self, *args, **kwargs): # real signature unknown
        pass

    def glLightModelf(self, *args, **kwargs): # real signature unknown
        pass

    def glLightModelfv(self, *args, **kwargs): # real signature unknown
        pass

    def glLightModeli(self, *args, **kwargs): # real signature unknown
        pass

    def glLightModeliv(self, *args, **kwargs): # real signature unknown
        pass

    def glLineStipple(self, *args, **kwargs): # real signature unknown
        pass

    def glLineWidth(self, *args, **kwargs): # real signature unknown
        pass

    def glLinkProgram(self, *args, **kwargs): # real signature unknown
        pass

    def glListBase(self, *args, **kwargs): # real signature unknown
        pass

    def glLoadIdentity(self, *args, **kwargs): # real signature unknown
        pass

    def glLoadMatrixd(self, *args, **kwargs): # real signature unknown
        pass

    def glLoadMatrixf(self, *args, **kwargs): # real signature unknown
        pass

    def glLoadName(self, *args, **kwargs): # real signature unknown
        pass

    def glLoadTransposeMatrixd(self, *args, **kwargs): # real signature unknown
        pass

    def glLoadTransposeMatrixf(self, *args, **kwargs): # real signature unknown
        pass

    def glLogicOp(self, *args, **kwargs): # real signature unknown
        pass

    def glMap1d(self, *args, **kwargs): # real signature unknown
        pass

    def glMap1f(self, *args, **kwargs): # real signature unknown
        pass

    def glMap2d(self, *args, **kwargs): # real signature unknown
        pass

    def glMap2f(self, *args, **kwargs): # real signature unknown
        pass

    def glMapGrid1d(self, *args, **kwargs): # real signature unknown
        pass

    def glMapGrid1f(self, *args, **kwargs): # real signature unknown
        pass

    def glMapGrid2d(self, *args, **kwargs): # real signature unknown
        pass

    def glMapGrid2f(self, *args, **kwargs): # real signature unknown
        pass

    def glMaterialf(self, *args, **kwargs): # real signature unknown
        pass

    def glMaterialfv(self, *args, **kwargs): # real signature unknown
        pass

    def glMateriali(self, *args, **kwargs): # real signature unknown
        pass

    def glMaterialiv(self, *args, **kwargs): # real signature unknown
        pass

    def glMatrixMode(self, *args, **kwargs): # real signature unknown
        pass

    def glMinmax(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord1d(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord1dv(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord1f(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord1fv(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord1i(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord1iv(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord1s(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord1sv(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord2d(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord2dv(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord2f(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord2fv(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord2i(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord2iv(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord2s(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord2sv(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord3d(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord3dv(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord3f(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord3fv(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord3i(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord3iv(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord3s(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord3sv(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord4d(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord4dv(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord4f(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord4fv(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord4i(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord4iv(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord4s(self, *args, **kwargs): # real signature unknown
        pass

    def glMultiTexCoord4sv(self, *args, **kwargs): # real signature unknown
        pass

    def glMultMatrixd(self, *args, **kwargs): # real signature unknown
        pass

    def glMultMatrixf(self, *args, **kwargs): # real signature unknown
        pass

    def glMultTransposeMatrixd(self, *args, **kwargs): # real signature unknown
        pass

    def glMultTransposeMatrixf(self, *args, **kwargs): # real signature unknown
        pass

    def glNewList(self, *args, **kwargs): # real signature unknown
        pass

    def glNormal3b(self, *args, **kwargs): # real signature unknown
        pass

    def glNormal3bv(self, *args, **kwargs): # real signature unknown
        pass

    def glNormal3d(self, *args, **kwargs): # real signature unknown
        pass

    def glNormal3dv(self, *args, **kwargs): # real signature unknown
        pass

    def glNormal3f(self, *args, **kwargs): # real signature unknown
        pass

    def glNormal3fv(self, *args, **kwargs): # real signature unknown
        pass

    def glNormal3i(self, *args, **kwargs): # real signature unknown
        pass

    def glNormal3iv(self, *args, **kwargs): # real signature unknown
        pass

    def glNormal3s(self, *args, **kwargs): # real signature unknown
        pass

    def glNormal3sv(self, *args, **kwargs): # real signature unknown
        pass

    def glNormalPointer(self, *args, **kwargs): # real signature unknown
        pass

    def glOrtho(self, *args, **kwargs): # real signature unknown
        pass

    def glPassThrough(self, *args, **kwargs): # real signature unknown
        pass

    def glPixelMapfv(self, *args, **kwargs): # real signature unknown
        pass

    def glPixelMapuiv(self, *args, **kwargs): # real signature unknown
        pass

    def glPixelMapusv(self, *args, **kwargs): # real signature unknown
        pass

    def glPixelStoref(self, *args, **kwargs): # real signature unknown
        pass

    def glPixelStorei(self, *args, **kwargs): # real signature unknown
        pass

    def glPixelTransferf(self, *args, **kwargs): # real signature unknown
        pass

    def glPixelTransferi(self, *args, **kwargs): # real signature unknown
        pass

    def glPixelZoom(self, *args, **kwargs): # real signature unknown
        pass

    def glPointParameterf(self, *args, **kwargs): # real signature unknown
        pass

    def glPointParameterfv(self, *args, **kwargs): # real signature unknown
        pass

    def glPointParameteri(self, *args, **kwargs): # real signature unknown
        pass

    def glPointParameteriv(self, *args, **kwargs): # real signature unknown
        pass

    def glPointSize(self, *args, **kwargs): # real signature unknown
        pass

    def glPolygonMode(self, *args, **kwargs): # real signature unknown
        pass

    def glPolygonOffset(self, *args, **kwargs): # real signature unknown
        pass

    def glPolygonStipple(self, *args, **kwargs): # real signature unknown
        pass

    def glPopAttrib(self, *args, **kwargs): # real signature unknown
        pass

    def glPopClientAttrib(self, *args, **kwargs): # real signature unknown
        pass

    def glPopMatrix(self, *args, **kwargs): # real signature unknown
        pass

    def glPopName(self, *args, **kwargs): # real signature unknown
        pass

    def glPushAttrib(self, *args, **kwargs): # real signature unknown
        pass

    def glPushClientAttrib(self, *args, **kwargs): # real signature unknown
        pass

    def glPushMatrix(self, *args, **kwargs): # real signature unknown
        pass

    def glPushName(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos2d(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos2dv(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos2f(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos2fv(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos2i(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos2iv(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos2s(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos2sv(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos3d(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos3dv(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos3f(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos3fv(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos3i(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos3iv(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos3s(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos3sv(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos4d(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos4dv(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos4f(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos4fv(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos4i(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos4iv(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos4s(self, *args, **kwargs): # real signature unknown
        pass

    def glRasterPos4sv(self, *args, **kwargs): # real signature unknown
        pass

    def glReadBuffer(self, *args, **kwargs): # real signature unknown
        pass

    def glRectd(self, *args, **kwargs): # real signature unknown
        pass

    def glRectf(self, *args, **kwargs): # real signature unknown
        pass

    def glRecti(self, *args, **kwargs): # real signature unknown
        pass

    def glRects(self, *args, **kwargs): # real signature unknown
        pass

    def glRenderMode(self, *args, **kwargs): # real signature unknown
        pass

    def glResetHistogram(self, *args, **kwargs): # real signature unknown
        pass

    def glResetMinmax(self, *args, **kwargs): # real signature unknown
        pass

    def glRotated(self, *args, **kwargs): # real signature unknown
        pass

    def glRotatef(self, *args, **kwargs): # real signature unknown
        pass

    def glSampleCoverage(self, *args, **kwargs): # real signature unknown
        pass

    def glScaled(self, *args, **kwargs): # real signature unknown
        pass

    def glScalef(self, *args, **kwargs): # real signature unknown
        pass

    def glScissor(self, *args, **kwargs): # real signature unknown
        pass

    def glSecondaryColor3b(self, *args, **kwargs): # real signature unknown
        pass

    def glSecondaryColor3bv(self, *args, **kwargs): # real signature unknown
        pass

    def glSecondaryColor3d(self, *args, **kwargs): # real signature unknown
        pass

    def glSecondaryColor3dv(self, *args, **kwargs): # real signature unknown
        pass

    def glSecondaryColor3f(self, *args, **kwargs): # real signature unknown
        pass

    def glSecondaryColor3fv(self, *args, **kwargs): # real signature unknown
        pass

    def glSecondaryColor3i(self, *args, **kwargs): # real signature unknown
        pass

    def glSecondaryColor3iv(self, *args, **kwargs): # real signature unknown
        pass

    def glSecondaryColor3s(self, *args, **kwargs): # real signature unknown
        pass

    def glSecondaryColor3sv(self, *args, **kwargs): # real signature unknown
        pass

    def glSecondaryColor3ub(self, *args, **kwargs): # real signature unknown
        pass

    def glSecondaryColor3ubv(self, *args, **kwargs): # real signature unknown
        pass

    def glSecondaryColor3ui(self, *args, **kwargs): # real signature unknown
        pass

    def glSecondaryColor3uiv(self, *args, **kwargs): # real signature unknown
        pass

    def glSecondaryColor3us(self, *args, **kwargs): # real signature unknown
        pass

    def glSecondaryColor3usv(self, *args, **kwargs): # real signature unknown
        pass

    def glSecondaryColorPointer(self, *args, **kwargs): # real signature unknown
        pass

    def glShadeModel(self, *args, **kwargs): # real signature unknown
        pass

    def glStencilFunc(self, *args, **kwargs): # real signature unknown
        pass

    def glStencilFuncSeparate(self, *args, **kwargs): # real signature unknown
        pass

    def glStencilMask(self, *args, **kwargs): # real signature unknown
        pass

    def glStencilMaskSeparate(self, *args, **kwargs): # real signature unknown
        pass

    def glStencilOp(self, *args, **kwargs): # real signature unknown
        pass

    def glStencilOpSeparate(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord1d(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord1dv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord1f(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord1fv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord1i(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord1iv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord1s(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord1sv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord2d(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord2dv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord2f(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord2fv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord2i(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord2iv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord2s(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord2sv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord3d(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord3dv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord3f(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord3fv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord3i(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord3iv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord3s(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord3sv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord4d(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord4dv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord4f(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord4fv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord4i(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord4iv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord4s(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoord4sv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexCoordPointer(self, *args, **kwargs): # real signature unknown
        pass

    def glTexEnvf(self, *args, **kwargs): # real signature unknown
        pass

    def glTexEnvfv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexEnvi(self, *args, **kwargs): # real signature unknown
        pass

    def glTexEnviv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexGend(self, *args, **kwargs): # real signature unknown
        pass

    def glTexGendv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexGenf(self, *args, **kwargs): # real signature unknown
        pass

    def glTexGenfv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexGeni(self, *args, **kwargs): # real signature unknown
        pass

    def glTexGeniv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexImage1D(self, *args, **kwargs): # real signature unknown
        pass

    def glTexImage2D(self, *args, **kwargs): # real signature unknown
        pass

    def glTexImage3D(self, *args, **kwargs): # real signature unknown
        pass

    def glTexParameterf(self, *args, **kwargs): # real signature unknown
        pass

    def glTexParameterfv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexParameteri(self, *args, **kwargs): # real signature unknown
        pass

    def glTexParameteriv(self, *args, **kwargs): # real signature unknown
        pass

    def glTexSubImage1D(self, *args, **kwargs): # real signature unknown
        pass

    def glTexSubImage2D(self, *args, **kwargs): # real signature unknown
        pass

    def glTexSubImage3D(self, *args, **kwargs): # real signature unknown
        pass

    def glTranslated(self, *args, **kwargs): # real signature unknown
        pass

    def glTranslatef(self, *args, **kwargs): # real signature unknown
        pass

    def glUniform1f(self, *args, **kwargs): # real signature unknown
        pass

    def glUniform1fv(self, *args, **kwargs): # real signature unknown
        pass

    def glUniform1i(self, *args, **kwargs): # real signature unknown
        pass

    def glUniform1iv(self, *args, **kwargs): # real signature unknown
        pass

    def glUniform2f(self, *args, **kwargs): # real signature unknown
        pass

    def glUniform2fv(self, *args, **kwargs): # real signature unknown
        pass

    def glUniform2i(self, *args, **kwargs): # real signature unknown
        pass

    def glUniform2iv(self, *args, **kwargs): # real signature unknown
        pass

    def glUniform3f(self, *args, **kwargs): # real signature unknown
        pass

    def glUniform3fv(self, *args, **kwargs): # real signature unknown
        pass

    def glUniform3i(self, *args, **kwargs): # real signature unknown
        pass

    def glUniform3iv(self, *args, **kwargs): # real signature unknown
        pass

    def glUniform4f(self, *args, **kwargs): # real signature unknown
        pass

    def glUniform4fv(self, *args, **kwargs): # real signature unknown
        pass

    def glUniform4i(self, *args, **kwargs): # real signature unknown
        pass

    def glUniform4iv(self, *args, **kwargs): # real signature unknown
        pass

    def glUniformMatrix2fv(self, *args, **kwargs): # real signature unknown
        pass

    def glUniformMatrix3fv(self, *args, **kwargs): # real signature unknown
        pass

    def glUniformMatrix4fv(self, *args, **kwargs): # real signature unknown
        pass

    def glUnmapBuffer(self, *args, **kwargs): # real signature unknown
        pass

    def glUseProgram(self, *args, **kwargs): # real signature unknown
        pass

    def glValidateProgram(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex2d(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex2dv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex2f(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex2fv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex2i(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex2iv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex2s(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex2sv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex3d(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex3dv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex3f(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex3fv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex3i(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex3iv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex3s(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex3sv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex4d(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex4dv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex4f(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex4fv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex4i(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex4iv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex4s(self, *args, **kwargs): # real signature unknown
        pass

    def glVertex4sv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib1d(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib1dv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib1f(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib1fv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib1s(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib1sv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib2d(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib2dv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib2f(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib2fv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib2s(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib2sv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib3d(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib3dv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib3f(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib3fv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib3s(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib3sv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib4bv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib4d(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib4dv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib4f(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib4fv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib4iv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib4Nbv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib4Niv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib4Nsv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib4Nub(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib4Nubv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib4Nuiv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib4Nusv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib4s(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib4sv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib4ubv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib4uiv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttrib4usv(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexAttribPointer(self, *args, **kwargs): # real signature unknown
        pass

    def glVertexPointer(self, *args, **kwargs): # real signature unknown
        pass

    def glViewport(self, *args, **kwargs): # real signature unknown
        pass

    def glWindowPos2d(self, *args, **kwargs): # real signature unknown
        pass

    def glWindowPos2dv(self, *args, **kwargs): # real signature unknown
        pass

    def glWindowPos2f(self, *args, **kwargs): # real signature unknown
        pass

    def glWindowPos2fv(self, *args, **kwargs): # real signature unknown
        pass

    def glWindowPos2i(self, *args, **kwargs): # real signature unknown
        pass

    def glWindowPos2iv(self, *args, **kwargs): # real signature unknown
        pass

    def glWindowPos2s(self, *args, **kwargs): # real signature unknown
        pass

    def glWindowPos2sv(self, *args, **kwargs): # real signature unknown
        pass

    def glWindowPos3d(self, *args, **kwargs): # real signature unknown
        pass

    def glWindowPos3dv(self, *args, **kwargs): # real signature unknown
        pass

    def glWindowPos3f(self, *args, **kwargs): # real signature unknown
        pass

    def glWindowPos3fv(self, *args, **kwargs): # real signature unknown
        pass

    def glWindowPos3i(self, *args, **kwargs): # real signature unknown
        pass

    def glWindowPos3iv(self, *args, **kwargs): # real signature unknown
        pass

    def glWindowPos3s(self, *args, **kwargs): # real signature unknown
        pass

    def glWindowPos3sv(self, *args, **kwargs): # real signature unknown
        pass

    def initializeOpenGLFunctions(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


