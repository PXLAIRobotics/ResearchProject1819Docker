# encoding: utf-8
# module qt_gui_cpp.libqt_gui_cpp_sip
# from /opt/ros/melodic/lib/python2.7/dist-packages/qt_gui_cpp/libqt_gui_cpp_sip.so
# by generator 1.147
# no doc
# no imports

# no functions
# classes

class qt_gui_cpp(): # skipped bases: <type 'sip.simplewrapper'>
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    CompositePluginProvider = None # (!) real value is "<class 'libqt_gui_cpp_sip.CompositePluginProvider'>"
    GenericProxy = None # (!) real value is "<class 'libqt_gui_cpp_sip.GenericProxy'>"
    Plugin = None # (!) real value is "<class 'libqt_gui_cpp_sip.Plugin'>"
    PluginBridge = None # (!) real value is "<class 'libqt_gui_cpp_sip.PluginBridge'>"
    PluginContext = None # (!) real value is "<class 'libqt_gui_cpp_sip.PluginContext'>"
    PluginDescriptor = None # (!) real value is "<class 'libqt_gui_cpp_sip.PluginDescriptor'>"
    PluginProvider = None # (!) real value is "<class 'libqt_gui_cpp_sip.PluginProvider'>"
    RecursivePluginProvider = None # (!) real value is "<class 'libqt_gui_cpp_sip.RecursivePluginProvider'>"
    RosPluginlibPluginProvider_ForPluginProviders = None # (!) real value is "<class 'libqt_gui_cpp_sip.RosPluginlibPluginProvider_ForPluginProviders'>"
    RosPluginlibPluginProvider_ForPlugins = None # (!) real value is "<class 'libqt_gui_cpp_sip.RosPluginlibPluginProvider_ForPlugins'>"
    Settings = None # (!) real value is "<class 'libqt_gui_cpp_sip.Settings'>"


