# encoding: utf-8
# module cairo._cairo
# from /usr/lib/python2.7/dist-packages/cairo/_cairo.x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import cairo as __cairo


class PDFVersion(__cairo._IntEnum):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    VERSION_1_4 = 0
    VERSION_1_5 = 1
    __map = {
        0: 'VERSION_1_4',
        1: 'VERSION_1_5',
    }


