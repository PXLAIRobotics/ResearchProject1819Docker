# encoding: utf-8
# module cairo._cairo
# from /usr/lib/python2.7/dist-packages/cairo/_cairo.x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import cairo as __cairo


class MeshPattern(__cairo.Pattern):
    # no doc
    def begin_patch(self, *args, **kwargs): # real signature unknown
        pass

    def curve_to(self, *args, **kwargs): # real signature unknown
        pass

    def end_patch(self, *args, **kwargs): # real signature unknown
        pass

    def get_control_point(self, *args, **kwargs): # real signature unknown
        pass

    def get_corner_color_rgba(self, *args, **kwargs): # real signature unknown
        pass

    def get_patch_count(self, *args, **kwargs): # real signature unknown
        pass

    def get_path(self, *args, **kwargs): # real signature unknown
        pass

    def line_to(self, *args, **kwargs): # real signature unknown
        pass

    def move_to(self, *args, **kwargs): # real signature unknown
        pass

    def set_control_point(self, *args, **kwargs): # real signature unknown
        pass

    def set_corner_color_rgb(self, *args, **kwargs): # real signature unknown
        pass

    def set_corner_color_rgba(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass


