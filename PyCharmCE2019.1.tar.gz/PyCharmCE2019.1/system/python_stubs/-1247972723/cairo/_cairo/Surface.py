# encoding: utf-8
# module cairo._cairo
# from /usr/lib/python2.7/dist-packages/cairo/_cairo.x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import cairo as __cairo


from object import object

class Surface(object):
    # no doc
    def copy_page(self, *args, **kwargs): # real signature unknown
        pass

    def create_for_rectangle(self, *args, **kwargs): # real signature unknown
        pass

    def create_similar(self, *args, **kwargs): # real signature unknown
        pass

    def create_similar_image(self, *args, **kwargs): # real signature unknown
        pass

    def finish(self, *args, **kwargs): # real signature unknown
        pass

    def flush(self, *args, **kwargs): # real signature unknown
        pass

    def get_content(self, *args, **kwargs): # real signature unknown
        pass

    def get_device(self, *args, **kwargs): # real signature unknown
        pass

    def get_device_offset(self, *args, **kwargs): # real signature unknown
        pass

    def get_device_scale(self, *args, **kwargs): # real signature unknown
        pass

    def get_fallback_resolution(self, *args, **kwargs): # real signature unknown
        pass

    def get_font_options(self, *args, **kwargs): # real signature unknown
        pass

    def get_mime_data(self, *args, **kwargs): # real signature unknown
        pass

    def has_show_text_glyphs(self, *args, **kwargs): # real signature unknown
        pass

    def map_to_image(self, *args, **kwargs): # real signature unknown
        pass

    def mark_dirty(self, *args, **kwargs): # real signature unknown
        pass

    def mark_dirty_rectangle(self, *args, **kwargs): # real signature unknown
        pass

    def set_device_offset(self, *args, **kwargs): # real signature unknown
        pass

    def set_device_scale(self, *args, **kwargs): # real signature unknown
        pass

    def set_fallback_resolution(self, *args, **kwargs): # real signature unknown
        pass

    def set_mime_data(self, *args, **kwargs): # real signature unknown
        pass

    def show_page(self, *args, **kwargs): # real signature unknown
        pass

    def supports_mime_type(self, *args, **kwargs): # real signature unknown
        pass

    def unmap_image(self, *args, **kwargs): # real signature unknown
        pass

    def write_to_png(self, *args, **kwargs): # real signature unknown
        pass

    def __eq__(self, y): # real signature unknown; restored from __doc__
        """ x.__eq__(y) <==> x==y """
        pass

    def __ge__(self, y): # real signature unknown; restored from __doc__
        """ x.__ge__(y) <==> x>=y """
        pass

    def __gt__(self, y): # real signature unknown; restored from __doc__
        """ x.__gt__(y) <==> x>y """
        pass

    def __hash__(self): # real signature unknown; restored from __doc__
        """ x.__hash__() <==> hash(x) """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __le__(self, y): # real signature unknown; restored from __doc__
        """ x.__le__(y) <==> x<=y """
        pass

    def __lt__(self, y): # real signature unknown; restored from __doc__
        """ x.__lt__(y) <==> x<y """
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    def __ne__(self, y): # real signature unknown; restored from __doc__
        """ x.__ne__(y) <==> x!=y """
        pass


