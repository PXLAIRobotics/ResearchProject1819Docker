# encoding: utf-8
# module cairo._cairo
# from /usr/lib/python2.7/dist-packages/cairo/_cairo.x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import cairo as __cairo


from object import object

class Matrix(object):
    # no doc
    @classmethod
    def init_rotate(cls, *args, **kwargs): # real signature unknown
        pass

    def invert(self, *args, **kwargs): # real signature unknown
        pass

    def multiply(self, *args, **kwargs): # real signature unknown
        pass

    def rotate(self, *args, **kwargs): # real signature unknown
        pass

    def scale(self, *args, **kwargs): # real signature unknown
        pass

    def transform_distance(self, *args, **kwargs): # real signature unknown
        pass

    def transform_point(self, *args, **kwargs): # real signature unknown
        pass

    def translate(self, *args, **kwargs): # real signature unknown
        pass

    def __eq__(self, y): # real signature unknown; restored from __doc__
        """ x.__eq__(y) <==> x==y """
        pass

    def __getitem__(self, y): # real signature unknown; restored from __doc__
        """ x.__getitem__(y) <==> x[y] """
        pass

    def __ge__(self, y): # real signature unknown; restored from __doc__
        """ x.__ge__(y) <==> x>=y """
        pass

    def __gt__(self, y): # real signature unknown; restored from __doc__
        """ x.__gt__(y) <==> x>y """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __le__(self, y): # real signature unknown; restored from __doc__
        """ x.__le__(y) <==> x<=y """
        pass

    def __lt__(self, y): # real signature unknown; restored from __doc__
        """ x.__lt__(y) <==> x<y """
        pass

    def __mul__(self, y): # real signature unknown; restored from __doc__
        """ x.__mul__(y) <==> x*y """
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    def __ne__(self, y): # real signature unknown; restored from __doc__
        """ x.__ne__(y) <==> x!=y """
        pass

    def __repr__(self): # real signature unknown; restored from __doc__
        """ x.__repr__() <==> repr(x) """
        pass

    def __rmul__(self, y): # real signature unknown; restored from __doc__
        """ x.__rmul__(y) <==> y*x """
        pass

    x0 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """X translation component of the affine transformation"""

    xx = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """xx component of the affine transformation"""

    xy = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """xy component of the affine transformation"""

    y0 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Y translation component of the affine transformation"""

    yx = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """yx component of the affine transformation"""

    yy = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """yy component of the affine transformation"""



