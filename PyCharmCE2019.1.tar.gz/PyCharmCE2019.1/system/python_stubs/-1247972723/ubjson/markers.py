# encoding: utf-8
# module ubjson.markers
# from /usr/lib/python2.7/dist-packages/ubjson/markers.x86_64-linux-gnu.so
# by generator 1.147
""" UBJSON marker defitions """

# imports
import __builtin__ as __builtins__ # <module '__builtin__' (built-in)>

# no functions
# no classes
# variables with complex values

__pyx_capi__ = {
    'ARRAY_END': None, # (!) real value is '<capsule object "PyObject *" at 0x7f950954dba0>'
    'ARRAY_START': None, # (!) real value is '<capsule object "PyObject *" at 0x7f950954db70>'
    'CONTAINER_COUNT': None, # (!) real value is '<capsule object "PyObject *" at 0x7f950954dc00>'
    'CONTAINER_TYPE': None, # (!) real value is '<capsule object "PyObject *" at 0x7f950954dbd0>'
    'OBJECT_END': None, # (!) real value is '<capsule object "PyObject *" at 0x7f950954db40>'
    'OBJECT_START': None, # (!) real value is '<capsule object "PyObject *" at 0x7f950954db10>'
    'TYPE_BOOL_FALSE': None, # (!) real value is '<capsule object "PyObject *" at 0x7f950954d900>'
    'TYPE_BOOL_TRUE': None, # (!) real value is '<capsule object "PyObject *" at 0x7f950954d8d0>'
    'TYPE_CHAR': None, # (!) real value is '<capsule object "PyObject *" at 0x7f950954dab0>'
    'TYPE_FLOAT32': None, # (!) real value is '<capsule object "PyObject *" at 0x7f950954da20>'
    'TYPE_FLOAT64': None, # (!) real value is '<capsule object "PyObject *" at 0x7f950954da50>'
    'TYPE_HIGH_PREC': None, # (!) real value is '<capsule object "PyObject *" at 0x7f950954da80>'
    'TYPE_INT16': None, # (!) real value is '<capsule object "PyObject *" at 0x7f950954d990>'
    'TYPE_INT32': None, # (!) real value is '<capsule object "PyObject *" at 0x7f950954d9c0>'
    'TYPE_INT64': None, # (!) real value is '<capsule object "PyObject *" at 0x7f950954d9f0>'
    'TYPE_INT8': None, # (!) real value is '<capsule object "PyObject *" at 0x7f950954d930>'
    'TYPE_NONE': None, # (!) real value is '<capsule object "PyObject *" at 0x7f950954d870>'
    'TYPE_NULL': None, # (!) real value is '<capsule object "PyObject *" at 0x7f950954d8a0>'
    'TYPE_STRING': None, # (!) real value is '<capsule object "PyObject *" at 0x7f950954dae0>'
    'TYPE_UINT8': None, # (!) real value is '<capsule object "PyObject *" at 0x7f950954d960>'
}

__test__ = {}

