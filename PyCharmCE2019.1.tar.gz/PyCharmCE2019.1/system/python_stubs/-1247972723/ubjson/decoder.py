# encoding: utf-8
# module ubjson.decoder
# from /usr/lib/python2.7/dist-packages/ubjson/decoder.x86_64-linux-gnu.so
# by generator 1.147
""" UBJSON draft v12 decoder. It does NOT support No-Op ('N') values """

# imports
import __builtin__ as __builtins__ # <module '__builtin__' (built-in)>
from ubjson.compat import raise_from

from _io import BytesIO

from _struct import pack

import _abcoll as ___abcoll


# functions

def load(*args, **kwargs): # real signature unknown
    """
    Decodes and returns UBJSON from the given file-like object
    
        Args:
            fp: read([size])-able object
            no_bytes (bool): If set, typed UBJSON arrays (uint8) will not be
                             converted to a bytes instance and instead treated like
                             any other array (i.e. result in a list).
            object_pairs_hook (class): A alternative class to use as the mapping
                                       type (instead of dict), e.g. OrderedDict
                                       from the collections module.
    
        Returns:
            Decoded object
    
        Raises:
            DecoderException: If an encoding failure occured.
    
        UBJSON types are mapped to Python types as follows.  Numbers in brackets
        denote Python version.
    
            +----------------------------------+---------------+
            | UBJSON                           | Python        |
            +==================================+===============+
            | object                           | dict          |
            +----------------------------------+---------------+
            | array                            | list          |
            +----------------------------------+---------------+
            | string                           | (3) str       |
            |                                  | (2) unicode   |
            +----------------------------------+---------------+
            | uint8, int8, int16, int32, int64 | (3) int       |
            |                                  | (2) int, long |
            +----------------------------------+---------------+
            | float32, float64                 | float         |
            +----------------------------------+---------------+
            | high_precision                   | Decimal       |
            +----------------------------------+---------------+
            | array (typed, uint8)             | (3) bytes     |
            |                                  | (2) str       |
            +----------------------------------+---------------+
            | true                             | True          |
            +----------------------------------+---------------+
            | false                            | False         |
            +----------------------------------+---------------+
            | null                             | None          |
            +----------------------------------+---------------+
    """
    pass

def loadb(*args, **kwargs): # real signature unknown
    """
    Decodes and returns UBJSON from the given bytes or bytesarray object. See
           load() for available arguments.
    """
    pass

def __UNPACK_FLOAT32(*args, **kwargs): # real signature unknown
    """
    S.unpack(str) -> (v1, v2, ...)
    
    Return tuple containing values unpacked according to this Struct's format.
    Requires len(str) == self.size. See struct.__doc__ for more on format
    strings.
    """
    pass

def __UNPACK_FLOAT64(*args, **kwargs): # real signature unknown
    """
    S.unpack(str) -> (v1, v2, ...)
    
    Return tuple containing values unpacked according to this Struct's format.
    Requires len(str) == self.size. See struct.__doc__ for more on format
    strings.
    """
    pass

def __UNPACK_INT16(*args, **kwargs): # real signature unknown
    """
    S.unpack(str) -> (v1, v2, ...)
    
    Return tuple containing values unpacked according to this Struct's format.
    Requires len(str) == self.size. See struct.__doc__ for more on format
    strings.
    """
    pass

def __UNPACK_INT32(*args, **kwargs): # real signature unknown
    """
    S.unpack(str) -> (v1, v2, ...)
    
    Return tuple containing values unpacked according to this Struct's format.
    Requires len(str) == self.size. See struct.__doc__ for more on format
    strings.
    """
    pass

def __UNPACK_INT64(*args, **kwargs): # real signature unknown
    """
    S.unpack(str) -> (v1, v2, ...)
    
    Return tuple containing values unpacked according to this Struct's format.
    Requires len(str) == self.size. See struct.__doc__ for more on format
    strings.
    """
    pass

# classes

class Decimal(object):
    """ Floating point class for decimal arithmetic. """
    def adjusted(self, *args, **kwargs): # real signature unknown
        """ Return the adjusted exponent of self """
        pass

    def as_tuple(self, *args, **kwargs): # real signature unknown
        """
        Represents the number as a triple tuple.
        
                To show the internals exactly as they are.
        """
        pass

    def canonical(self, *args, **kwargs): # real signature unknown
        """
        Returns the same Decimal object.
        
                As we do not have different encodings for the same number, the
                received object already is in its canonical form.
        """
        pass

    def compare(self, *args, **kwargs): # real signature unknown
        """
        Compares one to another.
        
                -1 => a < b
                0  => a = b
                1  => a > b
                NaN => one is NaN
                Like __cmp__, but returns Decimal instances.
        """
        pass

    def compare_signal(self, *args, **kwargs): # real signature unknown
        """
        Compares self to the other operand numerically.
        
                It's pretty much like compare(), but all NaNs signal, with signaling
                NaNs taking precedence over quiet NaNs.
        """
        pass

    def compare_total(self, *args, **kwargs): # real signature unknown
        """
        Compares self to other using the abstract representations.
        
                This is not like the standard compare, which use their numerical
                value. Note that a total ordering is defined for all possible abstract
                representations.
        """
        pass

    def compare_total_mag(self, *args, **kwargs): # real signature unknown
        """
        Compares self to other using abstract repr., ignoring sign.
        
                Like compare_total, but with operand's sign ignored and assumed to be 0.
        """
        pass

    def conjugate(self, *args, **kwargs): # real signature unknown
        pass

    def copy_abs(self, *args, **kwargs): # real signature unknown
        """ Returns a copy with the sign set to 0. """
        pass

    def copy_negate(self, *args, **kwargs): # real signature unknown
        """ Returns a copy with the sign inverted. """
        pass

    def copy_sign(self, *args, **kwargs): # real signature unknown
        """ Returns self with the sign of other. """
        pass

    def exp(self, *args, **kwargs): # real signature unknown
        """ Returns e ** self. """
        pass

    def fma(self, *args, **kwargs): # real signature unknown
        """
        Fused multiply-add.
        
                Returns self*other+third with no rounding of the intermediate
                product self*other.
        
                self and other are multiplied together, with no rounding of
                the result.  The third operand is then added to the result,
                and a single final rounding is performed.
        """
        pass

    @classmethod
    def from_float(cls, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """
        Converts a float to a decimal number, exactly.
        
                Note that Decimal.from_float(0.1) is not the same as Decimal('0.1').
                Since 0.1 is not exactly representable in binary floating point, the
                value is stored as the nearest representable value which is
                0x1.999999999999ap-4.  The exact equivalent of the value in decimal
                is 0.1000000000000000055511151231257827021181583404541015625.
        
                >>> Decimal.from_float(0.1)
                Decimal('0.1000000000000000055511151231257827021181583404541015625')
                >>> Decimal.from_float(float('nan'))
                Decimal('NaN')
                >>> Decimal.from_float(float('inf'))
                Decimal('Infinity')
                >>> Decimal.from_float(-float('inf'))
                Decimal('-Infinity')
                >>> Decimal.from_float(-0.0)
                Decimal('-0')
        """
        pass

    def is_canonical(self, *args, **kwargs): # real signature unknown
        """
        Return True if self is canonical; otherwise return False.
        
                Currently, the encoding of a Decimal instance is always
                canonical, so this method returns True for any Decimal.
        """
        pass

    def is_finite(self, *args, **kwargs): # real signature unknown
        """
        Return True if self is finite; otherwise return False.
        
                A Decimal instance is considered finite if it is neither
                infinite nor a NaN.
        """
        pass

    def is_infinite(self, *args, **kwargs): # real signature unknown
        """ Return True if self is infinite; otherwise return False. """
        pass

    def is_nan(self, *args, **kwargs): # real signature unknown
        """ Return True if self is a qNaN or sNaN; otherwise return False. """
        pass

    def is_normal(self, *args, **kwargs): # real signature unknown
        """ Return True if self is a normal number; otherwise return False. """
        pass

    def is_qnan(self, *args, **kwargs): # real signature unknown
        """ Return True if self is a quiet NaN; otherwise return False. """
        pass

    def is_signed(self, *args, **kwargs): # real signature unknown
        """ Return True if self is negative; otherwise return False. """
        pass

    def is_snan(self, *args, **kwargs): # real signature unknown
        """ Return True if self is a signaling NaN; otherwise return False. """
        pass

    def is_subnormal(self, *args, **kwargs): # real signature unknown
        """ Return True if self is subnormal; otherwise return False. """
        pass

    def is_zero(self, *args, **kwargs): # real signature unknown
        """ Return True if self is a zero; otherwise return False. """
        pass

    def ln(self, *args, **kwargs): # real signature unknown
        """ Returns the natural (base e) logarithm of self. """
        pass

    def log10(self, *args, **kwargs): # real signature unknown
        """ Returns the base 10 logarithm of self. """
        pass

    def logb(self, *args, **kwargs): # real signature unknown
        """
        Returns the exponent of the magnitude of self's MSD.
        
                The result is the integer which is the exponent of the magnitude
                of the most significant digit of self (as though it were truncated
                to a single digit while maintaining the value of that digit and
                without limiting the resulting exponent).
        """
        pass

    def logical_and(self, *args, **kwargs): # real signature unknown
        """ Applies an 'and' operation between self and other's digits. """
        pass

    def logical_invert(self, *args, **kwargs): # real signature unknown
        """ Invert all its digits. """
        pass

    def logical_or(self, *args, **kwargs): # real signature unknown
        """ Applies an 'or' operation between self and other's digits. """
        pass

    def logical_xor(self, *args, **kwargs): # real signature unknown
        """ Applies an 'xor' operation between self and other's digits. """
        pass

    def max(self, other): # real signature unknown; restored from __doc__
        """
        Returns the larger value.
        
                Like max(self, other) except if one is not a number, returns
                NaN (and signals if one is sNaN).  Also rounds.
        """
        pass

    def max_mag(self, *args, **kwargs): # real signature unknown
        """ Compares the values numerically with their sign ignored. """
        pass

    def min(self, other): # real signature unknown; restored from __doc__
        """
        Returns the smaller value.
        
                Like min(self, other) except if one is not a number, returns
                NaN (and signals if one is sNaN).  Also rounds.
        """
        pass

    def min_mag(self, *args, **kwargs): # real signature unknown
        """ Compares the values numerically with their sign ignored. """
        pass

    def next_minus(self, *args, **kwargs): # real signature unknown
        """ Returns the largest representable number smaller than itself. """
        pass

    def next_plus(self, *args, **kwargs): # real signature unknown
        """ Returns the smallest representable number larger than itself. """
        pass

    def next_toward(self, *args, **kwargs): # real signature unknown
        """
        Returns the number closest to self, in the direction towards other.
        
                The result is the closest representable number to self
                (excluding self) that is in the direction towards other,
                unless both have the same value.  If the two operands are
                numerically equal, then the result is a copy of self with the
                sign set to be the same as the sign of other.
        """
        pass

    def normalize(self, *args, **kwargs): # real signature unknown
        """ Normalize- strip trailing 0s, change anything equal to 0 to 0e0 """
        pass

    def number_class(self, *args, **kwargs): # real signature unknown
        """
        Returns an indication of the class of self.
        
                The class is one of the following strings:
                  sNaN
                  NaN
                  -Infinity
                  -Normal
                  -Subnormal
                  -Zero
                  +Zero
                  +Subnormal
                  +Normal
                  +Infinity
        """
        pass

    def quantize(self, *args, **kwargs): # real signature unknown
        """
        Quantize self so its exponent is the same as that of exp.
        
                Similar to self._rescale(exp._exp) but with error checking.
        """
        pass

    def radix(self, *args, **kwargs): # real signature unknown
        """ Just returns 10, as this is Decimal, :) """
        pass

    def remainder_near(self, *args, **kwargs): # real signature unknown
        """ Remainder nearest to 0-  abs(remainder-near) <= other/2 """
        pass

    def rotate(self, *args, **kwargs): # real signature unknown
        """ Returns a rotated copy of self, value-of-other times. """
        pass

    def same_quantum(self, *args, **kwargs): # real signature unknown
        """
        Return True if self and other have the same exponent; otherwise
                return False.
        
                If either operand is a special value, the following rules are used:
                   * return True if both operands are infinities
                   * return True if both operands are NaNs
                   * otherwise, return False.
        """
        pass

    def scaleb(self, *args, **kwargs): # real signature unknown
        """ Returns self operand after adding the second value to its exp. """
        pass

    def shift(self, *args, **kwargs): # real signature unknown
        """ Returns a shifted copy of self, value-of-other times. """
        pass

    def sqrt(self, *args, **kwargs): # real signature unknown
        """ Return the square root of self. """
        pass

    def to_eng_string(self, *args, **kwargs): # real signature unknown
        """
        Convert to a string, using engineering notation if an exponent is needed.
        
                Engineering notation has an exponent which is a multiple of 3.  This
                can leave up to 3 digits to the left of the decimal place and may
                require the addition of either one or two trailing zeros.
        """
        pass

    def to_integral(self, *args, **kwargs): # real signature unknown
        """ Rounds to the nearest integer, without raising inexact, rounded. """
        pass

    def to_integral_exact(self, *args, **kwargs): # real signature unknown
        """
        Rounds to a nearby integer.
        
                If no rounding mode is specified, take the rounding mode from
                the context.  This method raises the Rounded and Inexact flags
                when appropriate.
        
                See also: to_integral_value, which does exactly the same as
                this method except that it doesn't raise Inexact or Rounded.
        """
        pass

    def to_integral_value(self, *args, **kwargs): # real signature unknown
        """ Rounds to the nearest integer, without raising inexact, rounded. """
        pass

    def _check_nans(self, *args, **kwargs): # real signature unknown
        """
        Returns whether the number is not actually one.
        
                if self, other are sNaN, signal
                if self, other are NaN return nan
                return 0
        
                Done before operations.
        """
        pass

    def _cmp(self, *args, **kwargs): # real signature unknown
        """
        Compare the two non-NaN decimal instances self and other.
        
                Returns -1 if self < other, 0 if self == other and 1
                if self > other.  This routine is for internal use only.
        """
        pass

    def _compare_check_nans(self, *args, **kwargs): # real signature unknown
        """
        Version of _check_nans used for the signaling comparisons
                compare_signal, __le__, __lt__, __ge__, __gt__.
        
                Signal InvalidOperation if either self or other is a (quiet
                or signaling) NaN.  Signaling NaNs take precedence over quiet
                NaNs.
        
                Return 0 if neither operand is a NaN.
        """
        pass

    def _divide(self, *args, **kwargs): # real signature unknown
        """
        Return (self // other, self % other), to context.prec precision.
        
                Assumes that neither self nor other is a NaN, that self is not
                infinite and that other is nonzero.
        """
        pass

    def _fill_logical(self, *args, **kwargs): # real signature unknown
        pass

    def _fix(self, *args, **kwargs): # real signature unknown
        """
        Round if it is necessary to keep self within prec precision.
        
                Rounds and fixes the exponent.  Does not raise on a sNaN.
        
                Arguments:
                self - Decimal instance
                context - context used.
        """
        pass

    def _fix_nan(self, *args, **kwargs): # real signature unknown
        """ Decapitate the payload of a NaN to fit the context """
        pass

    def _iseven(self, *args, **kwargs): # real signature unknown
        """ Returns True if self is even.  Assumes self is an integer. """
        pass

    def _isinfinity(self, *args, **kwargs): # real signature unknown
        """
        Returns whether the number is infinite
        
                0 if finite or not a number
                1 if +INF
                -1 if -INF
        """
        pass

    def _isinteger(self, *args, **kwargs): # real signature unknown
        """ Returns whether self is an integer """
        pass

    def _islogical(self, *args, **kwargs): # real signature unknown
        """
        Return True if self is a logical operand.
        
                For being logical, it must be a finite number with a sign of 0,
                an exponent of 0, and a coefficient whose digits must all be
                either 0 or 1.
        """
        pass

    def _isnan(self, *args, **kwargs): # real signature unknown
        """
        Returns whether the number is not actually one.
        
                0 if a number
                1 if NaN
                2 if sNaN
        """
        pass

    def _ln_exp_bound(self, *args, **kwargs): # real signature unknown
        """
        Compute a lower bound for the adjusted exponent of self.ln().
                In other words, compute r such that self.ln() >= 10**r.  Assumes
                that self is finite and positive and that self != 1.
        """
        pass

    def _log10_exp_bound(self, *args, **kwargs): # real signature unknown
        """
        Compute a lower bound for the adjusted exponent of self.log10().
                In other words, find r such that self.log10() >= 10**r.
                Assumes that self is finite and positive and that self != 1.
        """
        pass

    def _power_exact(self, *args, **kwargs): # real signature unknown
        """
        Attempt to compute self**other exactly.
        
                Given Decimals self and other and an integer p, attempt to
                compute an exact result for the power self**other, with p
                digits of precision.  Return None if self**other is not
                exactly representable in p digits.
        
                Assumes that elimination of special cases has already been
                performed: self and other must both be nonspecial; self must
                be positive and not numerically equal to 1; other must be
                nonzero.  For efficiency, other._exp should not be too large,
                so that 10**abs(other._exp) is a feasible calculation.
        """
        pass

    def _power_modulo(self, *args, **kwargs): # real signature unknown
        """ Three argument version of __pow__ """
        pass

    def _rescale(self, *args, **kwargs): # real signature unknown
        """
        Rescale self so that the exponent is exp, either by padding with zeros
                or by truncating digits, using the given rounding mode.
        
                Specials are returned without change.  This operation is
                quiet: it raises no flags, and uses no information from the
                context.
        
                exp = exp to scale to (an integer)
                rounding = rounding mode
        """
        pass

    def _round(self, *args, **kwargs): # real signature unknown
        """
        Round a nonzero, nonspecial Decimal to a fixed number of
                significant figures, using the given rounding mode.
        
                Infinities, NaNs and zeros are returned unaltered.
        
                This operation is quiet: it raises no flags, and uses no
                information from the context.
        """
        pass

    def _round_05up(self, *args, **kwargs): # real signature unknown
        """ Round down unless digit prec-1 is 0 or 5. """
        pass

    def _round_ceiling(self, *args, **kwargs): # real signature unknown
        """ Rounds up (not away from 0 if negative.) """
        pass

    def _round_down(self, *args, **kwargs): # real signature unknown
        """ Also known as round-towards-0, truncate. """
        pass

    def _round_floor(self, *args, **kwargs): # real signature unknown
        """ Rounds down (not towards 0 if negative) """
        pass

    def _round_half_down(self, *args, **kwargs): # real signature unknown
        """ Round 5 down """
        pass

    def _round_half_even(self, *args, **kwargs): # real signature unknown
        """ Round 5 to even, rest to nearest. """
        pass

    def _round_half_up(self, *args, **kwargs): # real signature unknown
        """ Rounds 5 up (away from 0) """
        pass

    def _round_up(self, *args, **kwargs): # real signature unknown
        """ Rounds away from 0. """
        pass

    def __abs__(self, round=False): # real signature unknown; restored from __doc__
        """
        Returns the absolute value of self.
        
                If the keyword argument 'round' is false, do not round.  The
                expression self.__abs__(round=False) is equivalent to
                self.copy_abs().
        """
        pass

    def __add__(self, *args, **kwargs): # real signature unknown
        """
        Returns self + other.
        
                -INF + INF (or the reverse) cause InvalidOperation errors.
        """
        pass

    def __complex__(self, *args, **kwargs): # real signature unknown
        pass

    def __copy__(self, *args, **kwargs): # real signature unknown
        pass

    def __deepcopy__(self, *args, **kwargs): # real signature unknown
        pass

    def __divmod__(self, *args, **kwargs): # real signature unknown
        """ Return (self // other, self % other) """
        pass

    def __div__(self, *args, **kwargs): # real signature unknown
        """ Return self / other. """
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        pass

    def __float__(self, *args, **kwargs): # real signature unknown
        """ Float representation. """
        pass

    def __floordiv__(self, *args, **kwargs): # real signature unknown
        """ self // other """
        pass

    def __format__(self, *args, **kwargs): # real signature unknown
        """
        Format a Decimal instance according to the given specifier.
        
                The specifier should be a standard format specifier, with the
                form described in PEP 3101.  Formatting types 'e', 'E', 'f',
                'F', 'g', 'G', 'n' and '%' are supported.  If the formatting
                type is omitted it defaults to 'g' or 'G', depending on the
                value of context.capitals.
        """
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        pass

    def __hash__(self): # real signature unknown; restored from __doc__
        """ x.__hash__() <==> hash(x) """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __int__(self, *args, **kwargs): # real signature unknown
        """ Converts self to an int, truncating if necessary. """
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        pass

    def __long__(self, *args, **kwargs): # real signature unknown
        """
        Converts to a long.
        
                Equivalent to long(int(self))
        """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        pass

    def __mod__(self, *args, **kwargs): # real signature unknown
        """ self % other """
        pass

    def __mul__(self, *args, **kwargs): # real signature unknown
        """
        Return self * other.
        
                (+-) INF * 0 (or its reverse) raise InvalidOperation.
        """
        pass

    def __neg__(self, *args, **kwargs): # real signature unknown
        """
        Returns a copy with the sign switched.
        
                Rounds, if it has reason.
        """
        pass

    @staticmethod # known case of __new__
    def __new__(cls, value=0, context=None): # reliably restored by inspect
        """
        Create a decimal point instance.
        
                >>> Decimal('3.14')              # string input
                Decimal('3.14')
                >>> Decimal((0, (3, 1, 4), -2))  # tuple (sign, digit_tuple, exponent)
                Decimal('3.14')
                >>> Decimal(314)                 # int or long
                Decimal('314')
                >>> Decimal(Decimal(314))        # another decimal instance
                Decimal('314')
                >>> Decimal('  3.14  \n')        # leading and trailing whitespace okay
                Decimal('3.14')
        """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        pass

    def __nonzero__(self, *args, **kwargs): # real signature unknown
        """
        Return True if self is nonzero; otherwise return False.
        
                NaNs and infinities are considered nonzero.
        """
        pass

    def __pos__(self, *args, **kwargs): # real signature unknown
        """
        Returns a copy, unless it is a sNaN.
        
                Rounds the number (if more than precision digits)
        """
        pass

    def __pow__(self, *args, **kwargs): # real signature unknown
        """
        Return self ** other [ % modulo].
        
                With two arguments, compute self**other.
        
                With three arguments, compute (self**other) % modulo.  For the
                three argument form, the following restrictions on the
                arguments hold:
        
                 - all three arguments must be integral
                 - other must be nonnegative
                 - either self or other (or both) must be nonzero
                 - modulo must be nonzero and must have at most p digits,
                   where p is the context precision.
        
                If any of these restrictions is violated the InvalidOperation
                flag is raised.
        
                The result of pow(self, other, modulo) is identical to the
                result that would be obtained by computing (self**other) %
                modulo with unbounded precision, but is computed more
                efficiently.  It is always exact.
        """
        pass

    def __radd__(self, *args, **kwargs): # real signature unknown
        """
        Returns self + other.
        
                -INF + INF (or the reverse) cause InvalidOperation errors.
        """
        pass

    def __rdivmod__(self, *args, **kwargs): # real signature unknown
        """ Swaps self/other and returns __divmod__. """
        pass

    def __rdiv__(self, *args, **kwargs): # real signature unknown
        """ Swaps self/other and returns __truediv__. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Represents the number as an instance of Decimal. """
        pass

    def __rfloordiv__(self, *args, **kwargs): # real signature unknown
        """ Swaps self/other and returns __floordiv__. """
        pass

    def __rmod__(self, *args, **kwargs): # real signature unknown
        """ Swaps self/other and returns __mod__. """
        pass

    def __rmul__(self, *args, **kwargs): # real signature unknown
        """
        Return self * other.
        
                (+-) INF * 0 (or its reverse) raise InvalidOperation.
        """
        pass

    def __rpow__(self, *args, **kwargs): # real signature unknown
        """ Swaps self/other and returns __pow__. """
        pass

    def __rsub__(self, *args, **kwargs): # real signature unknown
        """ Return other - self """
        pass

    def __rtruediv__(self, *args, **kwargs): # real signature unknown
        """ Swaps self/other and returns __truediv__. """
        pass

    def __str__(self, *args, **kwargs): # real signature unknown
        """
        Return string representation of the number in scientific notation.
        
                Captures all of the information in the underlying representation.
        """
        pass

    def __sub__(self, *args, **kwargs): # real signature unknown
        """ Return self - other """
        pass

    def __truediv__(self, *args, **kwargs): # real signature unknown
        """ Return self / other. """
        pass

    def __trunc__(self, *args, **kwargs): # real signature unknown
        """ Converts self to an int, truncating if necessary. """
        pass

    imag = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    real = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _exp = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _int = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _is_special = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _sign = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    _pick_rounding_function = {
        'ROUND_05UP': None, # (!) real value is '<function _round_05up at 0x7fed96508ed8>'
        'ROUND_CEILING': None, # (!) real value is '<function _round_ceiling at 0x7fed96508de8>'
        'ROUND_DOWN': None, # (!) real value is '<function _round_down at 0x7fed96508b90>'
        'ROUND_FLOOR': None, # (!) real value is '<function _round_floor at 0x7fed96508e60>'
        'ROUND_HALF_DOWN': None, # (!) real value is '<function _round_half_down at 0x7fed96508cf8>'
        'ROUND_HALF_EVEN': None, # (!) real value is '<function _round_half_even at 0x7fed96508d70>'
        'ROUND_HALF_UP': None, # (!) real value is '<function _round_half_up at 0x7fed96508c80>'
        'ROUND_UP': None, # (!) real value is '<function _round_up at 0x7fed96508c08>'
    }
    __slots__ = (
        '_exp',
        '_int',
        '_sign',
        '_is_special',
    )


class DecimalException(ArithmeticError):
    """
    Base exception class.
    
        Used exceptions derive from this.
        If an exception derives from another exception besides this (such as
        Underflow (Inexact, Rounded, Subnormal) that indicates that it is only
        called if the others are present.  This isn't actually used for
        anything, though.
    
        handle  -- Called when context._raise_error is called and the
                   trap_enabler is not set.  First argument is self, second is the
                   context.  More arguments can be given, those being after
                   the explanation in _raise_error (For example,
                   context._raise_error(NewError, '(-x)!', self._sign) would
                   call NewError().handle(context, self._sign).)
    
        To define a new exception, it should be sufficient to have it derive
        from DecimalException.
    """
    def handle(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



class DecoderException(ValueError):
    """ Raised when decoding of a UBJSON stream fails. """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    __qualname__ = 'DecoderException'


class Mapping(___abcoll.Sized, ___abcoll.Iterable, ___abcoll.Container):
    """
    A Mapping is a generic container for associating key/value
        pairs.
    
        This class provides concrete generic implementations of all
        methods except for __getitem__, __iter__, and __len__.
    """
    def get(self, k, d=None): # real signature unknown; restored from __doc__
        """ D.get(k[,d]) -> D[k] if k in D, else d.  d defaults to None. """
        pass

    def items(self): # real signature unknown; restored from __doc__
        """ D.items() -> list of D's (key, value) pairs, as 2-tuples """
        return []

    def iteritems(self): # real signature unknown; restored from __doc__
        """ D.iteritems() -> an iterator over the (key, value) items of D """
        pass

    def iterkeys(self): # real signature unknown; restored from __doc__
        """ D.iterkeys() -> an iterator over the keys of D """
        pass

    def itervalues(self): # real signature unknown; restored from __doc__
        """ D.itervalues() -> an iterator over the values of D """
        pass

    def keys(self): # real signature unknown; restored from __doc__
        """ D.keys() -> list of D's keys """
        return []

    def values(self): # real signature unknown; restored from __doc__
        """ D.values() -> list of D's values """
        return []

    def __contains__(self, *args, **kwargs): # real signature unknown
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is '<_weakrefset.WeakSet object at 0x7fed97ef2a10>'
    _abc_negative_cache = None # (!) real value is '<_weakrefset.WeakSet object at 0x7fed97ef2a90>'
    _abc_negative_cache_version = 3
    _abc_registry = None # (!) real value is '<_weakrefset.WeakSet object at 0x7fed97ef29d0>'
    __abstractmethods__ = frozenset(['__iter__', '__getitem__', '__len__'])
    __hash__ = None


class Struct(object):
    """ Compiled struct object """
    def pack(self, v1, v2, *more): # real signature unknown; restored from __doc__
        """
        S.pack(v1, v2, ...) -> string
        
        Return a string containing values v1, v2, ... packed according to this
        Struct's format. See struct.__doc__ for more on format strings.
        """
        return ""

    def pack_into(self, buffer, offset, v1, v2, *more): # real signature unknown; restored from __doc__
        """
        S.pack_into(buffer, offset, v1, v2, ...)
        
        Pack the values v1, v2, ... according to this Struct's format, write 
        the packed bytes into the writable buffer buf starting at offset.  Note
        that the offset is not an optional argument.  See struct.__doc__ for 
        more on format strings.
        """
        pass

    def unpack(self, p_str): # real signature unknown; restored from __doc__
        """
        S.unpack(str) -> (v1, v2, ...)
        
        Return tuple containing values unpacked according to this Struct's format.
        Requires len(str) == self.size. See struct.__doc__ for more on format
        strings.
        """
        pass

    def unpack_from(self, buffer, offset=None): # real signature unknown; restored from __doc__
        """
        S.unpack_from(buffer[, offset]) -> (v1, v2, ...)
        
        Return tuple containing values unpacked according to this Struct's format.
        Unlike unpack, unpack_from can unpack values from any object supporting
        the buffer API, not just str. Requires len(buffer[offset:]) >= self.size.
        See struct.__doc__ for more on format strings.
        """
        pass

    def __delattr__(self, name): # real signature unknown; restored from __doc__
        """ x.__delattr__('name') <==> del x.name """
        pass

    def __getattribute__(self, name): # real signature unknown; restored from __doc__
        """ x.__getattribute__('name') <==> x.name """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    def __setattr__(self, name, value): # real signature unknown; restored from __doc__
        """ x.__setattr__('name', value) <==> x.name = value """
        pass

    def __sizeof__(self): # real signature unknown; restored from __doc__
        """ S.__sizeof__() -> size of S in memory, in bytes """
        pass

    format = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """struct format string"""

    size = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """struct size in bytes"""



class StructError(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



# variables with complex values

__METHOD_MAP = {
    'C': None, # (!) real value is '<cyfunction __Pyx_CFunc_unicode____object____bytes___to_py.<locals>.wrap at 0x7fed96db8f50>'
    'D': None, # (!) real value is '<cyfunction __Pyx_CFunc_object____object____bytes___to_py.<locals>.wrap at 0x7fed96db8dd0>'
    'F': None, # (!) real value is '<cyfunction <lambda> at 0x7fed96db8890>'
    'H': None, # (!) real value is '<cyfunction __Pyx_CFunc_object____object____bytes___to_py.<locals>.wrap at 0x7fed96db8e90>'
    'I': None, # (!) real value is '<cyfunction __Pyx_CFunc_object____object____bytes___to_py.<locals>.wrap at 0x7fed96db8ad0>'
    'L': None, # (!) real value is '<cyfunction __Pyx_CFunc_object____object____bytes___to_py.<locals>.wrap at 0x7fed96db8c50>'
    'S': None, # (!) real value is '<cyfunction __Pyx_CFunc_unicode____object____bytes___to_py.<locals>.wrap at 0x7fed97de1050>'
    'T': None, # (!) real value is '<cyfunction <lambda> at 0x7fed96db87d0>'
    'U': None, # (!) real value is '<cyfunction __Pyx_CFunc_object____object____bytes___to_py.<locals>.wrap at 0x7fed96db8a10>'
    'Z': None, # (!) real value is '<cyfunction <lambda> at 0x7fed96db8710>'
    'd': None, # (!) real value is '<cyfunction __Pyx_CFunc_object____object____bytes___to_py.<locals>.wrap at 0x7fed96db8d10>'
    'i': None, # (!) real value is '<cyfunction __Pyx_CFunc_object____object____bytes___to_py.<locals>.wrap at 0x7fed96db8950>'
    'l': None, # (!) real value is '<cyfunction __Pyx_CFunc_object____object____bytes___to_py.<locals>.wrap at 0x7fed96db8b90>'
}

__pyx_capi__ = {
    '__SMALL_INTS_DECODED': None, # (!) real value is '<capsule object "PyObject *" at 0x7fed97dd02a0>'
    '__SMALL_UINTS_DECODED': None, # (!) real value is '<capsule object "PyObject *" at 0x7fed97dd02d0>'
    '__TYPES': None, # (!) real value is '<capsule object "PyObject *" at 0x7fed964ffd50>'
    '__TYPES_INT': None, # (!) real value is '<capsule object "PyObject *" at 0x7fed97dd0270>'
    '__TYPES_NO_DATA': None, # (!) real value is '<capsule object "PyObject *" at 0x7fed964ffd80>'
    '__decode_array': None, # (!) real value is '<capsule object "PyObject *(PyObject *, int, PyObject *)" at 0x7fed97dd05a0>'
    '__decode_char': None, # (!) real value is '<capsule object "PyObject *(PyObject *, PyObject *)" at 0x7fed97dd04b0>'
    '__decode_float32': None, # (!) real value is '<capsule object "PyObject *(PyObject *, PyObject *)" at 0x7fed97dd0450>'
    '__decode_float64': None, # (!) real value is '<capsule object "PyObject *(PyObject *, PyObject *)" at 0x7fed97dd0480>'
    '__decode_high_prec': None, # (!) real value is '<capsule object "PyObject *(PyObject *, PyObject *)" at 0x7fed97dd0300>'
    '__decode_int16': None, # (!) real value is '<capsule object "PyObject *(PyObject *, PyObject *)" at 0x7fed97dd03c0>'
    '__decode_int32': None, # (!) real value is '<capsule object "PyObject *(PyObject *, PyObject *)" at 0x7fed97dd03f0>'
    '__decode_int64': None, # (!) real value is '<capsule object "PyObject *(PyObject *, PyObject *)" at 0x7fed97dd0420>'
    '__decode_int8': None, # (!) real value is '<capsule object "PyObject *(PyObject *, PyObject *)" at 0x7fed97dd0360>'
    '__decode_int_non_negative': None, # (!) real value is '<capsule object "PyObject *(PyObject *, PyObject *)" at 0x7fed97dd0330>'
    '__decode_object': None, # (!) real value is '<capsule object "PyObject *(PyObject *, int, PyObject *)" at 0x7fed97dd0570>'
    '__decode_object_key': None, # (!) real value is '<capsule object "PyObject *(PyObject *, PyObject *)" at 0x7fed97dd0510>'
    '__decode_string': None, # (!) real value is '<capsule object "PyObject *(PyObject *, PyObject *)" at 0x7fed97dd04e0>'
    '__decode_uint8': None, # (!) real value is '<capsule object "PyObject *(PyObject *, PyObject *)" at 0x7fed97dd0390>'
    '__get_container_params': None, # (!) real value is '<capsule object "PyObject *(PyObject *, int, int, PyObject *)" at 0x7fed97dd0540>'
    'load': None, # (!) real value is '<capsule object "PyObject *(PyObject *, int __pyx_skip_dispatch, struct __pyx_opt_args_6ubjson_7decoder_load *__pyx_optional_args)" at 0x7fed97dd05d0>'
    'loadb': None, # (!) real value is '<capsule object "PyObject *(PyObject *, int __pyx_skip_dispatch, struct __pyx_opt_args_6ubjson_7decoder_loadb *__pyx_optional_args)" at 0x7fed97dd0600>'
}

__test__ = {}

